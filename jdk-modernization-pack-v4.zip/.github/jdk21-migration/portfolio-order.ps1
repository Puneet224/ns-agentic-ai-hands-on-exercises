#requires -Version 7.0
<#
.SYNOPSIS
  Cross-repo migration order. Every assessment (with portfolioCsv set) writes graph/<repo>.json
  listing which internal artifacts the repo provides and consumes. This script orders the repos in
  waves: shared libraries that others depend on come first, then the apps that consume them.
.EXAMPLE
  pwsh .github/jdk21-migration/portfolio-order.ps1 -PortfolioDir C:\work\jdk-assessment
#>
param([Parameter(Mandatory)][string]$PortfolioDir)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$nodes = @{}
foreach ($f in Get-ChildItem -LiteralPath (Join-Path $PortfolioDir 'graph') -Filter '*.json') { $n = Read-JsonFile $f.FullName; $nodes[$n.repo] = $n }
if (-not $nodes.Count) { throw "No graph/*.json in $PortfolioDir - run assessments with portfolioCsv set first." }

$providerOf = @{}
foreach ($n in $nodes.Values) { foreach ($p in @($n.provides)) { $providerOf[$p] = $n.repo } }
$deps = @{}
foreach ($n in $nodes.Values) {
    $deps[$n.repo] = @(@($n.consumes) | ForEach-Object { $providerOf[$_] } | Where-Object { $_ -and $_ -ne $n.repo } | Select-Object -Unique)
}
$unknown = @($nodes.Values | ForEach-Object { @($_.consumes) } | Where-Object { -not $providerOf.ContainsKey($_) } | Select-Object -Unique)

$done = @{}; $waves = [System.Collections.Generic.List[object]]::new()
while ($done.Count -lt $nodes.Count) {
    $ready = @($nodes.Keys | Where-Object { -not $done.ContainsKey($_) -and @($deps[$_] | Where-Object { -not $done.ContainsKey($_) }).Count -eq 0 } | Sort-Object)
    if (-not $ready.Count) {
        $cycle = @($nodes.Keys | Where-Object { -not $done.ContainsKey($_) })
        $waves.Add(@{ repos = $cycle; note = 'CYCLE - these repos depend on each other; migrate together or break the cycle' })
        break
    }
    foreach ($r in $ready) { $done[$r] = $true }
    $waves.Add(@{ repos = $ready; note = '' })
}

$md = [System.Collections.Generic.List[string]]::new()
$md.Add('# Cross-repo JDK migration order'); $md.Add('')
$i = 1
foreach ($w in $waves) {
    $md.Add("## Wave $i $($w.note)"); $md.Add('')
    foreach ($r in $w.repos) {
        $n = $nodes[$r]
        $md.Add("- **$r** ($($n.role), Java $($n.sourceJdk), $($n.recommendation))$(if (@($deps[$r]).Count) { ' - after: ' + (@($deps[$r]) -join ', ') })")
    }
    $md.Add(''); $i++
}
$md.Add('Libraries: build on the new JDK but keep --release at the lowest consumer level until every consumer has migrated.')
if ($unknown.Count) { $md.Add(''); $md.Add("Internal artifacts consumed but not provided by any assessed repo (assess those repos too): $($unknown -join ', ')") }
$out = Join-Path $PortfolioDir 'portfolio-order.md'
$md | Set-Content -LiteralPath $out -Encoding utf8NoBOM
$md | ForEach-Object { Write-Host $_ }
Write-Host "`n-> $out" -ForegroundColor Green
