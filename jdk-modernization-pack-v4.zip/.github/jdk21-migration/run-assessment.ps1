#requires -Version 7.0
<#
.SYNOPSIS
  Assessment only - changes NOTHING in the repo. Answers:
    * current vs target Java, JDK homes, company-repo enforcement
    * can all Snyk/Checkmarx findings be fixed on the current JDK, or do they need a JDK upgrade
      and/or framework modernization (javax -> jakarta, Spring/Hibernate lines)?
    * JDK upgrade effort (frameworks, removed APIs, internal libs, JVM flags, behaviour risks)
  Output: .jdk21-work/assessment-report.md (+ optional portfolio CSV row across repos)

.EXAMPLE
  pwsh .github/jdk21-migration/run-assessment.ps1
  pwsh C:\tools\.github\jdk21-migration\run-assessment.ps1 -RepoPath C:\code\repo-x -TargetJdk 17 -NonInteractive
#>
[CmdletBinding()]
param(
    [string]$RepoPath,
    [string]$TargetJdk,
    [switch]$Force,
    [switch]$NonInteractive
)
$ErrorActionPreference = 'Stop'
if (-not $RepoPath) { $RepoPath = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path }
if ($NonInteractive) { $env:JDKMIG_NONINTERACTIVE = '1' }
Import-Module (Join-Path $PSScriptRoot 'lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
if ($TargetJdk) { Save-MachineConfig $ctx 'targetJdk' $TargetJdk; $ctx = Get-MigContext $RepoPath }

# Copilot Chat mode: finish the AI task handed out by the previous run before doing anything else
if (-not $env:JDKMIG_PARENT_RUNNER) { $env:JDKMIG_RESUME_CMD = "pwsh -NoProfile -File $($MyInvocation.MyCommand.Path) -RepoPath `"$($ctx.Repo)`" -NonInteractive" }
$pendingState = Complete-PendingChatTask $ctx
if ($pendingState -eq 'waiting') { exit 3 }

$sw = [Diagnostics.Stopwatch]::StartNew()
foreach ($p in Get-ChildItem (Join-Path $PSScriptRoot 'assess') -Filter 'A*.ps1' | Sort-Object Name) {
    $name = $p.BaseName
    $state = Get-State $ctx
    $status = if ($state.phases.ContainsKey($name)) { $state.phases[$name].status } else { $null }
    if (-not $Force -and $status -in 'done', 'skipped') { Write-Info "skip $name (already $status; -Force reruns)"; continue }
    try { & $p.FullName -RepoPath $ctx.Repo }
    catch {
        if ($_.Exception.Message -like 'AI-TASK-PENDING:*') { Write-Host "`nWaiting for the AI task above ($name). Do it, then rerun the command." -ForegroundColor Magenta; exit 3 }
        Write-Host "`nSTOPPED in $name : $($_.Exception.Message)" -ForegroundColor Red
        Invoke-ErrorTriage $ctx $name $_.Exception.Message
        Write-Host "Logs: $($ctx.Config.workDir)/logs  |  fix and rerun (finished phases are skipped)" -ForegroundColor Red
        exit 1
    }
}
Write-Host "`nAssessment finished in $([int]$sw.Elapsed.TotalMinutes) min -> $($ctx.Config.workDir)/assessment-report.md" -ForegroundColor Green

exit 0
