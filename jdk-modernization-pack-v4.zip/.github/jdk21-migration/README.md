# JDK upgrade & modernization toolkit (PowerShell tools + Copilot agents)

## Quick start with Copilot Chat (no CLI needed - default `aiMode: "chat"`)
1. Copy `.github/jdk21-migration`, `.github/agents`, `.github/prompts` into the repo (or a tools repo).
2. Once, in your own terminal: `pwsh .github/jdk21-migration/run-assessment.ps1` - it detects the
   project Java level and asks for JDK paths only if it cannot find them (saved for later runs).
3. VS Code Copilot Chat -> **Agent** mode -> type `/jdk-assess` (report only), `/jdk-migrate` (upgrade), or
   `/jdk-auto` (assess, then migrate in continuation only if required - `run-all.ps1`).
   If prompt files are not picked up, select the `jdk-driver` agent and paste the command from the
   prompt file.
4. The driver runs the script; whenever AI is needed the script prints **AI TASK PENDING** with a task
   file. Copilot does that task, writes the output JSON and reruns. On rerun the script validates the
   output, reverts out-of-scope edits, runs the test-integrity guard, issues a reviewer task, and only
   then commits. Allow (or auto-approve) the `pwsh ...run-*.ps1` terminal command in VS Code.
5. Long chat? Open a new chat and run the same prompt - everything resumes from `.jdk21-work/`.

`aiMode: "cli"` uses the Copilot CLI instead (fully unattended).

Two entry points, same tools:

| runner | changes code? | purpose |
|---|---|---|
| `run-assessment.ps1` | **no** | Can Snyk/Checkmarx findings be fixed on the current JDK, or do they need a JDK upgrade and/or framework modernization? How big is the JDK upgrade? |
| `run-pipeline.ps1` | yes (own branch) | Execute the JDK upgrade with AI-assisted fixing, review and security gates |
| `run-all.ps1` | only if required | Assessment, decision gate (`autoMigrateOn`, AI disagreement pauses), then the migration pipeline. `-Migrate auto|always|never` |

## Architecture
A deterministic **PowerShell orchestrator** runs numbered phase scripts (tools). Each phase does all
mechanical work itself (parsing poms, Maven, jdeps, Snyk, Checkmarx, git) and calls a **specialised
agent** only for judgement. Agents never call each other and never run commands; the orchestrator
passes data between them (supervisor pattern):

| agent (`.github/agents/`) | role | can write |
|---|---|---|
| jdk21-fixer | fix compile errors in one file | that file |
| jdk21-test-fixer | fix JDK regressions in one test class | test + implicated sources |
| jdk-config-fixer | JVM flags / CI JDK pins in one config file | that file + JSON result |
| jdk-code-reviewer | **checker** for every AI diff (approve/reject + risk) | JSON verdict only |
| jdk21-plan-reviewer | review the upgrade plan | review file only |
| jdk-assessment-reviewer | validate the assessment decision | JSON verdict only |
| jdk-error-triage | diagnose any failed phase | JSON diagnosis only |

**Prompts:** no hand-written prompt files. Each agent has a short role file; per task the script
writes a JSON **input file** and an **output contract** (required keys, allowed values, example),
validates the agent's JSON output and retries once with the validation error. (The model still reads
one short instruction sentence - an LLM always needs some text.)

## AI in the loop
- **Errors:** any failed phase -> `jdk-error-triage` returns category, root cause, actions (`triage-<phase>.json`).
- **Review:** every AI code/config edit -> `jdk-code-reviewer`; *reject* or *high risk* = automatic revert + "needs human".
- **Changes:** code (compile, tests) and repo configuration files, always narrow file scope.
- **Decisions:** plan review and assessment review; disagreement with the automated decision is flagged.
- Test integrity guard: AI edits that disable tests or remove assertions are reverted.

## Assessment (`run-assessment.ps1`)
```
A00 environment      project Java level from poms; JDK homes auto-discovered (toolchains.xml,
                     JAVA_HOME, vendor folders) - asks only if ambiguous; company-repo policy;
                     tools + token presence
A01 analysis         inventory, compile on current JDK, jdeps/jdeprscan, compatibility scan
A02 security scans   Snyk + Checkmarx (SARIF) baseline
A03 requirements     each fixed version: in company repo? Java needed (bytecode)? javax->jakarta?
                     framework major line? -> fixable-now | needs-jdk-upgrade |
                     needs-framework-modernization | beyond-target-jdk | blocked-not-in-company-repo | no-fix
A04 AI review        structured second opinion
A05 report           assessment-report.md + one row in portfolioCsv (compare many repos)
```
`pwsh run-assessment.ps1 -RepoPath C:\code\repo-x -TargetJdk 21 [-NonInteractive]`

## Migration (`run-pipeline.ps1`)
```
00 preflight      JDK detection, company-repo enforcement, git branch
01 baseline       build + tests on current JDK (behaviour reference)
02 inventory  03 compat  04 security baseline (Snyk + Checkmarx)
05 plan           merged plan -> PAUSE for human approval ("approved": true)
06 apply-poms     deterministic pom edits
07 config-fix     repo config files (agent + reviewer)
08 compile-fix    per-file fixes (agent + reviewer)
09 test-fix       regressions vs baseline (agent + integrity guard + reviewer)
10 security-gate  Snyk + Checkmarx again; new findings >= threshold stop the run
11 report         final-report.md + server-team-handoff.md
12 push           only if push.enabled and the gate passed (never force)
```
Options: `-From 08`, `-To 05`, `-Only 03,05`, `-Force`, `-SkipBaseline`, `-SkipSnyk`, `-AllowDirty`, `-NonInteractive`.

## Company repository only
Set `allowedRepoHosts` (e.g. `nexus.yourcompany.com`). With `enforceCompanyRepo: true` the run stops
unless settings.xml has a catch-all `<mirrorOf>*</mirrorOf>` mirror on an allowed host and no
pom/settings repository bypasses it. `isolatedLocalRepo: true` uses a fresh local repository so cached
public artifacts cannot hide gaps. Proposed fix versions are resolved through that repository first.

## Credentials
Environment variables only: `SNYK_TOKEN` (or prior `snyk auth`) and the Checkmarx variables in
`checkmarx.requiredEnv` (default `CX_BASE_URI`, `CX_TENANT`, `CX_APIKEY`). Never put tokens in JSON.
The Checkmarx command line is a template (`checkmarx.args`) - adapt it to your CLI version, or set
`checkmarx.importSarif` to reuse a SARIF report from CI.

## Config layering
`config.default.json` < `<repo>/.jdk21-migration.json` (see sample) < `<workDir>/machine.json`
(JDK paths chosen on this PC, git-excluded). Rules: `rules/jdk<target>-rules.json` (falls back to the
JDK 21 rules) - verify minimum versions against your approved list.

## Not automated (by design)
Framework *line* upgrades (Spring 4->5.3, Boot 2->3, javax->jakarta) are assessed and planned but never
auto-approved. Server-side configuration outside the repo goes to the server-team handoff.
OpenRewrite-based framework modernization is the planned next step.

## v4 additions (industry-practice gaps)
- **Transitive dependencies:** `dependency:tree` before/after (who brings each jar), version divergence
  across modules, every third-party jar scanned (class-file level, JDK internals, removed JDK APIs ->
  runtime deps added to WAR modules), before/after transitive diff in the final report.
- **Deprecated APIs:** javac deprecation warnings on the current and the target JDK (incl. "marked for
  removal"), plus jdeprscan. Removed APIs are fixed in phase 08; deprecated ones are reported.
- **Library vs application:** shared-library repos build on the new JDK but keep `--release` at the
  consumers' level (`libraryRelease`), and dependency upgrades that would raise that level are not
  auto-approved. `portfolio-order.ps1 -PortfolioDir <dir>` orders all assessed repos in waves.
- **Source encoding:** missing `project.build.sourceEncoding` + non-UTF-8 sources detected (JDK 18+
  javac assumes UTF-8); plan pins the encoding.
- **Java agents:** `-javaagent` in repo scripts/config flagged for vendor confirmation (handoff 3b).
- **Coverage gate:** JaCoCo on the baseline run (no pom change); risky and migration-changed files
  below `coverage.minLineCoverageForRiskFiles` are listed (`coverage.mode: warn|fail`).
- **Release readiness:** `release-readiness-checklist.md` - runtime validation, golden-master
  comparison, serialization / mixed-cluster decision, performance baseline table, rollout & rollback.
