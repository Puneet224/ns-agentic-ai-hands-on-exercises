#requires -Version 7.0
# Shared helpers for the JDK 8 -> 21 migration pipeline.
# Deterministic work (parsing, scanning, building, version maths) lives here;
# only judgement work is sent to Copilot via Invoke-Copilot.

$ErrorActionPreference = 'Stop'
$script:ToolRoot = Split-Path -Parent $PSScriptRoot      # .github/jdk21-migration
$script:OrigPath = $env:PATH

# ------------------------------------------------------------------ output
function Write-Step([string]$Message) { Write-Host "`n==> $Message" -ForegroundColor Cyan }
function Write-Info([string]$Message) { Write-Host "    $Message" }
function Write-Warn2([string]$Message) { Write-Host "    WARN: $Message" -ForegroundColor Yellow }
function Write-Good([string]$Message) { Write-Host "    OK: $Message" -ForegroundColor Green }

# ------------------------------------------------------------------ json / state
function Read-JsonFile([string]$Path) {
    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return $null }
    $raw = Get-Content -LiteralPath $Path -Raw
    if (-not $raw) { return $null }
    $raw | ConvertFrom-Json -AsHashtable
}

function Save-JsonFile($Object, [string]$Path) {
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $Object | ConvertTo-Json -Depth 40 | Set-Content -LiteralPath $Path -Encoding utf8NoBOM
}

function Get-MigContext {
    param([Parameter(Mandatory)][string]$RepoPath)
    $repo = (Resolve-Path -LiteralPath $RepoPath).Path
    $cfg = Read-JsonFile (Join-Path $script:ToolRoot 'config.default.json')
    if (-not $cfg) { throw "config.default.json not found in $script:ToolRoot" }
    $override = Read-JsonFile (Join-Path $repo '.jdk21-migration.json')
    if ($override) { foreach ($k in @($override.Keys)) { $cfg[$k] = $override[$k] } }
    $work = Join-Path $repo $cfg.workDir
    $logs = Join-Path $work 'logs'
    New-Item -ItemType Directory -Force -Path $work, $logs | Out-Null
    # machine-specific values (JDK paths chosen on this PC) live in the git-excluded work dir
    $machine = Read-JsonFile (Join-Path $work 'machine.json')
    if ($machine) { foreach ($k in @($machine.Keys)) { $cfg[$k] = $machine[$k] } }
    if ($cfg.isolatedLocalRepo) { $cfg.localRepo = Join-Path $work 'm2repo' }
    elseif (-not $cfg.localRepo) { $cfg.localRepo = Join-Path $HOME '.m2/repository' }
    $cfg.excludeDirs = @(@($cfg.excludeDirs) + $cfg.workDir | Where-Object { $_ })
    $target = "$($cfg.targetJdk)"; if (-not $target) { $target = '21' }
    $rulesFile = Join-Path $script:ToolRoot "rules/jdk$target-rules.json"
    if (-not (Test-Path -LiteralPath $rulesFile)) { $rulesFile = Join-Path $script:ToolRoot 'rules/jdk21-rules.json' }
    $rules = Read-JsonFile $rulesFile
    [pscustomobject]@{
        Repo = $repo; Config = $cfg; Rules = $rules; RulesFile = $rulesFile; Work = $work; Logs = $logs
        TargetJdk = $target; ToolRoot = (Resolve-Path -LiteralPath $script:ToolRoot).Path
    }
}

function Get-WorkFile($Ctx, [string]$Name) { Join-Path $Ctx.Work $Name }

function Get-State($Ctx) {
    $s = Read-JsonFile (Get-WorkFile $Ctx 'state.json')
    if (-not $s) { $s = @{ phases = @{} } }
    if (-not $s.phases) { $s.phases = @{} }
    $s
}

function Set-StateValue($Ctx, [string]$Key, $Value) {
    $s = Get-State $Ctx
    $s[$Key] = $Value
    Save-JsonFile $s (Get-WorkFile $Ctx 'state.json')
}

function Set-PhaseDone($Ctx, [string]$Phase, [string]$Status = 'done') {
    $s = Get-State $Ctx
    $s.phases[$Phase] = @{ status = $Status; at = (Get-Date).ToString('s') }
    Save-JsonFile $s (Get-WorkFile $Ctx 'state.json')
}

function Get-RelPath($Ctx, [string]$Path) {
    ([IO.Path]::GetRelativePath($Ctx.Repo, $Path)) -replace '\\', '/'
}

# ------------------------------------------------------------------ files
function Get-RepoFiles {
    param($Ctx, [scriptblock]$Filter)
    $ex = @($Ctx.Config.excludeDirs)
    $toolRoot = $Ctx.ToolRoot
    $agentsDir = Join-Path (Split-Path -Parent $toolRoot) 'agents'
    Get-ChildItem -LiteralPath $Ctx.Repo -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
        $full = $_.FullName
        if ($full.StartsWith($toolRoot, [StringComparison]::OrdinalIgnoreCase)) { return $false }
        if ($full.StartsWith($agentsDir, [StringComparison]::OrdinalIgnoreCase)) { return $false }
        $rel = Get-RelPath $Ctx $full
        foreach ($seg in $rel.Split('/')) { if ($ex -contains $seg) { return $false } }
        if ($Filter) { return [bool](& $Filter $_) }
        $true
    }
}

function Get-ModuleForFile($Models, [string]$FullPath) {
    $best = $null
    foreach ($m in $Models) {
        $prefix = $m.Dir.TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
        if ($FullPath.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            if (-not $best -or $m.Dir.Length -gt $best.Dir.Length) { $best = $m }
        }
    }
    $best
}

# ------------------------------------------------------------------ processes
# JDK roles: 'source' (current project JDK, alias '8') and 'target' (alias '21').
function Get-JdkHome($Ctx, [string]$Role) {
    if ($Role -in '8', 'source') { $h = $Ctx.Config.sourceJdkHome; if (-not $h) { $h = $Ctx.Config.jdk8Home } }
    elseif ($Role -in '21', 'target') { $h = $Ctx.Config.targetJdkHome; if (-not $h) { $h = $Ctx.Config.jdk21Home } }
    else { throw "Unknown JDK role '$Role'" }
    $h
}

function Use-Jdk($Ctx, [string]$Version) {
    $jdkHome = Get-JdkHome $Ctx $Version
    if (-not $jdkHome -or -not (Test-Path -LiteralPath $jdkHome)) { throw "JDK ($Version) not found at '$jdkHome'. Run the preflight/A00 phase or set sourceJdkHome/targetJdkHome." }
    $env:JAVA_HOME = $jdkHome
    $env:PATH = (Join-Path $jdkHome 'bin') + [IO.Path]::PathSeparator + $script:OrigPath
}

function Get-JdkTool($Ctx, [string]$Name, [string]$Version = '21') {
    $exe = Join-Path (Get-JdkHome $Ctx $Version) "bin/$Name"
    if ($IsWindows) { $exe += '.exe' }
    $exe
}

function Get-MavenCmd($Ctx) {
    $c = $Ctx.Config.mavenCmd
    if ($c -and $c -ne 'auto') { return $c }
    $wrapper = if ($IsWindows) { Join-Path $Ctx.Repo 'mvnw.cmd' } else { Join-Path $Ctx.Repo 'mvnw' }
    if (Test-Path -LiteralPath $wrapper) { return $wrapper }
    'mvn'
}

function Invoke-Maven {
    param($Ctx, [string]$Jdk, [string[]]$MvnArgs, [string]$LogName, [switch]$Quiet)
    Use-Jdk $Ctx $Jdk
    $all = @('-B', '-Dstyle.color=never')
    if ($Ctx.Config.isolatedLocalRepo) { $all += "-Dmaven.repo.local=$($Ctx.Config.localRepo)" }
    if ($Ctx.Config.mavenSettings) { $all += @('-s', $Ctx.Config.mavenSettings) }
    if ($Ctx.Config.mavenExtraArgs) { $all += @($Ctx.Config.mavenExtraArgs) }
    $all += $MvnArgs
    $log = Join-Path $Ctx.Logs $LogName
    $mvn = Get-MavenCmd $Ctx
    Write-Info "mvn $($MvnArgs -join ' ')   [JDK $Jdk, log: $(Get-RelPath $Ctx $log)]"
    Push-Location -LiteralPath $Ctx.Repo
    try {
        & $mvn @all 2>&1 | ForEach-Object { "$_" } | Tee-Object -FilePath $log | ForEach-Object {
            if (-not $Quiet -and $_ -match '^\[ERROR\]|BUILD (SUCCESS|FAILURE)|Tests run:.*(Failures: [1-9]|Errors: [1-9])|Reactor Summary') { Write-Host "      $_" }
        }
        $code = $LASTEXITCODE
    }
    finally { Pop-Location }
    return $code
}

function Invoke-Exe {
    param([string]$Exe, [string[]]$ExeArgs, [string]$LogPath, [string]$WorkingDir)
    if ($WorkingDir) { Push-Location -LiteralPath $WorkingDir }
    try {
        $out = @(& $Exe @ExeArgs 2>&1 | ForEach-Object { "$_" })
        $code = $LASTEXITCODE
    }
    finally { if ($WorkingDir) { Pop-Location } }
    if ($LogPath) { $out | Set-Content -LiteralPath $LogPath -Encoding utf8NoBOM }
    [pscustomobject]@{ ExitCode = $code; Lines = $out }
}

function Invoke-Git($Ctx, [string[]]$GitArgs) {
    $r = Invoke-Exe 'git' $GitArgs -WorkingDir $Ctx.Repo
    if ($r.ExitCode -ne 0) { throw "git $($GitArgs -join ' ') failed:`n$($r.Lines -join "`n")" }
    $r.Lines
}

function Save-Commit($Ctx, [string]$Message) {
    if (-not $Ctx.Config.autoCommit) { Write-Info 'autoCommit=false, leaving changes uncommitted'; return }
    Invoke-Git $Ctx @('add', '-A') | Out-Null
    $st = Invoke-Git $Ctx @('status', '--porcelain')
    if ($st) {
        Invoke-Git $Ctx @('commit', '-m', $Message) | Out-Null
        Write-Good "committed: $Message"
    }
}

# ------------------------------------------------------------------ copilot
# The task text is written to a file and Copilot is pointed at it. This keeps the
# command line short (no quoting / cmd.exe newline problems) and leaves an audit trail.
function Invoke-Copilot {
    param($Ctx, [string]$Agent, [string]$Task, [string[]]$WritablePaths, [string]$Name, $Options)
    if (Test-ChatMode $Ctx) { return (Invoke-ChatTask -Ctx $Ctx -Kind 'copilot' -Agent $Agent -Task $Task -WritablePaths $WritablePaths -Name $Name -Schema $null -Options $Options) }
    $cfg = $Ctx.Config
    $taskDir = Join-Path $Ctx.Work 'tasks'
    New-Item -ItemType Directory -Force -Path $taskDir | Out-Null
    $taskFile = Join-Path $taskDir "$Name.md"
    $body = $Task
    if (-not $cfg.useAgentFlag) {
        $agentFile = Join-Path (Split-Path -Parent $Ctx.ToolRoot) "agents/$Agent.agent.md"
        if (Test-Path -LiteralPath $agentFile) {
            $role = (Get-Content -LiteralPath $agentFile -Raw) -replace '(?s)^\s*---.*?---\s*', ''
            $body = "$role`n`n---`n`n$Task"
        }
    }
    Set-Content -LiteralPath $taskFile -Value $body -Encoding utf8NoBOM
    $taskRel = Get-RelPath $Ctx $taskFile
    $transcript = Join-Path $Ctx.Logs "$Name.transcript.md"
    $cli = @('-p', "Read the task file $taskRel and carry it out exactly. Do not modify the task file.")
    if ($cfg.useAgentFlag) { $cli += @('--agent', $Agent) }
    if ($cfg.copilotModel) { $cli += @('--model', $cfg.copilotModel) }
    foreach ($w in @($WritablePaths | Where-Object { $_ })) { $cli += @('--allow-tool', "write($w)") }
    if ($cfg.copilotExtraArgs) { $cli += @($cfg.copilotExtraArgs) }
    $cli += "--share=$transcript"
    $log = Join-Path $Ctx.Logs "$Name.log"
    Write-Info "copilot [$Agent] $Name  (may write: $(@($WritablePaths) -join ', '))"
    Push-Location -LiteralPath $Ctx.Repo
    try {
        & $cfg.copilotCmd @cli 2>&1 | ForEach-Object { "$_" } | Tee-Object -FilePath $log | ForEach-Object { Write-Host "      | $_" }
        $code = $LASTEXITCODE
    }
    finally { Pop-Location }
    $out = "$(if (Test-Path -LiteralPath $log) { Get-Content -LiteralPath $log -Raw })"
    $needs = @([regex]::Matches($out, '(?m)^\W*NEEDS-HUMAN:\s*(.+)$') |
        ForEach-Object { $_.Groups[1].Value.Trim() } | Where-Object { $_ -notmatch '<reason' } | Select-Object -Unique)
    [pscustomobject]@{ ExitCode = $code; NeedsHuman = $needs; Log = $log }
}

# ------------------------------------------------------------------ pom xml
function Read-Pom([string]$Path) {
    $bytes = [IO.File]::ReadAllBytes($Path)
    $bom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
    $text = [IO.File]::ReadAllText($Path)
    $x = New-Object System.Xml.XmlDocument
    $x.PreserveWhitespace = $true
    $x.LoadXml($text)
    [pscustomobject]@{ Path = $Path; Xml = $x; Crlf = $text.Contains("`r`n"); Bom = $bom }
}

function Save-Pom($Pom) {
    $settings = New-Object System.Xml.XmlWriterSettings
    $settings.Encoding = New-Object System.Text.UTF8Encoding($false)
    $settings.OmitXmlDeclaration = -not ($Pom.Xml.FirstChild -is [System.Xml.XmlDeclaration])
    $settings.NewLineHandling = [System.Xml.NewLineHandling]::None
    $ms = New-Object System.IO.MemoryStream
    $w = [System.Xml.XmlWriter]::Create($ms, $settings)
    try { $Pom.Xml.Save($w); $w.Flush() } finally { $w.Dispose() }
    $text = [Text.Encoding]::UTF8.GetString($ms.ToArray()) -replace "`r`n", "`n"
    if ($Pom.Crlf) { $text = $text -replace "`n", "`r`n" }
    [IO.File]::WriteAllText($Pom.Path, $text, (New-Object System.Text.UTF8Encoding($Pom.Bom)))
}

function Get-ChildText($El, [string]$Name) {
    if (-not $El) { return $null }
    $c = $El[$Name]
    if ($c) { return $c.InnerText.Trim() }
    $null
}

function Get-NodeContext($Node) {
    $parts = @()
    $p = $Node.ParentNode
    while ($p -and $p.NodeType -eq [System.Xml.XmlNodeType]::Element -and $p.LocalName -ne 'project') {
        $parts = @($p.LocalName) + $parts
        $p = $p.ParentNode
    }
    $parts -join '/'
}

function Get-ChildIndent($Parent) {
    $lastEl = $null
    foreach ($n in $Parent.ChildNodes) { if ($n.NodeType -eq [System.Xml.XmlNodeType]::Element) { $lastEl = $n } }
    $ws = @([System.Xml.XmlNodeType]::Whitespace, [System.Xml.XmlNodeType]::SignificantWhitespace)
    if ($lastEl -and $lastEl.PreviousSibling -and $ws -contains $lastEl.PreviousSibling.NodeType) {
        return "`n" + ($lastEl.PreviousSibling.Value -split "`n")[-1]
    }
    $pIndent = "`n"
    if ($Parent.PreviousSibling -and $ws -contains $Parent.PreviousSibling.NodeType) {
        $pIndent = "`n" + ($Parent.PreviousSibling.Value -split "`n")[-1]
    }
    $pIndent + '    '
}

function Add-XmlChild($Parent, $Child) {
    $doc = $Parent.OwnerDocument
    $indent = Get-ChildIndent $Parent
    $lastEl = $null
    foreach ($n in $Parent.ChildNodes) { if ($n.NodeType -eq [System.Xml.XmlNodeType]::Element) { $lastEl = $n } }
    if ($lastEl) {
        [void]$Parent.InsertAfter($Child, $lastEl)
        [void]$Parent.InsertBefore($doc.CreateWhitespace($indent), $Child)
    }
    else {
        $closing = $indent.Substring(0, [Math]::Max(1, $indent.Length - 4))
        foreach ($n in @($Parent.ChildNodes)) {
            if ($n.NodeType -in @([System.Xml.XmlNodeType]::Whitespace, [System.Xml.XmlNodeType]::SignificantWhitespace)) { [void]$Parent.RemoveChild($n) }
        }
        [void]$Parent.AppendChild($doc.CreateWhitespace($indent))
        [void]$Parent.AppendChild($Child)
        [void]$Parent.AppendChild($doc.CreateWhitespace($closing))
    }
}

function Resolve-XmlPath($Parent, [string[]]$Names) {
    $cur = $Parent
    foreach ($n in $Names) {
        $next = $cur[$n]
        if (-not $next) {
            $next = $cur.OwnerDocument.CreateElement($n, $cur.OwnerDocument.DocumentElement.NamespaceURI)
            Add-XmlChild $cur $next
        }
        $cur = $next
    }
    , $cur
}

function New-CoordElement($Doc, [string]$Kind, [string]$G, [string]$A, [string]$V, [string]$Scope, [string]$Indent) {
    $ns = $Doc.DocumentElement.NamespaceURI
    $el = $Doc.CreateElement($Kind, $ns)
    foreach ($pair in @(@('groupId', $G), @('artifactId', $A), @('version', $V), @('scope', $Scope))) {
        if (-not $pair[1]) { continue }
        [void]$el.AppendChild($Doc.CreateWhitespace($Indent + '    '))
        $c = $Doc.CreateElement($pair[0], $ns)
        $c.InnerText = $pair[1]
        [void]$el.AppendChild($c)
    }
    [void]$el.AppendChild($Doc.CreateWhitespace($Indent))
    , $el
}

function Set-PomProperty($Pom, [string]$Name, [string]$Value) {
    $props = Resolve-XmlPath $Pom.Xml.DocumentElement @('properties')
    $el = $props[$Name]
    if ($el) { $el.InnerText = $Value; return }
    $el = $Pom.Xml.CreateElement($Name, $Pom.Xml.DocumentElement.NamespaceURI)
    $el.InnerText = $Value
    Add-XmlChild $props $el
}

function Add-PomDependency($Pom, [string]$G, [string]$A, [string]$V, [string]$Scope) {
    $deps = Resolve-XmlPath $Pom.Xml.DocumentElement @('dependencies')
    foreach ($d in $deps.ChildNodes) {
        if ($d.NodeType -eq [System.Xml.XmlNodeType]::Element -and (Get-ChildText $d 'groupId') -eq $G -and (Get-ChildText $d 'artifactId') -eq $A) { return $false }
    }
    $el = New-CoordElement $Pom.Xml 'dependency' $G $A $V $Scope (Get-ChildIndent $deps)
    Add-XmlChild $deps $el
    $true
}

# Adds or updates a dependencyManagement / pluginManagement entry (used to pin
# versions that come from external parents, BOMs, the super-POM or transitives).
function Set-PomManaged($Pom, [string]$Kind, [string]$G, [string]$A, [string]$V) {
    $path = if ($Kind -eq 'plugin') { @('build', 'pluginManagement', 'plugins') } else { @('dependencyManagement', 'dependencies') }
    $container = Resolve-XmlPath $Pom.Xml.DocumentElement $path
    foreach ($e in $container.ChildNodes) {
        if ($e.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }
        $g = Get-ChildText $e 'groupId'
        if (-not $g -and $Kind -eq 'plugin') { $g = 'org.apache.maven.plugins' }
        if ($g -ne $G -or (Get-ChildText $e 'artifactId') -ne $A) { continue }
        $ve = $e['version']
        if (-not $ve) {
            $ve = $Pom.Xml.CreateElement('version', $Pom.Xml.DocumentElement.NamespaceURI)
            Add-XmlChild $e $ve
        }
        $m = [regex]::Match($ve.InnerText.Trim(), '^\$\{([^}]+)\}$')
        if ($m.Success) { Set-PomProperty $Pom $m.Groups[1].Value $V } else { $ve.InnerText = $V }
        return 'updated'
    }
    $el = New-CoordElement $Pom.Xml $Kind $G $A $V $null (Get-ChildIndent $container)
    Add-XmlChild $container $el
    'added'
}

function Set-InlineVersion($Pom, [string]$Kind, [string]$G, [string]$A, [string]$Raw, [string]$To) {
    $count = 0
    foreach ($n in $Pom.Xml.SelectNodes("//*[local-name()='$Kind']")) {
        $g = Get-ChildText $n 'groupId'
        if (-not $g -and $Kind -eq 'plugin') { $g = 'org.apache.maven.plugins' }
        if ($g -ne $G -or (Get-ChildText $n 'artifactId') -ne $A) { continue }
        $v = $n['version']
        if ($v -and $v.InnerText.Trim() -eq $Raw) { $v.InnerText = $To; $count++ }
    }
    $count
}

# ------------------------------------------------------------------ pom model
function Get-PomModels($Ctx) {
    $models = [System.Collections.Generic.List[object]]::new()
    foreach ($f in @(Get-RepoFiles $Ctx { param($f) $f.Name -eq 'pom.xml' })) {
        $pom = Read-Pom $f.FullName
        $p = $pom.Xml.DocumentElement
        $parentEl = $p['parent']
        $pg = Get-ChildText $parentEl 'groupId'
        $pa = Get-ChildText $parentEl 'artifactId'
        $pv = Get-ChildText $parentEl 'version'
        $gid = Get-ChildText $p 'groupId'; if (-not $gid) { $gid = $pg }
        $ver = Get-ChildText $p 'version'; if (-not $ver) { $ver = $pv }
        $props = @{}
        $pe = $p['properties']
        if ($pe) { foreach ($n in $pe.ChildNodes) { if ($n.NodeType -eq [System.Xml.XmlNodeType]::Element) { $props[$n.LocalName] = $n.InnerText.Trim() } } }
        $pack = Get-ChildText $p 'packaging'; if (-not $pack) { $pack = 'jar' }
        $models.Add([pscustomobject]@{
                Path = $f.FullName; Dir = $f.DirectoryName; Rel = (Get-RelPath $Ctx $f.FullName)
                GroupId = $gid; ArtifactId = (Get-ChildText $p 'artifactId'); Version = $ver; Packaging = $pack
                ParentKey = $(if ($parentEl) { "${pg}:${pa}" } else { $null }); ParentVersion = $pv
                Properties = $props; Pom = $pom; InRepoParent = $null
            })
    }
    $byKey = @{}
    foreach ($m in $models) { $byKey["$($m.GroupId):$($m.ArtifactId)"] = $m }
    foreach ($m in $models) { if ($m.ParentKey -and $byKey.ContainsKey($m.ParentKey)) { $m.InRepoParent = $byKey[$m.ParentKey] } }
    $models.ToArray()
}

function Resolve-PomValue($Model, [string]$Value, [int]$Depth = 0) {
    if (-not $Value -or $Depth -gt 10) { return @{ Value = $Value; PropertyName = $null; PropertyPom = $null } }
    $m = [regex]::Match($Value, '^\$\{([^}]+)\}$')
    if (-not $m.Success) {
        if ($Value -match '\$\{') { return @{ Value = $null; PropertyName = $null; PropertyPom = $null; Complex = $true } }
        return @{ Value = $Value; PropertyName = $null; PropertyPom = $null }
    }
    $name = $m.Groups[1].Value
    if ($name -in 'project.version', 'pom.version', 'version') { return @{ Value = $Model.Version; PropertyName = $null; PropertyPom = $null } }
    if ($name -in 'project.parent.version', 'parent.version') { return @{ Value = $Model.ParentVersion; PropertyName = $null; PropertyPom = $null } }
    if ($name -in 'project.groupId', 'pom.groupId', 'groupId') { return @{ Value = $Model.GroupId; PropertyName = $null; PropertyPom = $null } }
    $cur = $Model
    while ($cur) {
        if ($cur.Properties.ContainsKey($name)) {
            $inner = Resolve-PomValue $cur $cur.Properties[$name] ($Depth + 1)
            if ($inner.PropertyName) { return $inner }
            return @{ Value = $inner.Value; PropertyName = $name; PropertyPom = $cur.Rel }
        }
        $cur = $cur.InRepoParent
    }
    @{ Value = $null; PropertyName = $name; PropertyPom = $null }   # defined in an external parent/BOM
}

function Get-PomItems($Models) {
    $reactor = @{}
    foreach ($m in $Models) { $reactor["$($m.GroupId):$($m.ArtifactId)"] = $true }
    foreach ($m in $Models) {
        $root = $m.Pom.Xml.DocumentElement
        foreach ($n in $m.Pom.Xml.SelectNodes("//*[local-name()='dependency' or local-name()='plugin' or local-name()='parent']")) {
            $kind = $n.LocalName
            if ($kind -eq 'parent' -and -not [object]::ReferenceEquals($n.ParentNode, $root)) { continue }
            $g = Get-ChildText $n 'groupId'
            if (-not $g -and $kind -eq 'plugin') { $g = 'org.apache.maven.plugins' }
            if ($g -and $g -match '^\$\{') { $g = (Resolve-PomValue $m $g).Value }
            $a = Get-ChildText $n 'artifactId'
            if (-not $g -or -not $a) { continue }
            if ($reactor.ContainsKey("${g}:${a}")) { continue }
            $raw = Get-ChildText $n 'version'
            $res = if ($raw) { Resolve-PomValue $m $raw } else { @{ Value = $null; PropertyName = $null; PropertyPom = $null } }
            [pscustomobject]@{
                Pom = $m.Rel; Kind = $kind; Context = (Get-NodeContext $n); GroupId = $g; ArtifactId = $a
                RawVersion = $raw; Version = $res.Value; PropertyName = $res.PropertyName; PropertyPom = $res.PropertyPom
                Scope = (Get-ChildText $n 'scope'); Type = (Get-ChildText $n 'type')
            }
        }
    }
}

# ------------------------------------------------------------------ versions
function ConvertTo-VersionTokens([string]$V) {
    $v = $V.ToLowerInvariant() -replace '[-_.](final|ga|release|jre)$', ''
    @([regex]::Matches($v, '\d+|[a-z]+') | ForEach-Object { $_.Value })
}

function Get-QualifierRank([string]$Q) {
    $order = @{ alpha = 1; a = 1; beta = 2; b = 2; milestone = 3; m = 3; rc = 4; cr = 4; snapshot = 5; sp = 7 }
    if ($order.ContainsKey($Q)) { return $order[$Q] }
    8
}

# Returns -1, 0, 1 (Maven-like ordering, good enough for upgrade decisions)
function Compare-MavenVersion([string]$A, [string]$B) {
    if (-not $A -and -not $B) { return 0 }; if (-not $A) { return -1 }; if (-not $B) { return 1 }
    $ta = @(ConvertTo-VersionTokens $A); $tb = @(ConvertTo-VersionTokens $B)
    $n = [Math]::Max($ta.Count, $tb.Count)
    for ($i = 0; $i -lt $n; $i++) {
        $x = if ($i -lt $ta.Count) { $ta[$i] } else { $null }
        $y = if ($i -lt $tb.Count) { $tb[$i] } else { $null }
        if ($x -eq $y) { continue }
        if ($null -eq $x) {
            if ($y -match '^0+$') { continue }
            if ($y -match '^\d+$') { return -1 }
            return $(if ((Get-QualifierRank $y) -gt 6) { -1 } else { 1 })
        }
        if ($null -eq $y) {
            if ($x -match '^0+$') { continue }
            if ($x -match '^\d+$') { return 1 }
            return $(if ((Get-QualifierRank $x) -gt 6) { 1 } else { -1 })
        }
        $xn = $x -match '^\d+$'; $yn = $y -match '^\d+$'
        if ($xn -and $yn) {
            $c = ([System.Numerics.BigInteger]::Parse($x)).CompareTo([System.Numerics.BigInteger]::Parse($y))
            if ($c -ne 0) { return [Math]::Sign($c) }
            continue
        }
        if ($xn) { return 1 }
        if ($yn) { return -1 }
        $rx = Get-QualifierRank $x; $ry = Get-QualifierRank $y
        if ($rx -ne $ry) { return [Math]::Sign($rx - $ry) }
        $c = [string]::CompareOrdinal($x, $y)
        if ($c -ne 0) { return [Math]::Sign($c) }
    }
    0
}

function Get-MaxVersion([string[]]$Versions) {
    $best = $null
    foreach ($v in $Versions) {
        if (-not $v) { continue }
        if (-not $best -or (Compare-MavenVersion $v $best) -gt 0) { $best = $v }
    }
    $best
}

function Get-MinVersion([string[]]$Versions) {
    $best = $null
    foreach ($v in $Versions) {
        if (-not $v) { continue }
        if (-not $best -or (Compare-MavenVersion $v $best) -lt 0) { $best = $v }
    }
    $best
}

function Get-Major([string]$V) { $t = @(ConvertTo-VersionTokens $V); if ($t.Count) { $t[0] } else { '' } }

# ------------------------------------------------------------------ build outputs
function Get-ResolvedDeps([string]$Path) {
    $map = @{}
    if (-not (Test-Path -LiteralPath $Path)) { return $map }
    foreach ($line in Get-Content -LiteralPath $Path) {
        $t = ($line -replace '\s--\s.*$', '' -replace '\s*\(.*\)\s*$', '').Trim()
        if ($t -notmatch '^[\w.\-]+:[\w.\-]+:') { continue }
        $p = $t.Split(':')
        if ($p.Count -lt 5) { continue }
        $k = "$($p[0]):$($p[1])"
        $v = $p[$p.Count - 2]
        if (-not $map.ContainsKey($k)) { $map[$k] = @() }
        if ($map[$k] -notcontains $v) { $map[$k] += $v }
    }
    $map
}

function Get-TestResults($Ctx) {
    $results = @{}
    $files = Get-ChildItem -LiteralPath $Ctx.Repo -Recurse -File -Filter 'TEST-*.xml' -ErrorAction SilentlyContinue |
        Where-Object { $_.DirectoryName -match '[\\/](surefire|failsafe)-reports$' -and $_.FullName -notmatch '[\\/]node_modules[\\/]' }
    foreach ($f in $files) {
        try { $x = New-Object System.Xml.XmlDocument; $x.Load($f.FullName) } catch { continue }
        foreach ($tc in $x.SelectNodes('//testcase')) {
            $key = "$($tc.GetAttribute('classname'))#$($tc.GetAttribute('name'))"
            $status = 'pass'; $msg = $null
            $fail = $tc.SelectSingleNode('failure'); $err = $tc.SelectSingleNode('error'); $skip = $tc.SelectSingleNode('skipped')
            $node = $null
            if ($fail) { $status = 'fail'; $node = $fail } elseif ($err) { $status = 'error'; $node = $err } elseif ($skip) { $status = 'skipped' }
            if ($node) {
                $msg = "$($node.GetAttribute('type')): $($node.GetAttribute('message'))`n$($node.InnerText)"
                if ($msg.Length -gt 4000) { $msg = $msg.Substring(0, 4000) }
            }
            $results[$key] = @{ status = $status; message = $msg; className = $tc.GetAttribute('classname') }
        }
    }
    $results
}

function Get-TestSummary($Results) {
    $s = @{ total = 0; pass = 0; fail = 0; error = 0; skipped = 0 }
    foreach ($r in $Results.Values) { $s.total++; $s[$r.status]++ }
    $s
}

function Get-CompileErrors([string]$LogPath, $Ctx) {
    $errs = [ordered]@{}
    $lastKey = $null
    foreach ($line in Get-Content -LiteralPath $LogPath) {
        $m = [regex]::Match($line, '^\[ERROR\]\s+(.+?\.java):\[(\d+)(?:,(\d+))?\]\s*(.*)$')
        if ($m.Success) {
            $file = $m.Groups[1].Value
            if ($file -match '^/[A-Za-z]:[/\\]') { $file = $file.Substring(1) }
            $rel = Get-RelPath $Ctx $file
            if (-not $errs.Contains($rel)) { $errs[$rel] = [System.Collections.Generic.List[string]]::new() }
            $txt = "line $($m.Groups[2].Value): $($m.Groups[4].Value.Trim())"
            if (-not $errs[$rel].Contains($txt)) { $errs[$rel].Add($txt); $lastKey = $rel } else { $lastKey = $null }
            continue
        }
        $d = [regex]::Match($line, '^\[ERROR\]\s{2,}(symbol|location|required|found|reason)\s*:\s*(.*)$')
        if ($d.Success -and $lastKey) {
            $list = $errs[$lastKey]
            $list[$list.Count - 1] = $list[$list.Count - 1] + " | $($d.Groups[1].Value): $($d.Groups[2].Value.Trim())"
            continue
        }
        if ($line -notmatch '^\[ERROR\]\s{2,}') { $lastKey = $null }
    }
    $errs
}

function Get-JarClassMajor([string]$Jar) {
    foreach ($asm in 'System.IO.Compression', 'System.IO.Compression.FileSystem', 'System.IO.Compression.ZipFile') { try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch { } }
    $z = [IO.Compression.ZipFile]::OpenRead($Jar)
    try {
        $max = 0; $checked = 0
        foreach ($e in $z.Entries) {
            if ($e.FullName -notlike '*.class' -or $e.FullName -like 'META-INF/versions/*' -or $e.Name -eq 'module-info.class') { continue }
            $s = $e.Open()
            try {
                $b = New-Object byte[] 8; $read = 0
                while ($read -lt 8) { $n = $s.Read($b, $read, 8 - $read); if ($n -le 0) { break }; $read += $n }
            }
            finally { $s.Dispose() }
            if ($read -eq 8 -and $b[0] -eq 0xCA -and $b[1] -eq 0xFE) {
                $major = [int]$b[6] * 256 + [int]$b[7]
                if ($major -gt $max) { $max = $major }
            }
            $checked++
            if ($checked -ge 60) { break }
        }
        if ($max) { return "Java $($max - 44)" }
        $null
    }
    finally { $z.Dispose() }
}

function Get-SafeName([string]$S) {
    $n = $S -replace '[\\/:*?"<>| ]', '_'
    if ($n.Length -gt 110) { $n = $n.Substring($n.Length - 110) }
    $n
}

# ================================================================== v2: JDK detection
function ConvertTo-JavaFeature([string]$V) {
    if (-not $V) { return $null }
    $v = $V.Trim().Trim('"')
    if ($v -match '^1\.(\d+)') { return [int]$Matches[1] }
    if ($v -match '^(\d+)') { return [int]$Matches[1] }
    $null
}

function Get-JdkVersionFromHome([string]$JdkHome) {
    $rel = Join-Path $JdkHome 'release'
    if (Test-Path -LiteralPath $rel) {
        $m = Select-String -LiteralPath $rel -Pattern '^JAVA_VERSION="([^"]+)"' | Select-Object -First 1
        if ($m) { return $m.Matches[0].Groups[1].Value }
    }
    $null
}

# Installed JDKs: Maven toolchains.xml, JAVA_HOME, common vendor folders, config jdkSearchRoots
function Find-Jdks($Ctx) {
    $cands = [System.Collections.Generic.List[string]]::new()
    $tc = Join-Path $HOME '.m2/toolchains.xml'
    if (Test-Path -LiteralPath $tc) {
        try { $x = New-Object System.Xml.XmlDocument; $x.Load($tc); foreach ($n in $x.SelectNodes("//*[local-name()='jdkHome']")) { $cands.Add($n.InnerText.Trim()) } } catch { }
    }
    if ($env:JAVA_HOME) { $cands.Add($env:JAVA_HOME) }
    $roots = if ($IsWindows) {
        @("$env:ProgramFiles\Java", "$env:ProgramFiles\Eclipse Adoptium", "$env:ProgramFiles\Amazon Corretto", "$env:ProgramFiles\Zulu",
            "$env:ProgramFiles\Microsoft", "$env:ProgramFiles\OpenJDK", "$env:ProgramFiles\Semeru", "$env:ProgramFiles\BellSoft",
            'C:\Java', 'D:\Java', 'C:\tools', 'D:\tools', (Join-Path $HOME '.jdks'))
    }
    else { @('/usr/lib/jvm', '/Library/Java/JavaVirtualMachines', '/opt/java', (Join-Path $HOME '.sdkman/candidates/java'), (Join-Path $HOME '.jdks')) }
    $roots += @($Ctx.Config.jdkSearchRoots | Where-Object { $_ })
    foreach ($r in $roots) {
        if (-not $r -or -not (Test-Path -LiteralPath $r)) { continue }
        foreach ($d in Get-ChildItem -LiteralPath $r -Directory -ErrorAction SilentlyContinue) { $cands.Add($d.FullName); $cands.Add((Join-Path $d.FullName 'Contents/Home')) }
    }
    $seen = @{}
    foreach ($c in $cands) {
        if (-not $c -or -not (Test-Path -LiteralPath $c)) { continue }
        $full = (Resolve-Path -LiteralPath $c).Path
        if ($seen.ContainsKey($full)) { continue }
        $seen[$full] = $true
        $javac = Join-Path $full ('bin/javac' + $(if ($IsWindows) { '.exe' } else { '' }))
        if (-not (Test-Path -LiteralPath $javac)) { continue }      # JDKs only, no JREs
        $ver = Get-JdkVersionFromHome $full
        [pscustomobject]@{ Home = $full; Version = $ver; Feature = (ConvertTo-JavaFeature $ver) }
    }
}

# Current Java level from the project itself (properties, compiler plugin, enforcer)
function Get-ProjectJavaLevel($Ctx, $Models) {
    $evidence = [System.Collections.Generic.List[object]]::new()
    $props = @($Ctx.Rules.javaVersionProperties)
    foreach ($m in $Models) {
        foreach ($k in @($m.Properties.Keys)) {
            if ($props -notcontains $k) { continue }
            $v = (Resolve-PomValue $m $m.Properties[$k]).Value
            $f = ConvertTo-JavaFeature $v
            if ($f) { $evidence.Add(@{ source = "$($m.Rel) property $k"; value = $v; feature = $f }) }
        }
        foreach ($pl in @($m.Pom.Xml.SelectNodes("//*[local-name()='plugin']"))) {
            if ((Get-ChildText $pl 'artifactId') -ne 'maven-compiler-plugin') { continue }
            foreach ($cfgEl in @($pl.SelectNodes(".//*[local-name()='configuration']"))) {
                foreach ($nm in 'release', 'source', 'target') {
                    $raw = Get-ChildText $cfgEl $nm
                    if (-not $raw) { continue }
                    $v = (Resolve-PomValue $m $raw).Value
                    $f = ConvertTo-JavaFeature $v
                    if ($f) { $evidence.Add(@{ source = "$($m.Rel) maven-compiler-plugin <$nm>"; value = $v; feature = $f }) }
                }
            }
        }
    }
    $level = $null
    foreach ($e in $evidence) { if (-not $level -or $e.feature -gt $level) { $level = $e.feature } }
    @{ feature = $level; evidence = @($evidence) }
}

function Save-MachineConfig($Ctx, [string]$Key, $Value) {
    $file = Join-Path $Ctx.Work 'machine.json'
    $m = Read-JsonFile $file
    if (-not $m) { $m = @{} }
    $m[$Key] = $Value
    Save-JsonFile $m $file
    $Ctx.Config[$Key] = $Value
}

# Detect source level, find/select source + target JDK homes, ask the user only if needed.
function Resolve-JdkHomes($Ctx) {
    $nonInt = $env:JDKMIG_NONINTERACTIVE -eq '1'
    $models = @(Get-PomModels $Ctx)
    $lvl = Get-ProjectJavaLevel $Ctx $models
    $src = if ($Ctx.Config.sourceJdk -and "$($Ctx.Config.sourceJdk)" -ne 'auto') { [int]$Ctx.Config.sourceJdk } else { $lvl.feature }
    if (-not $src) {
        if ($nonInt) { throw 'Project Java level could not be detected; set "sourceJdk" in .jdk21-migration.json.' }
        $src = [int](Read-Host '    Project Java level could not be detected. Current Java version of this project (e.g. 8)')
    }
    $tgt = [int]$Ctx.TargetJdk
    if ($src -ge $tgt) { throw "Project is already on Java $src; target is $tgt." }
    $jdks = @(Find-Jdks $Ctx)
    $result = @{ sourceFeature = $src; targetFeature = $tgt; evidence = $lvl.evidence; installed = @($jdks | ForEach-Object { "$($_.Version) @ $($_.Home)" }) }
    foreach ($role in 'source', 'target') {
        $key = "${role}JdkHome"
        $want = if ($role -eq 'source') { $src } else { $tgt }
        $current = Get-JdkHome $Ctx $role
        if ($current -and (Test-Path -LiteralPath (Join-Path $current 'bin'))) { $result[$key] = $current; continue }
        $match = @($jdks | Where-Object { $_.Feature -eq $want })
        if (-not $match.Count -and $role -eq 'source') { $match = @($jdks | Where-Object { $_.Feature -gt $src -and $_.Feature -lt $tgt } | Sort-Object Feature | Select-Object -First 1) }
        $chosen = $null
        if ($match.Count -eq 1 -or ($match.Count -gt 1 -and $nonInt)) {
            $best = $match[0]; foreach ($j in $match) { if ((Compare-MavenVersion $j.Version $best.Version) -gt 0) { $best = $j } }
            $chosen = $best.Home
        }
        elseif ($match.Count -gt 1) {
            Write-Host "    Several JDK $want installations found:"
            for ($i = 0; $i -lt $match.Count; $i++) { Write-Host "      [$i] $($match[$i].Version)  $($match[$i].Home)" }
            $chosen = $match[[int](Read-Host "    Choose JDK $want [0-$($match.Count - 1)]")].Home
        }
        else {
            if ($nonInt) { throw "No JDK $want found. Install it, add its parent folder to jdkSearchRoots, or set $key." }
            $chosen = (Read-Host "    JDK $want not found automatically. Path of its install folder (contains bin/javac)").Trim('"', ' ')
        }
        if (-not (Test-Path -LiteralPath (Join-Path $chosen 'bin'))) { throw "'$chosen' is not a JDK home." }
        $f = ConvertTo-JavaFeature (Get-JdkVersionFromHome $chosen)
        if ($role -eq 'target' -and $f -and $f -ne $tgt) { throw "JDK at '$chosen' is Java $f, expected $tgt." }
        Save-MachineConfig $Ctx $key $chosen
        $result[$key] = $chosen
        Write-Info "$role JDK: $chosen"
    }
    $result
}

# ================================================================== v2: company Maven repository policy
function Get-SettingsFiles($Ctx) {
    $files = @()
    if ($Ctx.Config.mavenSettings) { $files += $Ctx.Config.mavenSettings } else { $files += (Join-Path $HOME '.m2/settings.xml') }
    foreach ($mh in @($env:MAVEN_HOME, $env:M2_HOME)) { if ($mh) { $files += (Join-Path $mh 'conf/settings.xml') } }
    @($files | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -Unique)
}

# Parses settings.xml + poms (no network). enforced = a catch-all mirror (*) points to an allowed host
# and no repository escapes it.
function Get-MavenRepoPolicy($Ctx, $Models) {
    $allowed = @($Ctx.Config.allowedRepoHosts | Where-Object { $_ })
    $mirrors = [System.Collections.Generic.List[object]]::new()
    $repos = [System.Collections.Generic.List[object]]::new()
    function Get-HostOf([string]$U) { try { ([uri]$U).Host.ToLowerInvariant() } catch { $U } }
    $settingsFiles = @(Get-SettingsFiles $Ctx)
    foreach ($f in $settingsFiles) {
        $x = New-Object System.Xml.XmlDocument
        try { $x.Load($f) } catch { continue }
        foreach ($m in $x.SelectNodes("//*[local-name()='mirror']")) {
            $mirrors.Add(@{ id = (Get-ChildText $m 'id'); url = (Get-ChildText $m 'url'); mirrorOf = (Get-ChildText $m 'mirrorOf'); file = $f })
        }
        foreach ($r in $x.SelectNodes("//*[local-name()='repository' or local-name()='pluginRepository']")) {
            $repos.Add(@{ id = (Get-ChildText $r 'id'); url = (Get-ChildText $r 'url'); source = $f })
        }
    }
    foreach ($m in $Models) {
        foreach ($r in $m.Pom.Xml.SelectNodes("//*[local-name()='repositories' or local-name()='pluginRepositories']/*")) {
            if ($r.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }
            $repos.Add(@{ id = (Get-ChildText $r 'id'); url = (Get-ChildText $r 'url'); source = $m.Rel })
        }
    }
    $violations = [System.Collections.Generic.List[string]]::new()
    $notes = [System.Collections.Generic.List[string]]::new()
    $catchAll = @($mirrors | Where-Object { @(($_.mirrorOf -split ',') | ForEach-Object { $_.Trim() } | Where-Object { $_ -in '*', 'external:*' }).Count })
    $excludedIds = @($catchAll | ForEach-Object { ($_.mirrorOf -split ',') | ForEach-Object { $_.Trim() } | Where-Object { $_.StartsWith('!') } | ForEach-Object { $_.Substring(1) } })
    if ($allowed.Count) {
        foreach ($m in $mirrors) { if ((Get-HostOf $m.url) -notin $allowed) { $violations.Add("mirror '$($m.id)' -> $($m.url) is not an allowed host ($($m.file))") } }
        foreach ($r in $repos) {
            if ((Get-HostOf $r.url) -in $allowed) { continue }
            if ($catchAll.Count -and $excludedIds -notcontains $r.id) { $notes.Add("repository '$($r.id)' ($($r.url)) in $($r.source) is redirected by the catch-all mirror") }
            else { $violations.Add("repository '$($r.id)' -> $($r.url) in $($r.source) bypasses the company mirror") }
        }
        if (-not $catchAll.Count) { $violations.Add('no catch-all <mirrorOf>*</mirrorOf> mirror - Maven can reach public repositories directly') }
    }
    $status = if (-not $allowed.Count) { 'not-configured' } elseif ($violations.Count) { 'not-enforced' } else { 'enforced' }
    @{ status = $status; allowedHosts = $allowed; settingsFiles = $settingsFiles; mirrors = @($mirrors); repositories = @($repos); violations = @($violations); notes = @($notes) }
}

function Assert-RepoPolicy($Ctx, $Policy) {
    if (-not $Ctx.Config.enforceCompanyRepo) { return }
    if ($Policy.status -eq 'enforced') { Write-Good "Maven traffic restricted to: $($Policy.allowedHosts -join ', ')"; return }
    if ($Policy.status -eq 'not-configured') { throw 'enforceCompanyRepo=true but allowedRepoHosts is empty. Add your Nexus/Artifactory host(s) to .jdk21-migration.json.' }
    throw ("Company-repository policy NOT enforced:`n - " + ($Policy.violations -join "`n - ") + "`nFix settings.xml / poms, or set enforceCompanyRepo=false (not recommended).")
}

# Is g:a:v resolvable through the configured (company) repositories? Downloads into local repo.
function Test-ArtifactAvailable($Ctx, [string]$G, [string]$A, [string]$V) {
    foreach ($pk in 'jar', 'pom') {
        $art = if ($pk -eq 'jar') { "${G}:${A}:${V}" } else { "${G}:${A}:${V}:pom" }
        $code = Invoke-Maven $Ctx 'source' @('-q', 'dependency:get', "-Dartifact=$art", '-Dtransitive=false') ("avail-" + (Get-SafeName $art) + '.log') -Quiet
        if ($code -eq 0) { return $pk }
    }
    $null
}

# Java level a jar needs (class file version) and whether it is jakarta- or javax-EE based
function Get-JarJavaInfo([string]$Jar) {
    foreach ($asm in 'System.IO.Compression', 'System.IO.Compression.FileSystem', 'System.IO.Compression.ZipFile') { try { Add-Type -AssemblyName $asm -ErrorAction Stop } catch { } }
    $z = [IO.Compression.ZipFile]::OpenRead($Jar)
    try {
        $max = 0; $jak = $false; $jx = $false; $n = 0
        foreach ($e in $z.Entries) {
            if ($e.FullName -notlike '*.class' -or $e.FullName -like 'META-INF/versions/*' -or $e.Name -eq 'module-info.class') { continue }
            $s = $e.Open(); $ms = New-Object System.IO.MemoryStream
            try { $s.CopyTo($ms) } finally { $s.Dispose() }
            $b = $ms.ToArray()
            if ($b.Length -ge 8 -and $b[0] -eq 0xCA -and $b[1] -eq 0xFE) { $major = [int]$b[6] * 256 + [int]$b[7]; if ($major -gt $max) { $max = $major } }
            $txt = [Text.Encoding]::Latin1.GetString($b)
            if (-not $jak -and $txt.Contains('jakarta/')) { $jak = $true }
            if (-not $jx -and $txt -match 'javax/(servlet|persistence|ws/rs|validation|inject|transaction|xml/bind|ejb|faces|jms|el)/') { $jx = $true }
            $n++; if ($n -ge 400) { break }
        }
        @{ javaFeature = $(if ($max) { $max - 44 } else { $null }); usesJakarta = $jak; usesJavaxEE = $jx }
    }
    finally { $z.Dispose() }
}

function Get-LocalJar($Ctx, [string]$G, [string]$A, [string]$V) {
    Join-Path $Ctx.Config.localRepo ((($G -replace '\.', '/')) + "/$A/$V/$A-$V.jar")
}

# ================================================================== v2: Checkmarx (SARIF)
function Read-Sarif([string]$Path) {
    $j = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json -AsHashtable
    $levelMap = @{ error = 'high'; warning = 'medium'; note = 'low'; none = 'info' }
    foreach ($run in @($j.runs)) {
        if (-not $run) { continue }
        $rules = @{}
        foreach ($r in @($run.tool.driver.rules)) { if ($r -and $r.id) { $rules[$r.id] = $r } }
        foreach ($res in @($run.results)) {
            if (-not $res) { continue }
            $loc = @($res.locations)[0]
            $rule = $rules[$res.ruleId]
            $sev = $res.properties.severity
            if (-not $sev -and $rule) { $sev = $rule.properties.severity }
            if (-not $sev) { $sev = $levelMap["$($res.level)"] }
            $msg = "$($res.message.text)"
            $file = "$($loc.physicalLocation.artifactLocation.uri)"
            $f = @{ tool = "$($run.tool.driver.name)"; ruleId = $res.ruleId; ruleName = $(if ($rule) { $rule.name } else { $null })
                severity = "$sev".ToLowerInvariant(); message = $(if ($msg.Length -gt 600) { $msg.Substring(0, 600) } else { $msg })
                file = $file; line = $loc.physicalLocation.region.startLine; type = 'sast' }
            $pm = [regex]::Match($msg, '(?<g>[A-Za-z][\w.\-]*\.[\w.\-]+):(?<a>[\w.\-]+)[:@ ]v?(?<v>\d[\w.\-]*)')
            if (($file -match '(pom\.xml|\.jar)$') -or ($pm.Success -and ($msg -match '(?i)\b(CVE-|package|dependency|library|component)'))) {
                $f.type = 'sca'
                if ($pm.Success) { $f.package = "$($pm.Groups['g'].Value):$($pm.Groups['a'].Value)"; $f.version = $pm.Groups['v'].Value }
                $fx = [regex]::Match($msg, '(?i)(recommended|fixed in|upgrade to|fix version)[^\d]{0,30}(\d[\w.\-]*)')
                if ($fx.Success) { $f.fixVersion = $fx.Groups[2].Value }
            }
            $f
        }
    }
}

# Runs the Checkmarx CLI with the configured argument template (or imports an existing SARIF).
# Credentials only from environment variables listed in checkmarx.requiredEnv - never from files.
function Invoke-CheckmarxScan($Ctx, [string]$OutName) {
    $cx = $Ctx.Config.checkmarx
    $out = Get-WorkFile $Ctx $OutName
    $skip = { param($reason) Save-JsonFile @{ skipped = $true; reason = $reason; findings = @() } $out; Write-Warn2 "Checkmarx skipped: $reason"; Read-JsonFile $out }
    if (-not $cx -or -not $cx.enabled) { return (& $skip 'checkmarx.enabled=false') }
    $sarif = $null
    if ($cx.importSarif) {
        $sarif = if ([IO.Path]::IsPathRooted($cx.importSarif)) { $cx.importSarif } else { Join-Path $Ctx.Repo $cx.importSarif }
        if (-not (Test-Path -LiteralPath $sarif)) { return (& $skip "importSarif not found: $sarif") }
    }
    else {
        $missing = @($cx.requiredEnv | Where-Object { $_ -and -not [Environment]::GetEnvironmentVariable($_) })
        if ($missing.Count) { return (& $skip "missing environment variable(s): $($missing -join ', ')") }
        if (-not (Get-Command $cx.cmd -ErrorAction SilentlyContinue)) { return (& $skip "CLI '$($cx.cmd)' not found") }
        $outDir = Join-Path $Ctx.Work 'checkmarx'
        New-Item -ItemType Directory -Force -Path $outDir | Out-Null
        $name = ($OutName -replace '\.json$', '') + '-' + (Get-Date -Format 'yyyyMMddHHmmss')
        $project = if ($cx.projectName) { $cx.projectName } else { Split-Path -Leaf $Ctx.Repo }
        $branch = try { (Invoke-Git $Ctx @('rev-parse', '--abbrev-ref', 'HEAD')) | Select-Object -First 1 } catch { 'main' }
        $cxArgs = @($cx.args | ForEach-Object { "$_".Replace('{project}', $project).Replace('{branch}', $branch).Replace('{outDir}', $outDir).Replace('{outName}', $name).Replace('{repo}', $Ctx.Repo) })
        Write-Info "checkmarx: $($cx.cmd) $($cx.args -join ' ')"
        $r = Invoke-Exe $cx.cmd $cxArgs -WorkingDir $Ctx.Repo -LogPath (Join-Path $Ctx.Logs "$name.log")
        $sarif = Get-ChildItem -LiteralPath $outDir -Filter '*.sarif' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1 | ForEach-Object { $_.FullName }
        if (-not $sarif) { return (& $skip "no SARIF produced (exit $($r.ExitCode)) - see logs/$name.log") }
    }
    $findings = @(Read-Sarif $sarif)
    Save-JsonFile @{ skipped = $false; source = $sarif; findings = $findings } $out
    Write-Info "Checkmarx: $(@($findings | Where-Object { $_.type -eq 'sast' }).Count) SAST, $(@($findings | Where-Object { $_.type -eq 'sca' }).Count) SCA findings"
    Read-JsonFile $out
}

# ================================================================== v2: structured agents
# Agents get a JSON input file and must write a JSON output file that matches a contract.
# The script validates it (required keys, enums) and retries once with the validation error.
function Test-AgentOutput($Obj, $Schema) {
    if (-not ($Obj -is [System.Collections.IDictionary])) { return 'output is not a JSON object' }
    foreach ($k in @($Schema.required)) { if (-not $Obj.Contains($k)) { return "missing key '$k'" } }
    if ($Schema.enums) {
        foreach ($k in @($Schema.enums.Keys)) {
            if ($Obj.Contains($k) -and @($Schema.enums[$k]) -notcontains "$($Obj[$k])") { return "key '$k' must be one of: $(@($Schema.enums[$k]) -join ', ')" }
        }
    }
    $null
}

function Invoke-Agent {
    param($Ctx, [string]$Agent, $InputData, $Schema, [string[]]$WritablePaths, [string]$Name, [string]$Instruction, $Options)
    $io = Join-Path $Ctx.Work 'agent-io'
    New-Item -ItemType Directory -Force -Path $io | Out-Null
    $inFile = Join-Path $io "$Name.input.json"; $outFile = Join-Path $io "$Name.output.json"
    if (Test-ChatMode $Ctx) {
        if (-not (Test-Path -LiteralPath (Join-Path $io "$Name.final.json"))) { Save-JsonFile $InputData $inFile }
        return (Invoke-ChatTask -Ctx $Ctx -Kind 'agent' -Agent $Agent -Task "Input data: $(Get-RelPath $Ctx $inFile)`n`n$Instruction" -WritablePaths $WritablePaths -Name $Name -Schema $Schema -Options $Options)
    }
    Save-JsonFile $InputData $inFile
    Remove-Item -LiteralPath $outFile -ErrorAction SilentlyContinue
    $inRel = Get-RelPath $Ctx $inFile; $outRel = Get-RelPath $Ctx $outFile
    $contract = @{ required = $Schema.required; enums = $Schema.enums; example = $Schema.example } | ConvertTo-Json -Depth 12
    $feedback = ''; $obj = $null; $err = $null; $res = $null
    for ($try = 1; $try -le 2; $try++) {
        $task = "INPUT FILE: $inRel`nOUTPUT FILE: $outRel (write exactly one JSON object, nothing else)`nOUTPUT CONTRACT:`n$contract`n`n$Instruction$feedback"
        $res = Invoke-Copilot $Ctx $Agent $task (@($WritablePaths | Where-Object { $_ }) + $outRel) "$Name-try$try"
        $obj = $null; $err = $null
        try { $obj = Read-JsonFile $outFile } catch { $err = "output is not valid JSON ($($_.Exception.Message))" }
        if (-not $err -and -not $obj) { $err = 'output file was not written' }
        if (-not $err) { $err = Test-AgentOutput $obj $Schema }
        if (-not $err) { return [pscustomobject]@{ Ok = $true; Output = $obj; NeedsHuman = $res.NeedsHuman } }
        Write-Warn2 "agent $Agent output rejected: $err"
        $feedback = "`n`nYOUR PREVIOUS OUTPUT WAS REJECTED: $err. Fix it and rewrite $outRel."
    }
    [pscustomobject]@{ Ok = $false; Output = $obj; Error = $err; NeedsHuman = @($res.NeedsHuman) }
}

# Maker-checker: a second agent reviews the diff the first agent produced. Read-only.
function Invoke-DiffReview($Ctx, [string[]]$Files, $Context, [string]$Name) {
    if (Test-ChatMode $Ctx) { return [pscustomobject]@{ Verdict = 'approve'; Risk = 'see-task-review'; Reasons = @('reviewed when the AI task was finalised'); Tests = @() } }
    if (-not $Ctx.Config.aiDiffReview) { return [pscustomobject]@{ Verdict = 'approve'; Risk = 'unknown'; Reasons = @('review disabled') } }
    $diff = (Invoke-Git $Ctx (@('diff', '--') + $Files)) -join "`n"
    if (-not $diff.Trim()) { return [pscustomobject]@{ Verdict = 'approve'; Risk = 'none'; Reasons = @('no change') } }
    if ($diff.Length -gt 15000) { $diff = $diff.Substring(0, 15000) + "`n... (truncated)" }
    $schema = @{
        required = @('verdict', 'behaviourRisk', 'reasons')
        enums    = @{ verdict = @('approve', 'reject'); behaviourRisk = @('none', 'low', 'high') }
        example  = @{ verdict = 'approve'; behaviourRisk = 'low'; reasons = @('Base64 replacement keeps MIME line wrapping'); testsToAdd = @('encode 100-byte payload and compare with JDK 8 output') }
    }
    $r = Invoke-Agent $Ctx 'jdk-code-reviewer' @{ purpose = $Context.purpose; targetJdk = $Ctx.TargetJdk; files = $Files; context = $Context; diff = $diff } $schema @() $Name 'Review the diff in the input. Reject it if it changes business behaviour, data formats, public signatures, disables or weakens tests, or goes beyond what the purpose needs.'
    if (-not $r.Ok) { return [pscustomobject]@{ Verdict = 'unreviewed'; Risk = 'unknown'; Reasons = @("review failed: $($r.Error)") } }
    [pscustomobject]@{ Verdict = $r.Output.verdict; Risk = $r.Output.behaviourRisk; Reasons = @($r.Output.reasons); Tests = @($r.Output.testsToAdd) }
}

function Get-LatestLog($Ctx) {
    Get-ChildItem -LiteralPath $Ctx.Logs -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike '*.transcript.md' } |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
}

# When a phase fails: an agent reads the error + log tail and returns a structured diagnosis. Read-only.
function Invoke-ErrorTriage($Ctx, [string]$Phase, [string]$Message) {
    if (-not $Ctx.Config.aiErrorTriage) { return }
    if (Test-ChatMode $Ctx) {
        if (Read-JsonFile (Get-WorkFile $Ctx 'pending.json')) { return }
        $log = Get-LatestLog $Ctx
        $tail = if ($log) { (Get-Content -LiteralPath $log.FullName -Tail 150) -join "`n" } else { '' }
        $schema = @{ required = @('category', 'rootCause', 'suggestedActions', 'safeToRetry', 'needsHuman')
            enums = @{ category = @('environment', 'credentials-or-access', 'dependency-resolution', 'company-repo-policy', 'build-configuration', 'source-code', 'tests', 'tooling', 'unknown') }
            example = @{ category = 'dependency-resolution'; rootCause = 'artifact missing in company Nexus'; suggestedActions = @('request it in Nexus'); safeToRetry = $false; needsHuman = $true } }
        $name = "triage-$Phase-$(Get-ShortHash $Message)"
        Save-JsonFile @{ phase = $Phase; error = $Message; logFile = $(if ($log) { $log.Name }); logTail = $tail } (Join-Path $Ctx.Work "agent-io/$name.input.json")
        $t = New-ChatTask -Ctx $Ctx -Kind 'agent' -Agent 'jdk-error-triage' -Task "Input data: $($Ctx.Config.workDir)/agent-io/$name.input.json`n`nDiagnose why this pipeline phase failed. Explain the result to the user in chat after writing the output file." -WritablePaths @() -Name $name -Schema $schema
        Write-TaskBanner $Ctx $t
        return
    }
    try {
        $log = Get-LatestLog $Ctx
        $tail = if ($log) { (Get-Content -LiteralPath $log.FullName -Tail 150) -join "`n" } else { '' }
        $schema = @{
            required = @('category', 'rootCause', 'suggestedActions', 'safeToRetry', 'needsHuman')
            enums    = @{ category = @('environment', 'credentials-or-access', 'dependency-resolution', 'company-repo-policy', 'build-configuration', 'source-code', 'tests', 'tooling', 'unknown') }
            example  = @{ category = 'dependency-resolution'; rootCause = 'jaxb-runtime 2.3.9 is not in the company Nexus'; suggestedActions = @('Request the artifact in Nexus', 'or pin 2.3.8 in upgrade-plan.json'); safeToRetry = $false; needsHuman = $true }
        }
        $r = Invoke-Agent $Ctx 'jdk-error-triage' @{ phase = $Phase; error = $Message; logFile = $(if ($log) { $log.Name }); logTail = $tail } $schema @() "triage-$Phase" 'Diagnose why this pipeline phase failed. Do not change any file except the output file.'
        if ($r.Ok) {
            Save-JsonFile $r.Output (Get-WorkFile $Ctx "triage-$Phase.json")
            Write-Host "    AI triage [$($r.Output.category)]: $($r.Output.rootCause)" -ForegroundColor Yellow
            foreach ($a in @($r.Output.suggestedActions)) { Write-Host "      -> $a" -ForegroundColor Yellow }
        }
    }
    catch { Write-Warn2 "AI triage unavailable: $($_.Exception.Message)" }
}

# ================================================================== v3: Copilot CHAT mode (no CLI)
# The scripts cannot call Copilot Chat. Instead they hand out AI tasks as files and stop:
#   phase needs AI -> task file + pending.json -> "AI TASK PENDING" -> Copilot Chat (driver agent)
#   performs the task, writes the output JSON, reruns the runner -> runner finalises the task
#   (contract validation, scope enforcement, test-integrity guard, reviewer task, commit) -> continue.
function Test-ChatMode($Ctx) { "$($Ctx.Config.aiMode)" -ne 'cli' }

function Get-ShortHash([string]$S) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($S))) -replace '-', '').Substring(0, 10).ToLowerInvariant() } finally { $sha.Dispose() }
}

function Get-ToolPathPattern { '^(\.github/jdk21-migration/|\.github/agents/|\.github/prompts/|\.jdk21-migration\.json$)' }

function Get-ChangedFiles($Ctx) {
    $r = Invoke-Exe 'git' @('status', '--porcelain', '--untracked-files=all') -WorkingDir $Ctx.Repo
    if ($r.ExitCode -ne 0) { return @() }
    $pat = Get-ToolPathPattern
    @($r.Lines | Where-Object { $_.Length -gt 3 } | ForEach-Object {
            $p = $_.Substring(3); if ($p -match ' -> ') { $p = ($p -split ' -> ')[-1] }
            $p.Trim('"')
        } | Where-Object { $_ -notmatch $pat })
}

function Get-FileHashOrNull($Ctx, [string]$Rel) {
    $f = Join-Path $Ctx.Repo $Rel
    if (Test-Path -LiteralPath $f -PathType Leaf) { (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash } else { 'missing' }
}

function Undo-Files($Ctx, [string[]]$Files) {
    foreach ($f in @($Files | Where-Object { $_ })) {
        $tracked = (Invoke-Exe 'git' @('ls-files', '--error-unmatch', '--', $f) -WorkingDir $Ctx.Repo).ExitCode -eq 0
        if ($tracked) { Invoke-Git $Ctx @('checkout', '--', $f) | Out-Null }
        else { Remove-Item -LiteralPath (Join-Path $Ctx.Repo $f) -Force -ErrorAction SilentlyContinue }
    }
}

function Test-TestIntegrityFiles($Ctx, [string[]]$Files) {
    $bad = @()
    foreach ($f in @($Files | Where-Object { $_ -match '(^|/)src/test/' })) {
        $diff = @(Invoke-Git $Ctx @('diff', '-U0', '--', $f))
        $added = @($diff | Where-Object { $_ -match '^\+(?!\+\+)' }); $removed = @($diff | Where-Object { $_ -match '^-(?!--)' })
        $hit = @($added | Where-Object { $_ -match '@Ignore|@Disabled|\bAssume\.|assumeTrue|assumeFalse|@DisabledOnJre|@EnabledOnJre|@DisabledForJreRange' }) +
        @($removed | Where-Object { $_ -match '\bassert|\bverify\s*\(|@Test\b|\bexpect' })
        if ($hit.Count) { $bad += $f }
    }
    $bad
}

function Get-PlainContract {
    @{
        required = @('summary', 'filesChanged', 'needsHuman', 'selfReview')
        enums    = @{}
        example  = @{ summary = 'Replaced sun.misc.BASE64Encoder with a MIME Base64 encoder keeping 76-char lines'; filesChanged = @('src/main/java/com/x/Codec.java')
            needsHuman = @('src/main/java/com/x/Legacy.java: needs javax.xml.bind dependency'); selfReview = @{ behaviourChanged = $false; notes = 'output identical for test vectors' } }
    }
}

function Write-TaskBanner($Ctx, $Pending) {
    Write-Host ''
    Write-Host '==================== AI TASK PENDING ====================' -ForegroundColor Magenta
    Write-Host "Task file : $($Pending.taskFile)" -ForegroundColor Magenta
    Write-Host "Role      : $($Pending.agent)" -ForegroundColor Magenta
    Write-Host "May edit  : $(if (@($Pending.writable).Count) { @($Pending.writable) -join ', ' } else { '(nothing - output file only)' })" -ForegroundColor Magenta
    Write-Host "Output    : $($Pending.outFile)" -ForegroundColor Magenta
    Write-Host "Then rerun: $($Pending.resume)" -ForegroundColor Magenta
    Write-Host '=========================================================' -ForegroundColor Magenta
}

function New-ChatTask {
    param($Ctx, [string]$Kind, [string]$Agent, [string]$Task, [string[]]$WritablePaths, [string]$Name, $Schema, $Options, [int]$Try = 1, [string]$Feedback, $Parent)
    $io = Join-Path $Ctx.Work 'agent-io'; $taskDir = Join-Path $Ctx.Work 'tasks'
    New-Item -ItemType Directory -Force -Path $io, $taskDir | Out-Null
    $writable = @($WritablePaths | Where-Object { $_ -and $_ -notlike "$($Ctx.Config.workDir)/*" })
    if ($writable.Count -and $Kind -ne 'review') {
        # isolate this task's diff: commit whatever the scripts changed before it
        Invoke-Git $Ctx @('add', '-A') | Out-Null
        if (Invoke-Git $Ctx @('status', '--porcelain')) { Invoke-Git $Ctx @('commit', '-m', "jdk: wip before AI task $Name") | Out-Null }
    }
    if (-not $Schema) { $Schema = Get-PlainContract }
    $outFile = Join-Path $io "$Name.output.json"
    Remove-Item -LiteralPath $outFile -ErrorAction SilentlyContinue
    $outRel = Get-RelPath $Ctx $outFile
    $agentFile = Join-Path (Split-Path -Parent $Ctx.ToolRoot) "agents/$Agent.agent.md"
    $role = if (Test-Path -LiteralPath $agentFile) { (Get-Content -LiteralPath $agentFile -Raw) -replace '(?s)^\s*---.*?---\s*', '' } else { '' }
    $contract = @{ required = $Schema.required; enums = $Schema.enums; example = $Schema.example } | ConvertTo-Json -Depth 12
    $resume = $env:JDKMIG_RESUME_CMD; if (-not $resume) { $resume = 'rerun the same pipeline command' }
    $body = @"
# AI TASK $Name  (attempt $Try)

## Your role for this task ($Agent)
$role

## Task
$Task

## Rules
- Files you may edit: $(if (@($WritablePaths | Where-Object { $_ }).Count) { @($WritablePaths | Where-Object { $_ }) -join ', ' } else { 'NONE (only the output file below)' }). Any other change is reverted automatically.
- Do not run Maven or any build/test command and do not edit pipeline scripts, rules, config or this task file.
- When done, write ONE JSON object to $outRel that matches this contract:

$contract

- Then rerun: $resume
"@
    if ($Feedback) { $body += "`n`n## Your previous output was rejected`n$Feedback`n" }
    $taskFile = Join-Path $taskDir "$Name.md"
    Set-Content -LiteralPath $taskFile -Value $body -Encoding utf8NoBOM
    $pre = @{}; foreach ($f in Get-ChangedFiles $Ctx) { $pre[$f] = Get-FileHashOrNull $Ctx $f }
    $pending = @{
        name = $Name; kind = $Kind; agent = $Agent; taskText = $Task; taskFile = (Get-RelPath $Ctx $taskFile); outFile = $outRel
        writable = $writable; schema = $Schema; options = $Options; try = $Try; parent = $Parent; preChanged = $pre
        resume = $resume; createdAt = (Get-Date).ToString('s')
    }
    Save-JsonFile $pending (Get-WorkFile $Ctx 'pending.json')
    $pending
}

function Invoke-ChatTask {
    param($Ctx, [string]$Kind, [string]$Agent, [string]$Task, [string[]]$WritablePaths, [string]$Name, $Schema, $Options)
    $final = Read-JsonFile (Join-Path $Ctx.Work "agent-io/$Name.final.json")
    if ($final) {
        return [pscustomobject]@{ Ok = [bool]$final.ok; Output = $final.output; Error = $final.error; NeedsHuman = @($final.needsHuman); ExitCode = $(if ($final.ok) { 0 } else { 1 }); Log = $null }
    }
    $p = New-ChatTask -Ctx $Ctx -Kind $Kind -Agent $Agent -Task $Task -WritablePaths $WritablePaths -Name $Name -Schema $Schema -Options $Options
    Write-TaskBanner $Ctx $p
    throw "AI-TASK-PENDING: $($p.taskFile)"
}

function Save-ChatFinal($Ctx, [string]$Name, [bool]$Ok, $Output, [string]$Err, [string[]]$NeedsHuman) {
    Save-JsonFile @{ ok = $Ok; output = $Output; error = $Err; needsHuman = @($NeedsHuman | Where-Object { $_ }) } (Join-Path $Ctx.Work "agent-io/$Name.final.json")
    if (@($NeedsHuman | Where-Object { $_ }).Count) {
        $f = Get-WorkFile $Ctx 'chat-needs-human.json'
        $all = @(Read-JsonFile $f | Where-Object { $_ }) + @($NeedsHuman | Where-Object { $_ } | ForEach-Object { "[$Name] $_" })
        Save-JsonFile @($all) $f
    }
}

# Called by the runners before any phase. Returns 'none' | 'waiting' | 'done'.
function Complete-PendingChatTask($Ctx) {
    $pf = Get-WorkFile $Ctx 'pending.json'
    $p = Read-JsonFile $pf
    if (-not $p) { return 'none' }
    $outFile = Join-Path $Ctx.Repo $p.outFile
    if (-not (Test-Path -LiteralPath $outFile)) { Write-Warn2 "AI task '$($p.name)' is not finished yet (no output file)."; Write-TaskBanner $Ctx $p; return 'waiting' }
    Write-Step "Finalising AI task $($p.name)"
    $notes = [System.Collections.Generic.List[string]]::new()

    # 1. scope: anything changed outside the allowed files is reverted
    $allowed = @($p.writable)
    $outside = @(Get-ChangedFiles $Ctx | Where-Object { $allowed -notcontains $_ -and (-not $p.preChanged.ContainsKey($_) -or $p.preChanged[$_] -ne (Get-FileHashOrNull $Ctx $_)) })
    if ($outside.Count) {
        $revertable = @($outside | Where-Object { -not $p.preChanged.ContainsKey($_) })
        Undo-Files $Ctx $revertable
        foreach ($o in $outside) { $notes.Add("out-of-scope change to $o was $(if ($revertable -contains $o) { 'reverted' } else { 'detected (file was already modified - check manually)' })") }
        Write-Warn2 "reverted out-of-scope changes: $($revertable -join ', ')"
    }
    $changed = @(Get-ChangedFiles $Ctx | Where-Object { $allowed -contains $_ })

    # 2. output contract
    $obj = $null; $err = $null
    try { $obj = Read-JsonFile $outFile } catch { $err = "output is not valid JSON ($($_.Exception.Message))" }
    if (-not $err -and -not $obj) { $err = 'output file is empty' }
    if (-not $err) { $err = Test-AgentOutput $obj $p.schema }
    if ($err) {
        Move-Item -LiteralPath $outFile -Destination ($outFile -replace '\.json$', ".rejected$($p.try).json") -Force
        if ($p.try -lt 2) {
            $n = New-ChatTask -Ctx $Ctx -Kind $p.kind -Agent $p.agent -Task $p.taskText -WritablePaths $allowed -Name $p.name -Schema $p.schema -Options $p.options -Try ($p.try + 1) -Feedback $err -Parent $p.parent
            Write-Warn2 "output rejected: $err - task reissued"
            Write-TaskBanner $Ctx $n
            return 'waiting'
        }
        Undo-Files $Ctx $changed
        Save-ChatFinal $Ctx $p.name $false $null $err (@($notes) + "output rejected twice: $err")
        Remove-Item -LiteralPath $pf -Force
        return 'done'
    }
    foreach ($n in @($obj.needsHuman)) { if ($n) { $notes.Add("$n") } }

    # 3. test integrity guard
    if ($changed.Count) {
        $bad = @(Test-TestIntegrityFiles $Ctx $changed)
        if ($bad.Count) { Undo-Files $Ctx $bad; foreach ($b in $bad) { $notes.Add("$($b): edit disabled tests or touched assertions - reverted by integrity guard") }; $changed = @($changed | Where-Object { $bad -notcontains $_ }) }
    }

    # 4. review chain: maker output -> reviewer task -> commit or revert
    if ($p.kind -eq 'review') {
        $parent = $p.parent
        $reject = $obj.verdict -eq 'reject' -or $obj.behaviourRisk -eq 'high'
        Save-ChatFinal $Ctx $p.name $true $obj $null @()
        if ($reject) {
            Undo-Files $Ctx @($parent.changed)
            $why = "rejected by reviewer (risk $($obj.behaviourRisk)): $(@($obj.reasons) -join '; ')"
            Save-ChatFinal $Ctx $parent.name $false $parent.output $why (@($parent.notes) + $why)
            Write-Warn2 "$($parent.name): $why - reverted"
        }
        else {
            Invoke-Git $Ctx @('add', '-A') | Out-Null
            if (Invoke-Git $Ctx @('status', '--porcelain')) { Invoke-Git $Ctx @('commit', '-m', "ai: $($parent.name) (reviewed)") | Out-Null }
            $extra = @($obj.testsToAdd | Where-Object { $_ } | ForEach-Object { "reviewer suggests test: $_" })
            Save-ChatFinal $Ctx $parent.name $true $parent.output $null (@($parent.notes) + $extra)
            Write-Good "$($parent.name): approved by reviewer and committed"
        }
        Remove-Item -LiteralPath $pf -Force
        return 'done'
    }
    if ($changed.Count -and $Ctx.Config.aiDiffReview) {
        $diff = (Invoke-Git $Ctx (@('diff', '--') + $changed)) -join "`n"
        $untracked = @($changed | Where-Object { (Invoke-Exe 'git' @('ls-files', '--error-unmatch', '--', $_) -WorkingDir $Ctx.Repo).ExitCode -ne 0 })
        foreach ($u in $untracked) { $diff += "`n--- new file $u ---`n" + (Get-Content -LiteralPath (Join-Path $Ctx.Repo $u) -Raw) }
        if ($diff.Length -gt 15000) { $diff = $diff.Substring(0, 15000) + "`n... (truncated)" }
        $rschema = @{
            required = @('verdict', 'behaviourRisk', 'reasons')
            enums    = @{ verdict = @('approve', 'reject'); behaviourRisk = @('none', 'low', 'high') }
            example  = @{ verdict = 'approve'; behaviourRisk = 'low'; reasons = @('replacement keeps output identical'); testsToAdd = @('compare encoded output with JDK 8 vector') }
        }
        $purpose = if ($p.options -and $p.options.purpose) { $p.options.purpose } else { "AI task $($p.name)" }
        $rtask = "Review, as an independent reviewer, the change another engineer made for this purpose: $purpose`n`nIf you can run a separate subagent for reviews, use it. Judge only the diff below.`n`n~~~diff`n$diff`n~~~"
        $parentInfo = @{ name = $p.name; output = $obj; changed = $changed; notes = @($notes) }
        $r = New-ChatTask -Ctx $Ctx -Kind 'review' -Agent 'jdk-code-reviewer' -Task $rtask -WritablePaths @() -Name "$($p.name)-review" -Schema $rschema -Parent $parentInfo
        Write-TaskBanner $Ctx $r
        return 'waiting'
    }
    Invoke-Git $Ctx @('add', '-A') | Out-Null
    if ($changed.Count -and (Invoke-Git $Ctx @('status', '--porcelain'))) { Invoke-Git $Ctx @('commit', '-m', "ai: $($p.name)") | Out-Null }
    Save-ChatFinal $Ctx $p.name $true $obj $null @($notes)
    if ($p.name -like 'triage-*') {
        Write-Host "    AI triage [$($obj.category)]: $($obj.rootCause)" -ForegroundColor Yellow
        foreach ($a in @($obj.suggestedActions)) { Write-Host "      -> $a" -ForegroundColor Yellow }
    }
    Remove-Item -LiteralPath $pf -Force
    Write-Good "AI task $($p.name) accepted"
    'done'
}

# ================================================================== v4: dependency tree, roles, encoding, coverage, deprecations
# dependency:tree (all modules) -> flat list with the path that brings each artifact in
function Get-DependencyTree($Ctx, [string]$Jdk, [string]$OutName) {
    $txt = Get-WorkFile $Ctx ($OutName -replace '\.json$', '.txt')
    Remove-Item -LiteralPath $txt -ErrorAction SilentlyContinue
    $code = Invoke-Maven $Ctx $Jdk @('dependency:tree', "-DoutputFile=$txt", '-DappendOutput=true') ($OutName -replace '\.json$', '.log') -Quiet
    if ($code -ne 0 -or -not (Test-Path -LiteralPath $txt)) { Write-Warn2 'dependency:tree failed - transitive paths unavailable.'; return @() }
    $entries = [System.Collections.Generic.List[object]]::new()
    $stack = @(); $module = $null
    foreach ($line in Get-Content -LiteralPath $txt) {
        $m = [regex]::Match($line, '^(?<pre>[| ]*)(?<br>[+\\]- )?(?<coord>\S+)')
        if (-not $m.Success -or $m.Groups['coord'].Value -notmatch ':') { continue }
        $tok = $m.Groups['coord'].Value.Split(':')
        if (-not $m.Groups['br'].Success) { $module = "$($tok[0]):$($tok[1])"; $stack = @($module); continue }
        $depth = [int]($m.Groups['pre'].Value.Length / 3) + 1
        if ($tok.Count -lt 5) { continue }
        $key = "$($tok[0]):$($tok[1])"
        $ver = if ($tok.Count -ge 6) { $tok[4] } else { $tok[3] }
        $scope = $tok[$tok.Count - 1]
        $stack = @($stack | Select-Object -First $depth) + $key
        $entries.Add(@{ module = $module; key = $key; version = $ver; scope = $scope; depth = $depth; path = @($stack | Select-Object -Skip 1) })
    }
    Save-JsonFile @($entries) (Get-WorkFile $Ctx $OutName)
    $entries.ToArray()
}

function Get-WhoBrings($Tree, [string]$Key) {
    @($Tree | Where-Object { $_.key -eq $Key -and $_.depth -gt 1 } | ForEach-Object { "$($_.module) > $(@($_.path) -join ' > ')" } | Select-Object -Unique -First 5)
}

# library (shared by other repos) vs application (deployed)
function Get-RepoRole($Ctx, $Models) {
    if ($Ctx.Config.repoRole -and "$($Ctx.Config.repoRole)" -ne 'auto') { return "$($Ctx.Config.repoRole)" }
    foreach ($m in $Models) {
        if ($m.Packaging -in 'war', 'ear') { return 'application' }
        foreach ($pl in @($m.Pom.Xml.SelectNodes("//*[local-name()='plugin']"))) {
            if ((Get-ChildText $pl 'artifactId') -in 'spring-boot-maven-plugin', 'maven-assembly-plugin', 'appassembler-maven-plugin', 'maven-ear-plugin', 'maven-war-plugin') { return 'application' }
        }
    }
    $prefixes = @($Ctx.Config.internalGroupIdPrefixes | Where-Object { $_ })
    if (@($Models | Where-Object { $g = $_.GroupId; @($prefixes | Where-Object { $g -and $g.StartsWith($_) }).Count }).Count) { return 'library' }
    'application'
}

# Declared source encoding + files whose bytes are not valid UTF-8 (JDK 18+ javac default is UTF-8)
function Get-EncodingInfo($Ctx, $Models) {
    $declared = [System.Collections.Generic.List[object]]::new()
    foreach ($m in $Models) {
        foreach ($k in 'project.build.sourceEncoding') { if ($m.Properties.ContainsKey($k)) { $declared.Add(@{ pom = $m.Rel; where = $k; value = (Resolve-PomValue $m $m.Properties[$k]).Value }) } }
        foreach ($pl in @($m.Pom.Xml.SelectNodes("//*[local-name()='plugin']"))) {
            if ((Get-ChildText $pl 'artifactId') -ne 'maven-compiler-plugin') { continue }
            foreach ($c in @($pl.SelectNodes(".//*[local-name()='configuration']/*[local-name()='encoding']"))) { $declared.Add(@{ pom = $m.Rel; where = 'compiler <encoding>'; value = (Resolve-PomValue $m $c.InnerText.Trim()).Value }) }
        }
    }
    $strict = New-Object System.Text.UTF8Encoding($false, $true)
    $nonAscii = 0; $invalid = [System.Collections.Generic.List[string]]::new()
    foreach ($f in @(Get-RepoFiles $Ctx { param($f) $f.Extension -eq '.java' })) {
        $b = [IO.File]::ReadAllBytes($f.FullName)
        $has = $false; foreach ($x in $b) { if ($x -gt 127) { $has = $true; break } }
        if (-not $has) { continue }
        $nonAscii++
        try { [void]$strict.GetString($b) } catch { $invalid.Add((Get-RelPath $Ctx $f.FullName)) }
    }
    @{ declared = @($declared); nonAsciiFiles = $nonAscii; invalidUtf8Files = @($invalid) }
}

# JaCoCo XML reports -> line coverage per repo-relative source file
function Get-JacocoCoverage($Ctx) {
    $map = @{}
    $settings = New-Object System.Xml.XmlReaderSettings
    $settings.DtdProcessing = [System.Xml.DtdProcessing]::Ignore
    $settings.XmlResolver = $null
    $srcIndex = @{}
    foreach ($f in @(Get-RepoFiles $Ctx { param($f) $f.Extension -eq '.java' })) {
        $rel = Get-RelPath $Ctx $f.FullName
        $mm = [regex]::Match($rel, 'src/main/java/(.+)$')
        if ($mm.Success) { $srcIndex[$mm.Groups[1].Value] = $rel }
    }
    $reports = Get-ChildItem -LiteralPath $Ctx.Repo -Recurse -File -Filter 'jacoco.xml' -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch '[\\/]node_modules[\\/]' }
    foreach ($r in $reports) {
        $reader = [System.Xml.XmlReader]::Create($r.FullName, $settings)
        try { $x = New-Object System.Xml.XmlDocument; $x.Load($reader) } catch { continue } finally { $reader.Dispose() }
        foreach ($pkg in $x.SelectNodes('//package')) {
            foreach ($sf in $pkg.SelectNodes('sourcefile')) {
                $k = "$($pkg.GetAttribute('name'))/$($sf.GetAttribute('name'))"
                $line = $sf.SelectSingleNode("counter[@type='LINE']")
                if (-not $line) { continue }
                $rel = if ($srcIndex.ContainsKey($k)) { $srcIndex[$k] } else { $k }
                $cov = [int]$line.GetAttribute('covered'); $mis = [int]$line.GetAttribute('missed')
                $map[$rel] = @{ covered = $cov; missed = $mis; pct = $(if ($cov + $mis) { [Math]::Round(100.0 * $cov / ($cov + $mis), 1) } else { 0 }) }
            }
        }
    }
    $map
}

# javac deprecation warnings from a Maven log (needs -Dmaven.compiler.showDeprecation=true)
function Get-DeprecationWarnings([string]$LogPath, $Ctx) {
    $out = [System.Collections.Generic.List[object]]::new()
    if (-not (Test-Path -LiteralPath $LogPath)) { return @() }
    $seen = @{}
    foreach ($line in Get-Content -LiteralPath $LogPath) {
        $m = [regex]::Match($line, '^\[WARNING\]\s+(.+?\.java):\[(\d+)(?:,\d+)?\]\s+(.*\bdeprecated\b.*)$')
        if (-not $m.Success) { continue }
        $file = $m.Groups[1].Value; if ($file -match '^/[A-Za-z]:[/\\]') { $file = $file.Substring(1) }
        $rel = Get-RelPath $Ctx $file
        $id = "$rel|$($m.Groups[2].Value)|$($m.Groups[3].Value)"
        if ($seen.ContainsKey($id)) { continue }
        $seen[$id] = $true
        $msg = $m.Groups[3].Value.Trim()
        $out.Add(@{ file = $rel; line = [int]$m.Groups[2].Value; message = $msg; forRemoval = ($msg -match 'marked for removal'); api = ($msg -replace '\s+(in|of)\s+\S+\s+has been deprecated.*$', '' -replace '\s+has been deprecated.*$', '') })
    }
    $out.ToArray()
}

function Get-DeprecationSummary($List) {
    @{
        total = @($List).Count; forRemoval = @($List | Where-Object { $_.forRemoval }).Count
        topApis = @($List | Group-Object { $_.message } | Sort-Object Count -Descending | Select-Object -First 15 | ForEach-Object { @{ api = $_.Name; count = $_.Count } })
    }
}

Export-ModuleMember -Function *
