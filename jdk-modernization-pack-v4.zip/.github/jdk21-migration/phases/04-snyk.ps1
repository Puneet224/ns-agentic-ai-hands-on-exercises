#requires -Version 7.0
# 04 - Snyk: which vulnerable artifacts have a fixed version, and the smallest safe
#      upgrade for each (same major line preferred, to keep behaviour). No AI.
param([Parameter(Mandatory)][string]$RepoPath, [string]$OutName = 'snyk.json', [string]$Jdk = '8')
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step "04 Snyk vulnerability check (JDK $Jdk)"
$outFile = Get-WorkFile $ctx $OutName
# security baseline also includes Checkmarx (once, before any change)
if ($OutName -eq 'snyk.json' -and -not (Test-Path -LiteralPath (Get-WorkFile $ctx 'checkmarx.json'))) { $null = Invoke-CheckmarxScan $ctx 'checkmarx.json' }

if (-not $cfg.snykEnabled -or -not (Get-Command $cfg.snykCmd -ErrorAction SilentlyContinue)) {
    Save-JsonFile @{ skipped = $true; reason = 'snyk disabled or CLI not found'; findings = @() } $outFile
    Write-Warn2 'Snyk skipped.'
    if ($OutName -eq 'snyk.json') { Set-PhaseDone $ctx '04-snyk' 'skipped' }
    return
}

$raw = Get-WorkFile $ctx ($OutName -replace '\.json$', '-raw.json')
Remove-Item -LiteralPath $raw -ErrorAction SilentlyContinue
Use-Jdk $ctx $Jdk
$snykArgs = @('test', '--maven-aggregate-project', "--json-file-output=$raw")
if ($cfg.mavenSettings) { $snykArgs += @('--', '-s', $cfg.mavenSettings) }
$r = Invoke-Exe $cfg.snykCmd $snykArgs -WorkingDir $ctx.Repo -LogPath (Join-Path $ctx.Logs ($OutName -replace '\.json$', '.log'))
# exit codes: 0 = no vulns, 1 = vulns found, 2 = failure, 3 = no supported project
if ($r.ExitCode -ge 2 -or -not (Test-Path -LiteralPath $raw)) {
    Save-JsonFile @{ skipped = $true; reason = "snyk exit $($r.ExitCode) - see logs (is 'snyk auth' / SNYK_TOKEN set?)"; findings = @() } $outFile
    Write-Warn2 "Snyk failed (exit $($r.ExitCode)); continuing without it."
    if ($OutName -eq 'snyk.json') { Set-PhaseDone $ctx '04-snyk' 'skipped' }
    return
}

$json = Get-Content -LiteralPath $raw -Raw | ConvertFrom-Json -AsHashtable
$projects = @($json)
$rank = @{ low = 1; medium = 2; high = 3; critical = 4 }
$minRank = $rank[[string]$cfg.snykMinSeverity]; if (-not $minRank) { $minRank = 2 }

$findings = [System.Collections.Generic.List[object]]::new()
$seen = @{}
foreach ($p in $projects) {
    foreach ($v in @($p.vulnerabilities)) {
        if (-not $v) { continue }
        if (($rank[[string]$v.severity] ?? 0) -lt $minRank) { continue }
        $from = @($v.from)
        $pkg = $v.packageName; $cur = $v.version
        $id = "$($v.id)|$pkg|$cur|$($from[1])"
        if ($seen.ContainsKey($id)) { continue }
        $seen[$id] = $true

        $fixed = @($v.fixedIn | Where-Object { $_ -and (Compare-MavenVersion $_ $cur) -gt 0 })
        $sameMajor = @($fixed | Where-Object { (Get-Major $_) -eq (Get-Major $cur) })
        $minimalFix = if ($sameMajor.Count) { Get-MinVersion $sameMajor } else { Get-MinVersion $fixed }

        $f = @{ id = $v.id; title = $v.title; severity = $v.severity; package = $pkg; version = $cur; fixedIn = @($v.fixedIn); path = ($from -join ' > ') }
        if (-not $fixed.Count) { $f.kind = 'no-fix' }
        elseif ($from.Count -le 2) {
            $f.kind = 'direct'; $f.upgradeKey = $pkg; $f.target = $minimalFix
            $f.majorChange = ((Get-Major $minimalFix) -ne (Get-Major $cur))
        }
        else {
            $up = @($v.upgradePath)
            if ($up.Count -ge 2 -and $up[1] -is [string] -and $up[1] -match '^(.+)@(.+)$') {
                $directKey = $Matches[1]; $directTarget = $Matches[2]
                $directCur = ($from[1] -split '@')[1]
                $f.kind = 'via-direct'; $f.upgradeKey = $directKey; $f.target = $directTarget
                $f.majorChange = ((Get-Major $directTarget) -ne (Get-Major $directCur))
            }
            else { $f.kind = 'transitive-override'; $f.upgradeKey = $pkg; $f.target = $minimalFix; $f.majorChange = ((Get-Major $minimalFix) -ne (Get-Major $cur)) }
        }
        $findings.Add($f)
    }
}

Save-JsonFile @{ skipped = $false; exitCode = $r.ExitCode; findings = @($findings) } $outFile
$bySev = $findings | Group-Object { $_.severity } | ForEach-Object { "$($_.Name)=$($_.Count)" }
Write-Info "Snyk findings (>= $($cfg.snykMinSeverity)): $($findings.Count)  [$($bySev -join ', ')]"
Write-Info "with fix: $(@($findings | Where-Object { $_.kind -ne 'no-fix' }).Count) | no fix available: $(@($findings | Where-Object { $_.kind -eq 'no-fix' }).Count)"
if ($OutName -eq 'snyk.json') { Set-PhaseDone $ctx '04-snyk' }
