#requires -Version 7.0
# 02 - Inventory: every pom, where each version is defined (inline / property / parent /
#      external), effective plugin versions and resolved dependency versions. No AI.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
Write-Step '02 Inventory (poms, version sources, effective plugins, resolved deps)'

$models = @(Get-PomModels $ctx)
$items = @(Get-PomItems $models)
Write-Info "$($models.Count) pom.xml files, $($items.Count) declared dependency/plugin/parent entries"

$depFile = Get-WorkFile $ctx 'deps-before.txt'
if (-not (Test-Path -LiteralPath $depFile)) {
    $code = Invoke-Maven $ctx '8' @('dependency:list', "-DoutputFile=$depFile", '-DappendOutput=true') 'inventory-deplist.log'
    if ($code -ne 0) { throw "dependency:list failed on JDK 8 - see $($ctx.Config.workDir)/logs/inventory-deplist.log" }
}
$resolved = Get-ResolvedDeps $depFile

$effFile = Get-WorkFile $ctx 'effective-pom.xml'
Remove-Item -LiteralPath $effFile -ErrorAction SilentlyContinue
$code = Invoke-Maven $ctx '8' @('help:effective-pom', "-Doutput=$effFile") 'inventory-effective-pom.log'
$effPlugins = @{}
if ($code -eq 0 -and (Test-Path -LiteralPath $effFile)) {
    $eff = New-Object System.Xml.XmlDocument
    $eff.Load($effFile)
    foreach ($n in $eff.SelectNodes("//*[local-name()='build']/*[local-name()='plugins']/*[local-name()='plugin']")) {
        $g = Get-ChildText $n 'groupId'; if (-not $g) { $g = 'org.apache.maven.plugins' }
        $k = "${g}:$(Get-ChildText $n 'artifactId')"
        $v = Get-ChildText $n 'version'
        if (-not $effPlugins.ContainsKey($k)) { $effPlugins[$k] = @() }
        if ($v -and $effPlugins[$k] -notcontains $v) { $effPlugins[$k] += $v }
    }
}
else { Write-Warn2 'help:effective-pom failed - plugin versions inherited from external parents / super-POM cannot be checked.' }

$javaProps = @($ctx.Rules.javaVersionProperties)
$moduleRows = foreach ($m in $models) {
    $jp = @{}
    foreach ($k in $m.Properties.Keys) { if ($javaProps -contains $k) { $jp[$k] = $m.Properties[$k] } }
    @{
        pom = $m.Rel; groupId = $m.GroupId; artifactId = $m.ArtifactId; version = $m.Version; packaging = $m.Packaging
        parent = $m.ParentKey; inRepoParent = $(if ($m.InRepoParent) { $m.InRepoParent.Rel } else { $null })
        isTopParent = (-not $m.InRepoParent); javaProps = $jp
    }
}

if (-not (Test-Path -LiteralPath (Get-WorkFile $ctx 'tree-before.json'))) { $null = Get-DependencyTree $ctx '8' 'tree-before.json' }
$role = Get-RepoRole $ctx $models
$encoding = Get-EncodingInfo $ctx $models
$javaLevel = Get-ProjectJavaLevel $ctx $models
Write-Info "repo role: $role | source encoding declared: $(@($encoding.declared | ForEach-Object { $_.value }) -join ',') | non-ASCII java files: $($encoding.nonAsciiFiles) (not UTF-8: $(@($encoding.invalidUtf8Files).Count))"
$divergent = @($resolved.Keys | Where-Object { @($resolved[$_]).Count -gt 1 } | ForEach-Object { @{ key = $_; versions = @($resolved[$_]) } })
if ($divergent.Count) { Write-Info "artifacts resolved with different versions across modules: $($divergent.Count)" }

Save-JsonFile @{
    role             = $role
    sourceJava       = $javaLevel.feature
    encoding         = $encoding
    divergentVersions = $divergent
    modules          = @($moduleRows)
    items            = @($items)
    effectivePlugins = $effPlugins
    resolvedDeps     = $resolved
} (Get-WorkFile $ctx 'inventory.json')

$tops = @($models | Where-Object { -not $_.InRepoParent } | ForEach-Object { $_.Rel })
Write-Info "top-level parent pom(s): $($tops -join ', ')"
Write-Info "resolved artifacts: $($resolved.Count) | effective plugins: $($effPlugins.Count)"
Set-PhaseDone $ctx '02-inventory'
