#requires -Version 7.0
# 12 - Optional push of the migration branch. Only when push.enabled=true AND the security gate
#      passed. Never force-pushes, never touches other branches. Open the PR yourself for review.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step '12 Push'
if (-not $cfg.push.enabled) { Write-Info 'push.enabled=false - branch stays local. Review, then push and open a PR yourself.'; Set-PhaseDone $ctx '12-push' 'skipped'; return }

$gate = Read-JsonFile (Get-WorkFile $ctx 'security-gate.json')
if (-not $gate -or $gate.status -ne 'passed') { throw "Push refused: security gate status is '$($gate.status)'. It must be 'passed'." }
$branch = (Invoke-Git $ctx @('rev-parse', '--abbrev-ref', 'HEAD')) | Select-Object -First 1
if ($branch -ne $cfg.branchName) { throw "Push refused: current branch '$branch' is not the migration branch '$($cfg.branchName)'." }
if (Invoke-Git $ctx @('status', '--porcelain')) { throw 'Push refused: uncommitted changes present.' }
Invoke-Git $ctx @('push', '-u', $cfg.push.remote, $branch) | ForEach-Object { Write-Info $_ }
Write-Good "pushed $branch to $($cfg.push.remote) - open a pull request and attach final-report.md + security-gate.json"
Set-PhaseDone $ctx '12-push'
