#requires -Version 7.0
# 07 - Configuration files in THIS repo (startup scripts in dist, Dockerfiles, CI pipelines,
#       .mvn/jvm.config, surefire argLine ...): the scanner found the exact lines; a config-fixer
#       agent edits only those files, returns a structured change list, a reviewer agent checks
#       the diff. Server-owned config outside the repo goes to the server-team handoff instead.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step "07 Configuration files for JDK $($ctx.TargetJdk)"

if (-not $cfg.configFix.enabled) { Write-Info 'configFix.enabled=false - skipped'; Set-PhaseDone $ctx '07-config-fix' 'skipped'; return }
$compat = Read-JsonFile (Get-WorkFile $ctx 'compat.json')
$exclude = @($cfg.configFix.excludePaths | Where-Object { $_ })
$hits = @($compat.configHits | Where-Object {
        $f = $_.file
        $f -notmatch '\.md$' -and -not @($exclude | Where-Object { $f -like $_ }).Count
    })
if (-not $hits.Count) { Write-Info 'no configuration findings in the repo'; Set-PhaseDone $ctx '07-config-fix'; return }

$results = [System.Collections.Generic.List[object]]::new()
$needsHuman = [System.Collections.Generic.List[string]]::new()
$schema = @{
    required = @('file', 'changes', 'skipped')
    example  = @{ file = 'dist/bin/setenv.sh'; changes = @(@{ line = 12; before = '-XX:MaxPermSize=512m'; after = ''; reason = 'PermGen removed' }); skipped = @(@{ line = 20; reason = 'flag is read by an external launcher - needs server team' }) }
}
foreach ($grp in ($hits | Group-Object { $_.file } | Select-Object -First $cfg.configFix.maxFiles)) {
    $file = $grp.Name
    $input2 = @{
        file = $file; targetJdk = $ctx.TargetJdk
        findings = @($grp.Group | ForEach-Object { @{ line = $_.line; match = $_.match; category = $_.category; why = $_.why; advice = $_.advice } })
    }
    $instr = "Edit only $file and only the lines listed in findings, applying the advice for the target JDK. CI/container pins: switch the JDK to the target version. JVM flags: remove or replace with the modern equivalent. Keep every other line byte-identical. If a change could alter runtime behaviour (heap, GC choice, encoding, locale) do not guess: list it under skipped with the reason."
    $r = Invoke-Agent $ctx 'jdk-config-fixer' $input2 $schema @($file) "config-$(Get-SafeName $file)" $instr
    if (-not $r.Ok) { $needsHuman.Add("${file}: config agent failed ($($r.Error))"); Invoke-Git $ctx @('checkout', '--', $file) | Out-Null; continue }
    $rev = Invoke-DiffReview $ctx @($file) @{ purpose = "Update configuration for JDK $($ctx.TargetJdk) (JVM flags / CI JDK pins) without other changes"; findings = $input2.findings } "review-config-$(Get-SafeName $file)"
    if ($rev.Verdict -eq 'reject' -or $rev.Risk -eq 'high') {
        Invoke-Git $ctx @('checkout', '--', $file) | Out-Null
        $needsHuman.Add("${file}: change rejected by reviewer: $(@($rev.Reasons) -join '; ')")
        continue
    }
    $results.Add($r.Output)
    foreach ($s in @($r.Output.skipped)) { if ($s) { $needsHuman.Add("${file}:$($s.line) $($s.reason)") } }
}
Save-JsonFile @{ applied = @($results); needsHuman = @($needsHuman) } (Get-WorkFile $ctx 'config-fix.json')
Write-Info "$($results.Count) file(s) updated, $($needsHuman.Count) item(s) for a human"
Save-Commit $ctx "jdk$($ctx.TargetJdk): configuration files (JVM flags, CI JDK)"
Set-PhaseDone $ctx '07-config-fix'
