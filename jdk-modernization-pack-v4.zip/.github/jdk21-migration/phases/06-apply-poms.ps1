#requires -Version 7.0
# 06 - Apply the APPROVED plan to the pom.xml files. Deterministic XML edits, no AI.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
Write-Step '06 Apply approved plan to pom.xml files'

$plan = Read-JsonFile (Get-WorkFile $ctx 'upgrade-plan.json')
if (-not $plan) { throw 'upgrade-plan.json missing - run phase 05.' }
if ($plan.approved -ne $true) { throw "Plan is not approved. Review $($ctx.Config.workDir)/upgrade-plan.md and set `"approved`": true in upgrade-plan.json." }

$models = @(Get-PomModels $ctx)
$byRel = @{}; foreach ($m in $models) { $byRel[$m.Rel] = $m }
$tops = @($models | Where-Object { -not $_.InRepoParent })
$javaProps = @($ctx.Rules.javaVersionProperties)
$tj = $ctx.TargetJdk
function Test-OlderLevel([string]$V, [string]$Than = $tj) { $f = ConvertTo-JavaFeature $V; $f -and $f -lt [int]$Than }
$before = @{}; foreach ($m in $models) { $before[$m.Rel] = $m.Pom.Xml.OuterXml }
$dirty = @{}
$log = [System.Collections.Generic.List[object]]::new()

function Get-Model([string]$Rel) {
    $m = $byRel[$Rel]
    if (-not $m) { throw "pom '$Rel' from the plan no longer exists." }
    $m
}

function Set-CompilerRelease($Model, [bool]$IsTop, [string]$Release) {
    $pom = $Model.Pom
    $props = $pom.Xml.DocumentElement['properties']
    if ($props) {
        foreach ($n in @($props.ChildNodes)) {
            if ($n.NodeType -eq [System.Xml.XmlNodeType]::Element -and $javaProps -contains $n.LocalName -and (Test-OlderLevel $n.InnerText $Release)) { $n.InnerText = $Release }
        }
    }
    if ($IsTop) { Set-PomProperty $pom 'maven.compiler.release' $Release }
    foreach ($pl in @($pom.Xml.SelectNodes("//*[local-name()='plugin']"))) {
        $aid = Get-ChildText $pl 'artifactId'
        if ($aid -eq 'maven-compiler-plugin') {
            foreach ($cfgEl in @($pl.SelectNodes(".//*[local-name()='configuration']"))) {
                foreach ($nm in 'source', 'target', 'release') {
                    $e = $cfgEl[$nm]
                    if ($e -and (Test-OlderLevel $e.InnerText $Release)) { $e.InnerText = $Release }
                }
            }
        }
        if ($aid -eq 'maven-enforcer-plugin') {
            foreach ($rj in @($pl.SelectNodes(".//*[local-name()='requireJavaVersion']/*[local-name()='version']"))) {
                $lo = [regex]::Match($rj.InnerText, '^\[?\s*([\d.]+)'); if ($lo.Success -and (Test-OlderLevel $lo.Groups[1].Value)) { $rj.InnerText = "[$tj,)" }
            }
        }
    }
}

foreach ($c in $plan.changes) {
    if ($c.approved -ne $true) { $log.Add("SKIP  $($c.id) (not approved)"); continue }
    switch ($c.type) {
        'property' {
            foreach ($rel in @($c.poms)) { $m = Get-Model $rel; Set-PomProperty $m.Pom $c.property $c.to; $dirty[$rel] = $m }
            $log.Add("APPLY $($c.id) property $($c.property) -> $($c.to) in $(@($c.poms) -join ', ')")
        }
        'inline' {
            $m = Get-Model $c.pom
            $count = Set-InlineVersion $m.Pom $c.kind $c.groupId $c.artifactId $c.raw $c.to
            if ($count -gt 0) { $dirty[$c.pom] = $m; $log.Add("APPLY $($c.id) $($c.groupId):$($c.artifactId) $($c.raw) -> $($c.to) in $($c.pom) ($count place(s))") }
            else { Write-Warn2 "$($c.id): $($c.groupId):$($c.artifactId) with version '$($c.raw)' not found in $($c.pom) (changed since planning?)"; $log.Add("MISS  $($c.id)") }
        }
        'add-managed' {
            foreach ($rel in @($c.poms)) { $m = Get-Model $rel; $r = Set-PomManaged $m.Pom $c.kind $c.groupId $c.artifactId $c.to; $dirty[$rel] = $m }
            $log.Add("APPLY $($c.id) managed $($c.kind) $($c.groupId):$($c.artifactId):$($c.to) in $(@($c.poms) -join ', ')")
        }
        'add-dependency' {
            $m = Get-Model $c.pom
            if (Add-PomDependency $m.Pom $c.groupId $c.artifactId $c.to $c.scope) { $dirty[$c.pom] = $m; $log.Add("APPLY $($c.id) add $($c.groupId):$($c.artifactId):$($c.to) to $($c.pom)") }
            else { $log.Add("SKIP  $($c.id) already declared in $($c.pom)") }
        }
        'compiler-release' {
            foreach ($m in $models) { Set-CompilerRelease $m ($tops -contains $m) "$($c.to)"; $dirty[$m.Rel] = $m }
            $log.Add("APPLY $($c.id) compiler release $($c.to) (build JDK $tj, role $($c.role))")
        }
        'source-encoding' {
            foreach ($rel in @($c.poms)) { $m = Get-Model $rel; Set-PomProperty $m.Pom 'project.build.sourceEncoding' $c.to; Set-PomProperty $m.Pom 'project.reporting.outputEncoding' $c.to }
            $log.Add("APPLY $($c.id) project.build.sourceEncoding=$($c.to)")
        }
        default { Write-Warn2 "unknown change type $($c.type)" }
    }
}

$saved = 0
foreach ($m in $models) {
    if ($m.Pom.Xml.OuterXml -ne $before[$m.Rel]) { Save-Pom $m.Pom; $saved++ }   # only touch poms that really changed
}
Write-Info "$saved pom.xml file(s) modified"

$log | Set-Content -LiteralPath (Get-WorkFile $ctx 'apply-log.txt') -Encoding utf8NoBOM
$log | ForEach-Object { Write-Info $_ }

$code = Invoke-Maven $ctx '21' @('-q', 'validate') 'apply-validate.log'
if ($code -ne 0) { throw "mvn validate failed on JDK 21 after pom edits - see $($ctx.Config.workDir)/logs/apply-validate.log (git diff shows the edits; 'git checkout -- .' reverts)." }
Write-Good 'poms valid on JDK 21'
Save-Commit $ctx 'jdk21: upgrade dependencies/plugins and compiler level (approved plan)'
Set-PhaseDone $ctx '06-apply-poms'
