#requires -Version 7.0
# 09 - Run the full test suite on JDK 21 and compare with the JDK 8 baseline.
#      Regressions (green on 8, red on 21) are fixed per test class by Copilot.
#      Integrity guard: any edit that disables tests or touches assertions is reverted.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step '09 Tests on JDK 21 vs JDK 8 baseline'

$baseline = Read-JsonFile (Get-WorkFile $ctx 'baseline-tests.json')
$baseTests = if ($baseline) { $baseline.tests } else { @{} }
if (-not $baseline) { Write-Warn2 'No JDK 8 baseline - every failing test is treated as a regression.' }

# index of java sources: "com/x/Foo.java" -> repo-relative paths
$javaIndex = @{}
foreach ($f in @(Get-RepoFiles $ctx { param($f) $f.Extension -eq '.java' })) {
    $rel = Get-RelPath $ctx $f.FullName
    $m = [regex]::Match($rel, 'src/(main|test)/java/(.+)$')
    if (-not $m.Success) { continue }
    $k = $m.Groups[2].Value
    if (-not $javaIndex.ContainsKey($k)) { $javaIndex[$k] = @() }
    $javaIndex[$k] += $rel
}
function Find-Source([string]$Fqn, [string]$Kind) {
    $k = (($Fqn -replace '\$.*$', '') -replace '\.', '/') + '.java'
    @($javaIndex[$k] | Where-Object { $_ -and $_ -match "src/$Kind/java/" }) | Select-Object -First 1
}
function Test-TestIntegrity([string]$Rel) {
    $diff = @(Invoke-Git $ctx @('diff', '-U0', '--', $Rel))
    $added = @($diff | Where-Object { $_ -match '^\+(?!\+\+)' })
    $removed = @($diff | Where-Object { $_ -match '^-(?!--)' })
    $bad = @($added | Where-Object { $_ -match '@Ignore|@Disabled|\bAssume\.|assumeTrue|assumeFalse|@DisabledOnJre|@EnabledOnJre|@DisabledForJreRange' }) +
    @($removed | Where-Object { $_ -match '\bassert|\bverify\s*\(|@Test\b|\bexpect' })
    $bad.Count -eq 0
}

$needsHuman = [System.Collections.Generic.List[string]]::new()
$opens = [ordered]@{}
$round = 0
$results = @{}; $regressions = @(); $notRun = @(); $stillFailing = @()

while ($true) {
    $round++
    $logName = "test-r$round.log"
    $code = Invoke-Maven $ctx '21' @('clean', $cfg.testGoal, '-fae', '-Dmaven.test.failure.ignore=true') $logName
    $results = Get-TestResults $ctx
    $sum = Get-TestSummary $results
    Write-Info "JDK 21 tests: $($sum.total) total | $($sum.pass) pass | $($sum.fail) fail | $($sum.error) error | $($sum.skipped) skipped"

    $regressions = @($results.Keys | Where-Object {
            $results[$_].status -in 'fail', 'error' -and (-not $baseTests.ContainsKey($_) -or $baseTests[$_].status -notin 'fail', 'error')
        })
    $stillFailing = @($results.Keys | Where-Object { $results[$_].status -in 'fail', 'error' -and $baseTests.ContainsKey($_) -and $baseTests[$_].status -in 'fail', 'error' })
    $notRun = @($baseTests.Keys | Where-Object { $baseTests[$_].status -eq 'pass' -and -not $results.ContainsKey($_) })

    $logText = Get-Content -LiteralPath (Join-Path $ctx.Logs $logName) -Raw
    foreach ($src in @($logText) + @($results.Values | ForEach-Object { $_.message })) {
        foreach ($mm in [regex]::Matches("$src", 'module (\S+) does not "(opens|exports) ([\w.]+)" to unnamed module')) {
            $opens["--add-$($mm.Groups[2].Value) $($mm.Groups[1].Value)/$($mm.Groups[3].Value)=ALL-UNNAMED"] = $true
        }
    }
    if ($code -ne 0 -and -not $regressions.Count) {
        $tail = ($logText -split "`r?`n" | Where-Object { $_ -match '^\[ERROR\]' } | Select-Object -First 15) -join "`n"
        throw "Build failed on JDK 21 for a reason other than tests (packaging / plugin?):`n$tail"
    }
    if ($baseTests.Count -and $notRun.Count -gt [Math]::Max(5, 0.2 * $baseTests.Count)) {
        $needsHuman.Add("$($notRun.Count) tests that ran on JDK 8 did not run on JDK 21 - check surefire provider / JUnit vintage engine / forkCount settings.")
    }
    Write-Info "regressions: $($regressions.Count) | failing before and after: $($stillFailing.Count) | not run anymore: $($notRun.Count)"
    if (-not $regressions.Count) { Write-Good 'no test regressions vs JDK 8'; break }
    if ($round -gt $cfg.maxTestFixRounds) { Write-Warn2 "regressions remain after $($cfg.maxTestFixRounds) fix round(s) - see report."; break }

    $byClass = $regressions | Group-Object { $results[$_].className } | Select-Object -First $cfg.maxTestClassesPerRound

    if (Test-ChatMode $ctx) {
        # one batch task per test run (each rerun costs a full test run)
        $nm = "testfix-batch-$(Get-ShortHash ((@($regressions | Sort-Object)) -join '|'))"
        if (Test-Path -LiteralPath (Join-Path $ctx.Work "agent-io/$nm.final.json")) { Write-Warn2 "same regressions remain after AI task $nm - leaving them for a human."; break }
        $done = @(Get-ChildItem -LiteralPath (Join-Path $ctx.Work 'agent-io') -Filter 'testfix-batch-*.final.json' -ErrorAction SilentlyContinue).Count
        if ($done -ge $cfg.maxTestFixRounds) { Write-Warn2 "regressions remain after $done AI batch(es) - see report."; break }
        $writableAll = [System.Collections.Generic.List[string]]::new(); $blocks = [System.Collections.Generic.List[string]]::new()
        foreach ($grp in $byClass) {
            $testRel = Find-Source $grp.Name 'test'
            if (-not $testRel) { $needsHuman.Add("$($grp.Name): test source not found"); continue }
            if (-not $writableAll.Contains($testRel)) { $writableAll.Add($testRel) }
            $blk = "### $($grp.Name)  (file: $testRel)"
            foreach ($key in @($grp.Group | Select-Object -First 3)) {
                $msg = "$($results[$key].message)"; if ($msg.Length -gt 1200) { $msg = $msg.Substring(0, 1200) + ' ...' }
                $blk += "`n#### $key`n$msg"
                foreach ($fm in [regex]::Matches($msg, 'at ([\w.$]+)\.[\w$<>]+\([\w$]+\.java:\d+\)')) {
                    $pth = Find-Source $fm.Groups[1].Value 'main'
                    if ($pth -and -not $writableAll.Contains($pth) -and $writableAll.Count -lt 25) { $writableAll.Add($pth) }
                }
            }
            $blocks.Add($blk)
        }
        if (-not $writableAll.Count) { break }
        $hint = if ($opens.Count) { "Encapsulation errors were seen; candidate JVM flags: $(@($opens.Keys) -join ' ')" } else { '' }
        $task = @"
These tests pass on the JDK 8 baseline but fail on JDK $($ctx.TargetJdk). Find and fix each JDK incompatibility.
$hint

$($blocks -join "`n`n")

Rules:
1. Root cause first: (a) production code using a JDK API whose behaviour changed (default charset UTF-8, CLDR locale data, removed API, strong encapsulation, TLS, java.version format) or (b) the test relying on JDK internals or old mocking tricks.
2. (a) change production code so it behaves exactly as on JDK 8. (b) change only test setup or mocking.
3. Never change expected values, never delete/disable/skip tests, never loosen verifications (an automatic guard reverts such edits).
4. JVM flags, dependencies, pom changes or unlisted files: no edit, put it in needsHuman with the exact flag/dependency.
5. Mark lines to double-check with a comment starting JDK21-REVIEW:.
"@
        $null = Invoke-Copilot $ctx 'jdk21-test-fixer' $task @($writableAll) $nm @{ purpose = "Fix JDK $($ctx.TargetJdk) test regressions without changing business behaviour or weakening tests" }
        break
    }
    foreach ($grp in $byClass) {
        $cls = $grp.Name
        $testRel = Find-Source $cls 'test'
        if (-not $testRel) { $needsHuman.Add("${cls}: test source not found"); continue }
        $prod = [System.Collections.Generic.List[string]]::new()
        $details = [System.Collections.Generic.List[string]]::new()
        foreach ($key in @($grp.Group | Select-Object -First 3)) {
            $msg = "$($results[$key].message)"
            if ($msg.Length -gt 1500) { $msg = $msg.Substring(0, 1500) + ' ...' }
            $details.Add("### $key`n$msg")
            foreach ($fm in [regex]::Matches($msg, 'at ([\w.$]+)\.[\w$<>]+\([\w$]+\.java:\d+\)')) {
                $p = Find-Source $fm.Groups[1].Value 'main'
                if ($p -and -not $prod.Contains($p) -and $prod.Count -lt 4) { $prod.Add($p) }
            }
        }
        $writable = @($testRel) + @($prod)
        $hint = if ($opens.Count) { "Encapsulation errors were seen; candidate JVM flags: $(@($opens.Keys) -join ' ')" } else { '' }
        $task = @"
# Task: a test that passes on JDK 8 fails on JDK 21 - find and fix the JDK 21 incompatibility

Test class: $cls  (file: $testRel)
Files you may edit: $($writable -join ', ')
$hint

## Failures (JDK 21)
$($details -join "`n`n")

## Rules
1. Find the root cause first. Decide whether it is (a) production code using a JDK API whose behaviour changed (default charset UTF-8, CLDR locale data, removed API, strong encapsulation, TLS, java.version format), or (b) the test relying on JDK internals or test-tool limits (reflection into java.* classes, old Mockito/PowerMock tricks).
2. For (a) change production code so it behaves exactly as it did on JDK 8. For (b) change only test setup or mocking.
3. Never change expected values in assertions, never delete, disable or skip tests (no @Ignore, @Disabled, assumptions), never loosen verifications. Business behaviour must not change.
4. If the fix needs JVM flags (--add-opens), dependencies, pom changes or files not listed above, make no edit and print a separate line that starts with the marker NEEDS-HUMAN followed by a colon and the exact flag, dependency or reason.
5. Put a comment line starting with JDK21-REVIEW: above any change whose behaviour should be double-checked.
6. Finish by printing one line that starts with DONE followed by a colon, the root cause and the fix.
"@
        $res = Invoke-Copilot $ctx 'jdk21-test-fixer' $task $writable "testfix-r$round-$(Get-SafeName $cls)"
        foreach ($n in $res.NeedsHuman) { if (-not $needsHuman.Contains($n)) { $needsHuman.Add($n) } }
        if (-not (Test-TestIntegrity $testRel)) {
            Invoke-Git $ctx @('checkout', '--', $testRel) | Out-Null
            $needsHuman.Add("${cls}: AI edit touched assertions/disabled tests - reverted by integrity guard. Fix manually.")
            Write-Warn2 "integrity guard reverted $testRel"
            continue
        }
        $rev = Invoke-DiffReview $ctx $writable @{ purpose = "Fix JDK $($ctx.TargetJdk) regression in $cls without changing business behaviour or weakening the test"; failures = @($grp.Group | Select-Object -First 3) } "review-test-r$round-$(Get-SafeName $cls)"
        if ($rev.Verdict -eq 'reject' -or $rev.Risk -eq 'high') {
            Invoke-Git $ctx (@('checkout', '--') + $writable) | Out-Null
            $needsHuman.Add("${cls}: fix rejected by reviewer (risk $($rev.Risk)): $(@($rev.Reasons) -join '; ')")
            Write-Warn2 "reviewer rejected the fix for $cls - reverted"
        }
    }
}

$report = @{
    summary = (Get-TestSummary $results); baselineSummary = $(if ($baseline) { $baseline.summary } else { $null })
    regressions = @($regressions | ForEach-Object { @{ test = $_; message = $results[$_].message } })
    failingBeforeAndAfter = @($stillFailing); notRunAnymore = @($notRun)
    jvmFlagsNeeded = @($opens.Keys); needsHuman = @($needsHuman); rounds = $round
}
Save-JsonFile $report (Get-WorkFile $ctx 'test-results-jdk21.json')
Save-Commit $ctx 'jdk21: fixes for JDK 21 test regressions'
Set-PhaseDone $ctx '09-test-fix' $(if ($regressions.Count) { 'done-with-regressions' } else { 'done' })
