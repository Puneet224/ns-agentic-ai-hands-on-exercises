#requires -Version 7.0
# 01 - Baseline on JDK 8: full build + tests (the behaviour reference), resolved
#      dependency list, and jdeps/jdeprscan over the JDK 8 class files. No AI.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step '01 Baseline on JDK 8 (build, tests, dependency list, jdeps)'

$warnFlags = @('-Dmaven.compiler.showDeprecation=true', '-Dmaven.compiler.showWarnings=true')
$jv = $cfg.coverage.jacocoVersion
$goals = if ($cfg.coverage.enabled) { @('clean', "org.jacoco:jacoco-maven-plugin:${jv}:prepare-agent", $cfg.testGoal, "org.jacoco:jacoco-maven-plugin:${jv}:report") } else { @('clean', $cfg.testGoal) }
$code = Invoke-Maven $ctx '8' ($goals + @('-fae', '-Dmaven.test.failure.ignore=true') + $warnFlags) 'baseline-build.log'
if ($code -ne 0 -and $cfg.coverage.enabled -and (Select-String -LiteralPath (Join-Path $ctx.Logs 'baseline-build.log') -Pattern 'jacoco' -SimpleMatch -Quiet)) {
    Write-Warn2 "build with JaCoCo $jv failed (plugin not in company repo?) - retrying without coverage"
    $code = Invoke-Maven $ctx '8' (@('clean', $cfg.testGoal, '-fae', '-Dmaven.test.failure.ignore=true') + $warnFlags) 'baseline-build.log'
}
$results = Get-TestResults $ctx
$sum = Get-TestSummary $results
Save-JsonFile @{ exitCode = $code; summary = $sum; tests = $results } (Get-WorkFile $ctx 'baseline-tests.json')
Write-Info "JDK 8 tests: $($sum.total) total | $($sum.pass) pass | $($sum.fail) fail | $($sum.error) error | $($sum.skipped) skipped"
if ($code -ne 0) {
    throw "Project does not build on JDK 8 (exit $code). Fix the baseline first, or run the pipeline with -SkipBaseline (no before/after test comparison then). Log: $($cfg.workDir)/logs/baseline-build.log"
}

# coverage (behaviour protection) and deprecation warnings on the current JDK
$cov = Get-JacocoCoverage $ctx
Save-JsonFile $cov (Get-WorkFile $ctx 'coverage-baseline.json')
if ($cfg.coverage.enabled) {
    if ($cov.Count) { $c = 0; $mi = 0; foreach ($v in $cov.Values) { $c += $v.covered; $mi += $v.missed }; Write-Info "line coverage (JDK 8 baseline): $([Math]::Round(100.0 * $c / [Math]::Max(1, $c + $mi), 1))% over $($cov.Count) files" }
    else { Write-Warn2 'no JaCoCo data - surefire <argLine> may override the agent (use @{argLine} in the pom).' }
}
$dep = @(Get-DeprecationWarnings (Join-Path $ctx.Logs 'baseline-build.log') $ctx)
Save-JsonFile @{ list = $dep; summary = (Get-DeprecationSummary $dep) } (Get-WorkFile $ctx 'deprecations-before.json')
Write-Info "deprecation warnings on current JDK: $($dep.Count)"
$null = Get-DependencyTree $ctx '8' 'tree-before.json'

$depFile = Get-WorkFile $ctx 'deps-before.txt'
Remove-Item -LiteralPath $depFile -ErrorAction SilentlyContinue
$code = Invoke-Maven $ctx '8' @('dependency:list', "-DoutputFile=$depFile", '-DappendOutput=true') 'baseline-deplist.log'
if ($code -ne 0) { Write-Warn2 'dependency:list failed - phase 02 will retry it.'; Remove-Item -LiteralPath $depFile -ErrorAction SilentlyContinue }

# jdeps / jdeprscan (from JDK 21) over the JDK 8 compiled classes
$jdeps = Get-JdkTool $ctx 'jdeps'
$jdeprscan = Get-JdkTool $ctx 'jdeprscan'
$internals = [System.Collections.Generic.List[string]]::new()
$removals = [System.Collections.Generic.List[string]]::new()
$classDirs = Get-ChildItem -LiteralPath $ctx.Repo -Recurse -Directory -Filter 'classes' -ErrorAction SilentlyContinue |
    Where-Object { $_.Parent.Name -eq 'target' -and $_.FullName -notmatch '[\\/]node_modules[\\/]' }
foreach ($d in $classDirs) {
    $rel = Get-RelPath $ctx $d.FullName
    $r = Invoke-Exe $jdeps @('--multi-release', $ctx.TargetJdk, '--jdk-internals', $d.FullName)
    foreach ($l in $r.Lines) { if ($l -match 'JDK internal API') { $internals.Add("$rel :: $($l.Trim())") } }
    $r2 = Invoke-Exe $jdeprscan @('--release', $ctx.TargetJdk, '--for-removal', $d.FullName)
    foreach ($l in $r2.Lines) { if ($l -match 'forRemoval=true') { $removals.Add("$rel :: $($l.Trim())") } }
}
$internals | Set-Content -LiteralPath (Get-WorkFile $ctx 'baseline-jdeps-internals.txt') -Encoding utf8NoBOM
$removals | Set-Content -LiteralPath (Get-WorkFile $ctx 'baseline-jdeprscan.txt') -Encoding utf8NoBOM
Write-Info "jdeps: $($internals.Count) JDK-internal API uses | jdeprscan: $($removals.Count) for-removal API uses"

Set-PhaseDone $ctx '01-baseline'
