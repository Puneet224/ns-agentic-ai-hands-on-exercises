#requires -Version 7.0
# 11 - Final report + server-team handoff. Optional Snyk re-check on JDK 21. No AI.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step '11 Report and server-team handoff'

if ($cfg.snykEnabled -and $cfg.snykRecheck -and -not (Test-Path -LiteralPath (Get-WorkFile $ctx 'snyk-after.json'))) {
    & (Join-Path $PSScriptRoot '04-snyk.ps1') -RepoPath $ctx.Repo -OutName 'snyk-after.json' -Jdk '21'
}
$state = Get-State $ctx
$compat = Read-JsonFile (Get-WorkFile $ctx 'compat.json')
$plan = Read-JsonFile (Get-WorkFile $ctx 'upgrade-plan.json')
$snyk = Read-JsonFile (Get-WorkFile $ctx 'snyk.json')
$snykAfter = Read-JsonFile (Get-WorkFile $ctx 'snyk-after.json')
$compile = Read-JsonFile (Get-WorkFile $ctx 'compile-fix.json')
$tests = Read-JsonFile (Get-WorkFile $ctx 'test-results-jdk21.json')
$inv = Read-JsonFile (Get-WorkFile $ctx 'inventory.json')

# ---- transitive dependency changes caused by the upgrade (before vs after)
$afterFile = Get-WorkFile $ctx 'deps-after.txt'
Remove-Item -LiteralPath $afterFile -ErrorAction SilentlyContinue
$null = Invoke-Maven $ctx '21' @('dependency:list', "-DoutputFile=$afterFile", '-DappendOutput=true') 'report-deplist-after.log' -Quiet
$before = Get-ResolvedDeps (Get-WorkFile $ctx 'deps-before.txt'); $after = Get-ResolvedDeps $afterFile
$depAdded = @($after.Keys | Where-Object { -not $before.ContainsKey($_) } | Sort-Object)
$depRemoved = @($before.Keys | Where-Object { -not $after.ContainsKey($_) } | Sort-Object)
$depChanged = @($after.Keys | Where-Object { $before.ContainsKey($_) -and ((@($before[$_]) -join ',') -ne (@($after[$_]) -join ',')) } | Sort-Object)
$treeAfter = @(Get-DependencyTree $ctx '21' 'tree-after.json')

# ---- deprecations, coverage
$depBefore = Read-JsonFile (Get-WorkFile $ctx 'deprecations-before.json')
$depAfter = Read-JsonFile (Get-WorkFile $ctx 'deprecations-after.json')
$cov = Read-JsonFile (Get-WorkFile $ctx 'coverage-baseline.json')
$aiChanged = if ($state.baseCommit) { @(Invoke-Git $ctx @('diff', '--name-only', "$($state.baseCommit)..HEAD") | Where-Object { $_ -match 'src/main/java/.*\.java$' }) } else { @() }
$riskFiles = @($compat.riskHits | Where-Object { -not $_.test } | ForEach-Object { $_.file } | Select-Object -Unique)
$watch = @(@($aiChanged) + @($riskFiles) | Select-Object -Unique)
$minCov = [double]$cfg.coverage.minLineCoverageForRiskFiles
$lowCov = @($watch | ForEach-Object {
        $c = if ($cov) { $cov[$_] } else { $null }
        $pct = if ($c) { [double]$c.pct } else { $null }
        if ($null -eq $pct -or $pct -lt $minCov) { @{ file = $_; pct = $pct; changed = ($aiChanged -contains $_); risk = ($riskFiles -contains $_) } }
    })

$base = $state.baseCommit
$stat = if ($base) { @(Invoke-Git $ctx @('diff', '--stat', "$base..HEAD", '--', '.', ":(exclude).github/jdk21-migration", ":(exclude).github/agents")) } else { @() }
$review = (Invoke-Exe 'git' @('grep', '-n', 'JDK21-REVIEW') -WorkingDir $ctx.Repo).Lines | Where-Object { $_ -and $_ -notmatch '^\.github/(jdk21-migration|agents)/' }

function Get-SevCount($s) {
    if (-not $s -or $s.skipped) { return 'n/a' }
    (@($s.findings | Group-Object { $_.severity } | ForEach-Object { "$($_.Name): $($_.Count)" }) -join ', ') -replace '^$', 'none'
}

# ---------------------------------------------------------------- final report
$md = [System.Collections.Generic.List[string]]::new()
$md.Add('# JDK 8 -> 21 migration report'); $md.Add('')
$md.Add("Repository: $(Split-Path -Leaf $ctx.Repo) | branch: $($cfg.branchName) | base commit: $base | generated: $((Get-Date).ToString('s'))"); $md.Add('')
$md.Add('## Status'); $md.Add('')
$md.Add("- Compile on JDK 21: $(if ($compile -and $compile.success) { 'YES' } elseif ($compile) { 'NO' } else { 'not run' })")
if ($tests) {
    $b = $tests.baselineSummary; $a = $tests.summary
    $md.Add("- Tests JDK 8: $(if ($b) { "$($b.pass)/$($b.total) pass" } else { 'no baseline' }) | JDK 21: $($a.pass)/$($a.total) pass")
    $md.Add("- Regressions (green on 8, red on 21): **$(@($tests.regressions).Count)** | failing on both: $(@($tests.failingBeforeAndAfter).Count) | no longer executed: $(@($tests.notRunAnymore).Count)")
}
$md.Add("- Snyk before: $(Get-SevCount $snyk) | after: $(Get-SevCount $snykAfter)")
$gate = Read-JsonFile (Get-WorkFile $ctx 'security-gate.json')
if ($gate) { $md.Add("- Security gate: **$($gate.status)** (evaluated: $(@($gate.evaluated) -join ', '); new >= $($gate.threshold): snyk $(@($gate.newSnyk).Count), checkmarx $(@($gate.newCheckmarx).Count); snyk findings fixed by upgrade: $($gate.snykFixedByUpgrade))") }
$cfix = Read-JsonFile (Get-WorkFile $ctx 'config-fix.json')
if ($cfix) { $md.Add("- Config files updated: $(@($cfix.applied).Count) | config items for a human: $(@($cfix.needsHuman).Count)") }
$md.Add(''); $md.Add('## Framework decision'); $md.Add('')
foreach ($f in @($compat.frameworks)) { $md.Add("- $($f.name) $($f.current): **$($f.status)** -> $($f.recommended). $($f.note)") }
if (-not @($compat.frameworks).Count) { $md.Add('- No tracked framework found; JDK 21 needs no framework upgrade here.') }
$md.Add('- javax -> jakarta migration: **not required** for JDK 21 (only for Spring 6 / Boot 3 / Tomcat 10+).')
$md.Add(''); $md.Add('## Applied plan changes'); $md.Add('')
foreach ($c in @($plan.changes | Where-Object { $_.approved })) {
    $what = if ($c.property) { "property $($c.property)" } elseif ($c.artifactId) { "$($c.groupId):$($c.artifactId)" } else { $c.type }
    $md.Add("- $($c.id) $($c.type): $what -> $($c.to)")
}
$md.Add(''); $md.Add('## Not applied / needs a human'); $md.Add('')
foreach ($c in @($plan.changes | Where-Object { -not $_.approved })) { $md.Add("- (not approved) $($c.id) $($c.groupId):$($c.artifactId) -> $($c.to): $($c.reason)") }
foreach ($m in @($plan.manual)) { $md.Add("- $($m.item): $($m.reason)") }
foreach ($n in @($compile.needsHuman) + @($tests.needsHuman) + @($cfix.needsHuman)) { if ($n) { $md.Add("- AI: $n") } }
foreach ($n in @($compile.reviewerSuggestedTests)) { if ($n) { $md.Add("- reviewer suggests test: $n") } }
$md.Add(''); $md.Add('## Internal shared libraries'); $md.Add('')
foreach ($l in @($compat.internalLibs)) { $md.Add("- $($l.key):$($l.version) [$($l.compiledFor)] -> $($l.status)") }
if (-not @($compat.internalLibs).Count) { $md.Add('- none found (check internalGroupIdPrefixes in config)') }
$md.Add(''); $md.Add('## Code changes'); $md.Add('')
$md.Add('```'); foreach ($s in $stat) { $md.Add($s) }; $md.Add('```')
$md.Add(''); $md.Add("### Lines marked JDK21-REVIEW ($(@($review).Count)) - verify each"); $md.Add('')
foreach ($r in @($review)) { $md.Add("- $r") }
$md.Add(''); $md.Add('## Behaviour-risk hotspots (compile fine, may behave differently)'); $md.Add('')
foreach ($grp in (@($compat.riskHits | Where-Object { -not $_.test }) | Group-Object { $_.id } | Sort-Object Count -Descending)) {
    $rule = $ctx.Rules.sourcePatterns | Where-Object { $_.id -eq $grp.Name } | Select-Object -First 1
    $md.Add("### $($grp.Name) [$($rule.severity)] - $($grp.Count) hit(s)"); $md.Add("$($rule.why) **Action:** $($rule.advice)"); $md.Add('')
    foreach ($hit in @($grp.Group | Select-Object -First 15)) { $md.Add("- $($hit.file):$($hit.line) ``$($hit.code)``") }
    if ($grp.Count -gt 15) { $md.Add("- ... $($grp.Count - 15) more in compat.json") }
    $md.Add('')
}
$md.Add('## Test regressions'); $md.Add('')
foreach ($r in @($tests.regressions)) { $md.Add("- $($r.test): $((("$($r.message)" -split "`n")[0]))") }
$md.Add(''); $md.Add('## Transitive dependency changes (before -> after)'); $md.Add('')
$md.Add("added: $($depAdded.Count) | removed: $($depRemoved.Count) | version changed: $($depChanged.Count)")
foreach ($k in $depChanged | Select-Object -First 40) { $md.Add("- $k : $(@($before[$k]) -join ',') -> $(@($after[$k]) -join ',')$(if ($w = @(Get-WhoBrings $treeAfter $k)[0]) { "  (via $w)" })") }
foreach ($k in $depAdded | Select-Object -First 20) { $md.Add("- added $k $(@($after[$k]) -join ',')") }
foreach ($k in $depRemoved | Select-Object -First 20) { $md.Add("- removed $k") }
$md.Add(''); $md.Add('## Deprecated API usage (javac)'); $md.Add('')
$md.Add("- before (current JDK): $(if ($depBefore) { "$($depBefore.summary.total) warnings, $($depBefore.summary.forRemoval) marked for removal" } else { 'n/a' }) | after (JDK $($ctx.TargetJdk)): $(if ($depAfter) { "$($depAfter.summary.total) warnings, $($depAfter.summary.forRemoval) marked for removal" } else { 'n/a' })")
foreach ($t in @($depAfter.summary.topApis | Select-Object -First 10)) { $md.Add("- $($t.count) x $($t.api)") }
$md.Add('- APIs *marked for removal* will break on a later JDK: plan them now (also listed by jdeprscan in baseline-jdeprscan.txt).')
$md.Add(''); $md.Add("## Test coverage of risky / changed code (threshold $minCov%)"); $md.Add('')
if (-not $cov -or -not $cov.Count) { $md.Add('- No JaCoCo data: passing tests cannot be taken as proof of unchanged behaviour.') }
foreach ($l in $lowCov | Select-Object -First 40) { $md.Add("- $($l.file): $(if ($null -eq $l.pct) { 'no coverage data' } else { "$($l.pct)%" })$(if ($l.changed) { ' [changed by migration]' })$(if ($l.risk) { ' [behaviour-risk]' }) -> add characterization tests") }
if ($cov -and $cov.Count -and -not $lowCov.Count) { $md.Add('- all risky/changed files are above the threshold') }
$md.Add(''); $md.Add("Repository role: **$($inv.role)**$(if ($inv.role -eq 'library') { ' - bytecode kept at the consumers'' level; release this version before migrating consuming apps.' })")
$md.Add(''); $md.Add('## Manual sign-off checklist'); $md.Add('')
$md.Add('- [ ] Reviewed `git diff` of every pom and source change')
$md.Add('- [ ] Every JDK21-REVIEW line verified')
$md.Add('- [ ] Charset/locale hotspots checked with real data (reports, files, exports, date/amount formatting)')
$md.Add('- [ ] End-to-end business flow smoke test on a JDK 21 environment')
$md.Add('- [ ] Server-team handoff sent (server-team-handoff.md)')
$md | Set-Content -LiteralPath (Get-WorkFile $ctx 'final-report.md') -Encoding utf8NoBOM

# ---------------------------------------------------------------- server handoff
$h = [System.Collections.Generic.List[string]]::new()
$h.Add("# Server team handoff - $(Split-Path -Leaf $ctx.Repo) on JDK 21"); $h.Add('')
$wars = @($inv.modules | Where-Object { $_.packaging -eq 'war' } | ForEach-Object { $_.artifactId })
$servlet = @($inv.resolvedDeps.Keys | Where-Object { $_ -match ':(javax\.servlet-api|servlet-api|jakarta\.servlet-api)$' } | ForEach-Object { "$_ $(@($inv.resolvedDeps[$_]) -join ',')" })
$h.Add('## 1. Runtime'); $h.Add('')
$h.Add('- Install JDK 21 (organisation-approved vendor/patch) and point the app server / service JAVA_HOME to it. Keep JDK 8 available for rollback until sign-off.')
$h.Add("- Deployable WAR module(s): $($wars -join ', ')")
$h.Add("- Servlet API used by the app: $(if ($servlet.Count) { $servlet -join '; ' } else { 'not detected' }). The app stays on the **javax.*** namespace, so the app server must support Java 21 **and** javax Servlet (e.g. a current Tomcat 9.0.x, or confirm in your vendor's support matrix). Tomcat 10+/jakarta servers will NOT run this WAR.")
$h.Add(''); $h.Add('## 2. JVM options found in this repo that must change'); $h.Add('')
$flags = @($compat.configHits | Where-Object { $_.category -eq 'jvm-flag' })
if (-not $flags.Count) { $h.Add('- None found in repo scripts. Please also check the server''s own setenv / service / domain config for the same flags.') }
foreach ($f in $flags) { $h.Add("- $($f.file):$($f.line) ``$($f.match)`` - $($f.why). **$($f.advice)**") }
$h.Add(''); $h.Add('Also check the server-side config (not in this repo) for: -XX:PermSize/MaxPermSize, CMS/ParNew GC flags, -XX:+PrintGC*/-Xloggc (use -Xlog:gc*), -Djava.endorsed.dirs, --illegal-access.')
$h.Add(''); $h.Add('## 3. Flags the application may need'); $h.Add('')
$needFlags = @($tests.jvmFlagsNeeded)
if ($needFlags.Count) { foreach ($f in $needFlags) { $h.Add("- ``$f``  (seen in JDK 21 test runs: strong encapsulation)") } } else { $h.Add('- No --add-opens/--add-exports needed according to the test run.') }
$charset = @($compat.riskHits | Where-Object { $_.id -eq 'default-charset' -and -not $_.test }).Count
$locale = @($compat.riskHits | Where-Object { $_.id -eq 'locale-format' -and -not $_.test }).Count
if ($charset) { $h.Add("- Default charset: JDK 18+ uses UTF-8 by default (JDK 8 used the OS encoding). $charset code location(s) rely on the default. Until verified, start with ``-Dfile.encoding=COMPAT`` (or the explicit old encoding) - decide together with the app team.") }
if ($locale) { $h.Add("- Locale data: $locale formatting location(s). If date/number output must stay byte-identical, temporarily add ``-Djava.locale.providers=COMPAT,CLDR`` (COMPAT is removed in JDK 23).") }
if (@($compat.riskHits | Where-Object { $_.id -eq 'security-manager' }).Count -or @($compat.configHits | Where-Object { $_.id -eq 'security-manager-flag' }).Count) {
    $h.Add('- Security Manager in use: JDK 21 needs ``-Djava.security.manager=allow`` to install one (deprecated for removal).')
}
$agents = @($compat.configHits | Where-Object { $_.id -eq 'java-agent' })
$h.Add(''); $h.Add('## 3b. Java agents (APM / profilers / coverage)'); $h.Add('')
if ($agents.Count) { foreach ($a2 in $agents) { $h.Add("- $($a2.file):$($a2.line) ``$($a2.match)`` - confirm this agent version supports JDK $($ctx.TargetJdk); upgrade it together with the JDK.") } }
$h.Add('- Also check agents configured only on the servers (AppDynamics, Dynatrace, New Relic, Elastic APM, Contrast, etc.).')
$h.Add(''); $h.Add('## 4. Certificates and TLS'); $h.Add('')
$h.Add('- Re-import every internal/partner CA certificate that was added to the JDK 8 `cacerts` into the JDK 21 `cacerts` (or keep an external truststore via -Djavax.net.ssl.trustStore).')
$h.Add('- TLS 1.0/1.1 are disabled by default in JDK 21. Confirm all outbound integrations (DB, MQ, SMTP, partner APIs) support TLS 1.2+.')
if (@($compat.riskHits | Where-Object { $_.id -eq 'old-tls' }).Count) { $h.Add('- The code explicitly requests old TLS/SSL protocol names - see final-report.md.') }
$h.Add(''); $h.Add('## 5. GC and memory'); $h.Add('')
$h.Add('- Default GC is G1. Re-baseline heap sizing and GC logging (-Xlog) during performance testing.')
$h.Add(''); $h.Add('## 6. CI / build agents'); $h.Add('')
$ci = @($compat.configHits | Where-Object { $_.category -eq 'ci' })
foreach ($c in $ci) { $h.Add("- $($c.file):$($c.line) ``$($c.match)`` -> switch to JDK 21") }
if (-not $ci.Count) { $h.Add('- No Java 8 pins found in repo CI files; check the build agent JDK.') }
$h | Set-Content -LiteralPath (Get-WorkFile $ctx 'server-team-handoff.md') -Encoding utf8NoBOM

# ---------------------------------------------------------------- release readiness (needs your environment)
$ser = @($compat.riskHits | Where-Object { $_.id -eq 'serialization' -and -not $_.test })
$r = [System.Collections.Generic.List[string]]::new()
$r.Add("# Release readiness - $(Split-Path -Leaf $ctx.Repo) on JDK $($ctx.TargetJdk)"); $r.Add('')
$r.Add('## 1. Runtime validation (not covered by unit tests)'); $r.Add('')
$r.Add('- [ ] Deploy the branch build to a JDK ' + $ctx.TargetJdk + ' test environment with production-like config, agents and JVM options')
$r.Add('- [ ] Smoke test every entry point (UI pages, REST/SOAP endpoints, batch jobs, schedulers, MQ listeners)')
$r.Add('- [ ] Run the E2E / regression suite owned by QA; watch logs for InaccessibleObjectException, NoClassDefFoundError, ClassNotFoundException, IllegalAccessError')
$r.Add(''); $r.Add('## 2. Golden-master comparison (same input, JDK 8 vs JDK ' + $ctx.TargetJdk + ')'); $r.Add('')
$r.Add('- [ ] Pick 10-20 representative business transactions / reports / file exports')
$r.Add('- [ ] Run each on the old and the new build with identical input and data; diff the outputs byte by byte (files, generated PDFs/CSVs, emails, DB rows, API responses)')
$r.Add("- [ ] Focus on the $(@($compat.riskHits | Where-Object { $_.id -in 'default-charset','locale-format' -and -not $_.test }).Count) charset/locale hotspots in final-report.md (non-ASCII names, amounts, dates, Indian number grouping)")
$r.Add(''); $r.Add('## 3. Mixed-version cluster / serialization'); $r.Add('')
$r.Add("- Serialization-related code locations found: $($ser.Count) (sessions, caches, RMI/JMS payloads)")
foreach ($sx in $ser | Select-Object -First 15) { $r.Add("  - $($sx.file):$($sx.line) ``$($sx.code)``") }
$r.Add('- [ ] Decide: rolling deploy (old and new nodes share sessions/caches) only after testing replication between a JDK 8 and a JDK ' + $ctx.TargetJdk + ' node; otherwise plan a full cut-over or drain sessions')
$r.Add(''); $r.Add('## 4. Performance baseline'); $r.Add('')
$r.Add('| metric | JDK 8 | JDK ' + $ctx.TargetJdk + ' | delta | ok? |'); $r.Add('|---|---|---|---|---|')
foreach ($mt in 'p95 response time (key transaction)', 'throughput (tps)', 'heap used after GC', 'GC pause p99', 'CPU %', 'startup time', 'container memory (RSS)') { $r.Add("| $mt |  |  |  |  |") }
$r.Add('- Same load profile on both; G1 is the default GC on the new JDK; in containers prefer -XX:MaxRAMPercentage over fixed -Xmx')
$r.Add(''); $r.Add('## 5. Rollout and rollback'); $r.Add('')
$r.Add('- [ ] Canary or blue/green; keep the JDK 8 runtime and the previous artifact deployable until sign-off')
$r.Add('- [ ] Rollback runbook tested (JAVA_HOME switch, previous WAR, config/flags)')
$r.Add('- [ ] Monitoring/alerting verified on the new JVM (APM agent reporting, GC logs, heap dumps path)')
$r.Add('- [ ] Change record / CAB evidence: final-report.md, security-gate.json, test results, this checklist')
if ($inv.role -eq 'library') { $r.Add('- [ ] Library: publish this version first; consuming applications migrate afterwards (see portfolio-order.md)') }
$r | Set-Content -LiteralPath (Get-WorkFile $ctx 'release-readiness-checklist.md') -Encoding utf8NoBOM
Write-Good "$($cfg.workDir)/release-readiness-checklist.md"
if ($lowCov.Count -and $cfg.coverage.mode -eq 'fail') { throw "Coverage gate: $($lowCov.Count) risky/changed file(s) below $minCov% line coverage - see final-report.md" }

Write-Good "$($cfg.workDir)/final-report.md"
Write-Good "$($cfg.workDir)/server-team-handoff.md"
Set-PhaseDone $ctx '11-report'
