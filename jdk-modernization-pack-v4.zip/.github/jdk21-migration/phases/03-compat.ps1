#requires -Version 7.0
# 03 - JDK 21 compatibility analysis. No AI.
#   a) dependency/plugin minimum versions     d) source scan: removed APIs + behaviour risks
#   b) blockers (PowerMock, cglib, ...)       e) config scan: JVM flags in dist/scripts, CI JDK pins
#   c) framework decision (Spring/Boot/Hib.)  f) internal shared libraries (jdeps/jdeprscan on jars)
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$rules = $ctx.Rules
Write-Step '03 Compatibility scan'

$inv = Read-JsonFile (Get-WorkFile $ctx 'inventory.json')
if (-not $inv) { throw 'inventory.json missing - run phase 02 first.' }
$models = @(Get-PomModels $ctx)

function Add-ToPool($Pool, [string]$Key, [string]$Version) {
    if (-not $Key) { return }
    if (-not $Pool.ContainsKey($Key)) { $Pool[$Key] = @() }
    if ($Version -and $Pool[$Key] -notcontains $Version) { $Pool[$Key] += $Version }
}
function Test-RuleMatch($Rule, [string]$G, [string]$A) {
    if ($Rule.groupId -and $Rule.groupId -ne $G) { return $false }
    if ($Rule.groupIdRegex -and $G -notmatch $Rule.groupIdRegex) { return $false }
    if ($Rule.artifactId -and $Rule.artifactId -ne $A) { return $false }
    if ($Rule.artifactIdRegex -and $A -notmatch $Rule.artifactIdRegex) { return $false }
    $true
}

# pools: key -> versions (resolved + declared)
$depPool = @{}; $pluginPool = @{}
foreach ($k in $inv.resolvedDeps.Keys) { foreach ($v in @($inv.resolvedDeps[$k])) { Add-ToPool $depPool $k $v } }
foreach ($k in $inv.effectivePlugins.Keys) { foreach ($v in @($inv.effectivePlugins[$k])) { Add-ToPool $pluginPool $k $v } }
foreach ($it in $inv.items) {
    $k = "$($it.GroupId):$($it.ArtifactId)"
    if ($it.Kind -eq 'plugin') { Add-ToPool $pluginPool $k $it.Version } else { Add-ToPool $depPool $k $it.Version }
}

$versionFindings = [System.Collections.Generic.List[object]]::new()
$seen = @{}
function Add-VersionFinding([string]$Type, [string]$Kind, [string]$G, [string]$A, [string]$Current, [string]$Target, [string]$Why) {
    $id = "$Type|${G}:${A}|$Current"
    if ($seen.ContainsKey($id)) { return }
    $seen[$id] = $true
    $versionFindings.Add(@{ type = $Type; kind = $Kind; groupId = $G; artifactId = $A; current = $Current; target = $Target; why = $Why })
}

# a) minimum versions
foreach ($rule in $rules.minVersions) {
    $pool = if ($rule.kind -eq 'plugin') { $pluginPool } else { $depPool }
    foreach ($k in @($pool.Keys)) {
        $g, $a = $k.Split(':', 2)
        if (-not (Test-RuleMatch $rule $g $a)) { continue }
        foreach ($v in @($pool[$k])) {
            if ($v -and (Compare-MavenVersion $v $rule.min) -lt 0) { Add-VersionFinding 'jdk21-min' $rule.kind $g $a $v $rule.min $rule.why }
        }
    }
}

# b) blockers
$blockers = [System.Collections.Generic.List[object]]::new()
foreach ($rule in $rules.blockers) {
    foreach ($k in @($depPool.Keys)) {
        $g, $a = $k.Split(':', 2)
        if (Test-RuleMatch $rule $g $a) { $blockers.Add(@{ key = $k; versions = @($depPool[$k]); why = $rule.why; advice = $rule.advice }) }
    }
}

# c) frameworks
$frameworks = [System.Collections.Generic.List[object]]::new()
foreach ($fw in $rules.frameworks) {
    $vers = @(@($depPool["$($fw.groupId):$($fw.probeArtifactId)"]) | Where-Object { $_ })
    if (-not $vers.Count) { continue }
    $cur = Get-MinVersion $vers
    $status = 'ok'
    if ((Compare-MavenVersion $cur $fw.lineUpgradeBelow) -lt 0) { $status = 'line-upgrade-required' }
    elseif ((Compare-MavenVersion $cur $fw.recommended) -lt 0) { $status = 'patch-upgrade' }
    $frameworks.Add(@{ name = $fw.name; current = $cur; status = $status; recommended = $fw.recommended; note = $fw.note })
    if ($status -eq 'ok') { continue }
    $type = if ($status -eq 'patch-upgrade') { 'framework-align' } else { 'framework-line-upgrade' }
    foreach ($k in @($depPool.Keys)) {
        $g, $a = $k.Split(':', 2)
        if ($g -ne $fw.alignGroupId -or $a -notmatch $fw.alignArtifactRegex) { continue }
        foreach ($v in @($depPool[$k])) {
            if ($v -and (Compare-MavenVersion $v $fw.recommended) -lt 0) {
                Add-VersionFinding $type 'dependency' $g $a $v $fw.recommended "$($fw.name): $status to $($fw.recommended)"
            }
        }
    }
}

# d) source scan
$removedHits = [System.Collections.Generic.List[object]]::new()
$riskHits = [System.Collections.Generic.List[object]]::new()
$srcExt = @('.java', '.jsp', '.jspf', '.tag')
$srcFiles = @(Get-RepoFiles $ctx { param($f) $srcExt -contains $f.Extension.ToLowerInvariant() })
Write-Info "scanning $($srcFiles.Count) source files"
foreach ($f in $srcFiles) {
    $text = [IO.File]::ReadAllText($f.FullName)
    $rel = Get-RelPath $ctx $f.FullName
    $isTest = $rel -match '(^|/)src/test/'
    $mod = Get-ModuleForFile $models $f.FullName
    $lines = $null
    foreach ($r in $rules.removedJdkApis) {
        if ($text -match $r.regex) { $removedHits.Add(@{ id = $r.id; file = $rel; module = $(if ($mod) { $mod.Rel } else { 'pom.xml' }); test = $isTest }) }
    }
    foreach ($r in $rules.sourcePatterns) {
        if ($text -notmatch $r.regex) { continue }
        if (-not $lines) { $lines = $text -split "`r?`n" }
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -match $r.regex) {
                $code = $lines[$i].Trim(); if ($code.Length -gt 160) { $code = $code.Substring(0, 160) }
                $riskHits.Add(@{ id = $r.id; severity = $r.severity; file = $rel; line = $i + 1; code = $code; test = $isTest })
            }
        }
    }
}

# e) config scan (JVM flags in dist/startup scripts, surefire argLine, CI JDK pins)
$cs = $rules.configScan
$cfgFiles = @(Get-RepoFiles $ctx {
        param($f)
        ($cs.extensions -contains $f.Extension.ToLowerInvariant()) -or ($cs.fileNames -contains $f.Name) -or
        (@($cs.namePrefixes | Where-Object { $f.Name.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) }).Count -gt 0)
    })
$configHits = [System.Collections.Generic.List[object]]::new()
$flagRules = @($rules.jvmFlags | ForEach-Object { $_.category = 'jvm-flag'; $_ }) + @($rules.ciPatterns | ForEach-Object { $_.category = 'ci'; $_ })
foreach ($f in $cfgFiles) {
    if ($f.Length -gt 2MB) { continue }
    $text = [IO.File]::ReadAllText($f.FullName)
    $rel = Get-RelPath $ctx $f.FullName
    $lines = $null
    foreach ($r in $flagRules) {
        if ($text -notmatch $r.regex) { continue }
        if (-not $lines) { $lines = $text -split "`r?`n" }
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $m = [regex]::Match($lines[$i], $r.regex)
            if ($m.Success) {
                $configHits.Add(@{ id = $r.id; category = $r.category; file = $rel; line = $i + 1; match = $m.Value; why = $r.why; advice = $r.advice })
            }
        }
    }
}

# f) internal shared libraries
$internalLibs = [System.Collections.Generic.List[object]]::new()
$prefixes = @($ctx.Config.internalGroupIdPrefixes | Where-Object { $_ })
$jdeps = Get-JdkTool $ctx 'jdeps'
$jdeprscan = Get-JdkTool $ctx 'jdeprscan'
foreach ($k in @($inv.resolvedDeps.Keys)) {
    $g, $a = $k.Split(':', 2)
    if (-not @($prefixes | Where-Object { $g.StartsWith($_) }).Count) { continue }
    foreach ($v in @($inv.resolvedDeps[$k])) {
        $jar = Join-Path $ctx.Config.localRepo ((($g -replace '\.', '/')) + "/$a/$v/$a-$v.jar")
        if (-not (Test-Path -LiteralPath $jar)) { $internalLibs.Add(@{ key = $k; version = $v; status = 'jar-not-found'; jar = $jar }); continue }
        $major = Get-JarClassMajor $jar
        $int = @((Invoke-Exe $jdeps @('--multi-release', $ctx.TargetJdk, '--jdk-internals', $jar)).Lines | Where-Object { $_ -match 'JDK internal API' } | ForEach-Object { $_.Trim() })
        $dep = @((Invoke-Exe $jdeprscan @('--release', $ctx.TargetJdk, '--for-removal', $jar)).Lines | Where-Object { $_ -match 'forRemoval=true' } | ForEach-Object { $_.Trim() })
        $miss = [System.Collections.Generic.List[string]]::new()
        $cls = (Invoke-Exe $jdeps @('--multi-release', $ctx.TargetJdk, '-verbose:class', $jar)).Lines
        foreach ($l in $cls) {
            $mm = [regex]::Match($l, '->\s+(\S+)\s+not found')
            if (-not $mm.Success) { continue }
            foreach ($r in $rules.removedJdkApis) { if ($mm.Groups[1].Value -match $r.regex -and -not $miss.Contains($r.id)) { $miss.Add($r.id) } }
        }
        $status = if ($int.Count -or $dep.Count) { 'owner-action' } elseif ($miss.Count) { 'needs-runtime-deps' } else { 'ok' }
        $internalLibs.Add(@{
                key = $k; version = $v; status = $status; compiledFor = $major
                jdkInternals = @($int | Select-Object -First 20); forRemoval = @($dep | Select-Object -First 20); removedApis = @($miss)
            })
    }
}

# g) ALL third-party jars (transitive included): class-file level, JDK internals, removed JDK APIs
$tree = @(Read-JsonFile (Get-WorkFile $ctx 'tree-before.json'))
$thirdParty = [System.Collections.Generic.List[object]]::new()
if ($ctx.Config.scanThirdPartyJars) {
    $keys = @($inv.resolvedDeps.Keys | Where-Object { $g = $_.Split(':')[0]; -not @($prefixes | Where-Object { $g.StartsWith($_) }).Count } | Sort-Object | Select-Object -First $ctx.Config.maxThirdPartyJarsToScan)
    Write-Info "scanning $($keys.Count) third-party jars (class version, JDK internals, removed APIs)"
    foreach ($k in $keys) {
        $g, $a = $k.Split(':', 2)
        foreach ($v in @($inv.resolvedDeps[$k])) {
            $jar = Get-LocalJar $ctx $g $a $v
            if (-not (Test-Path -LiteralPath $jar)) { continue }
            $major = Get-JarClassMajor $jar
            $feature = if ($major) { [int]($major -replace '\D', '') } else { $null }
            $lines = (Invoke-Exe $jdeps @('--multi-release', $ctx.TargetJdk, '-verbose:class', $jar)).Lines
            $internal = @($lines | Where-Object { $_ -match 'JDK internal API' } | ForEach-Object { ($_ -replace '\s+', ' ').Trim() } | Select-Object -Unique -First 10)
            $miss = [System.Collections.Generic.List[string]]::new()
            foreach ($l in $lines) {
                $mm = [regex]::Match($l, '->\s+(\S+)\s+not found')
                if (-not $mm.Success) { continue }
                foreach ($r in $rules.removedJdkApis) { if ($mm.Groups[1].Value -match $r.regex -and -not $miss.Contains($r.id)) { $miss.Add($r.id) } }
            }
            $issues = @()
            if ($feature -and $feature -gt [int]$ctx.TargetJdk) { $issues += 'class-version-too-high' }
            if ($miss.Count) { $issues += 'needs-runtime-deps' }
            if ($internal.Count) { $issues += 'uses-jdk-internals' }
            if (-not $issues.Count) { continue }
            $thirdParty.Add(@{ key = $k; version = $v; compiledFor = $major; issues = $issues; removedApis = @($miss); jdkInternals = $internal; broughtBy = @(Get-WhoBrings $tree $k) })
        }
    }
}
$divergent = @($inv.divergentVersions)

# app class analysis from baseline (if phase 01 ran)
$appInternals = @(Get-Content -LiteralPath (Get-WorkFile $ctx 'baseline-jdeps-internals.txt') -ErrorAction SilentlyContinue)
$appRemovals = @(Get-Content -LiteralPath (Get-WorkFile $ctx 'baseline-jdeprscan.txt') -ErrorAction SilentlyContinue)

$compat = @{
    versionFindings = @($versionFindings); blockers = @($blockers); frameworks = @($frameworks)
    removedApiHits = @($removedHits); riskHits = @($riskHits); configHits = @($configHits)
    internalLibs = @($internalLibs); appJdkInternals = $appInternals; appForRemoval = $appRemovals
    thirdPartyJars = @($thirdParty); divergentVersions = $divergent; encoding = $inv.encoding; role = $inv.role
}
Save-JsonFile $compat (Get-WorkFile $ctx 'compat.json')

# human-readable summary (also input for the AI plan reviewer)
$md = [System.Collections.Generic.List[string]]::new()
$md.Add('# JDK 21 compatibility summary'); $md.Add('')
$md.Add('## Framework decision'); $md.Add('')
if (-not $frameworks.Count) { $md.Add('No tracked framework (Spring / Spring Boot / Spring Security / Hibernate) detected.') }
foreach ($f in $frameworks) { $md.Add("- **$($f.name)** $($f.current) -> status **$($f.status)** (recommended $($f.recommended)). $($f.note)") }
$md.Add(''); $md.Add("## Version findings ($($versionFindings.Count))"); $md.Add('')
$md.Add('| type | artifact | current | target | why |'); $md.Add('|---|---|---|---|---|')
foreach ($v in $versionFindings) { $md.Add("| $($v.type) | $($v.groupId):$($v.artifactId) | $($v.current) | $($v.target) | $($v.why) |") }
$md.Add(''); $md.Add("## Blockers ($($blockers.Count))"); $md.Add('')
foreach ($b in $blockers) { $md.Add("- $($b.key) $(@($b.versions) -join ','): $($b.why) -> $($b.advice)") }
$md.Add(''); $md.Add('## Removed JDK APIs used in source'); $md.Add('')
foreach ($grp in ($removedHits | Group-Object { $_.id })) { $md.Add("- $($grp.Name): $($grp.Count) file(s), e.g. $(@($grp.Group | Select-Object -First 3 | ForEach-Object { $_.file }) -join ', ')") }
$md.Add(''); $md.Add('## Behaviour-risk hotspots (review even if everything compiles)'); $md.Add('')
foreach ($grp in ($riskHits | Group-Object { $_.id } | Sort-Object Count -Descending)) {
    $sev = $grp.Group[0].severity
    $md.Add("- [$sev] $($grp.Name): $($grp.Count) hit(s) in $(@($grp.Group | ForEach-Object { $_.file } | Select-Object -Unique).Count) file(s)")
}
$md.Add(''); $md.Add("## JVM flags / CI pins found ($($configHits.Count))"); $md.Add('')
foreach ($c in $configHits) { $md.Add("- $($c.file):$($c.line) ``$($c.match)`` - $($c.why). $($c.advice)") }
$md.Add(''); $md.Add("## Internal shared libraries ($($internalLibs.Count))"); $md.Add('')
foreach ($l in $internalLibs) { $md.Add("- $($l.key):$($l.version) [$($l.compiledFor)] -> **$($l.status)** $(if ($l.removedApis) { 'needs: ' + (@($l.removedApis) -join ',') })") }
$md.Add(''); $md.Add("## Third-party jars with JDK $($ctx.TargetJdk) issues ($($thirdParty.Count), transitive included)"); $md.Add('')
foreach ($t in $thirdParty) { $md.Add("- $($t.key):$($t.version) [$($t.compiledFor)] $(@($t.issues) -join ', ')$(if ($t.removedApis) { ' needs: ' + (@($t.removedApis) -join ',') })$(if ($t.broughtBy) { ' - via ' + $t.broughtBy[0] })") }
$md.Add(''); $md.Add("## Version divergence across modules ($($divergent.Count))"); $md.Add('')
foreach ($d in $divergent | Select-Object -First 30) { $md.Add("- $($d.key): $(@($d.versions) -join ', ')") }
$enc = $inv.encoding
$md.Add(''); $md.Add("## Source encoding"); $md.Add('')
$md.Add("- declared: $(if (@($enc.declared).Count) { @($enc.declared | ForEach-Object { "$($_.pom) $($_.where)=$($_.value)" }) -join '; ' } else { '**none** (javac on JDK 18+ assumes UTF-8)' })")
$md.Add("- java files with non-ASCII characters: $($enc.nonAsciiFiles); not valid UTF-8: $(@($enc.invalidUtf8Files).Count) $(@($enc.invalidUtf8Files | Select-Object -First 5) -join ', ')")
$md.Add("- repository role: **$($inv.role)**")
$md.Add(''); $md.Add("## App classes: $($appInternals.Count) JDK-internal uses, $($appRemovals.Count) for-removal uses (see baseline-*.txt)")
$md | Set-Content -LiteralPath (Get-WorkFile $ctx 'compat-summary.md') -Encoding utf8NoBOM

Write-Info "version findings: $($versionFindings.Count) | blockers: $($blockers.Count) | removed-API files: $($removedHits.Count) | risk hits: $($riskHits.Count) | config hits: $($configHits.Count) | internal libs: $($internalLibs.Count)"
foreach ($f in $frameworks) { Write-Info "framework: $($f.name) $($f.current) -> $($f.status)" }
Set-PhaseDone $ctx '03-compat'
