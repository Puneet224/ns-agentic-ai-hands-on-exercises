#requires -Version 7.0
# 08 - Compile on JDK 21; fix errors in small steps.
#   Round loop:  mvn test-compile  ->  parse errors per file
#     * missing removed-JDK packages  -> add dependency deterministically (no AI)
#     * everything else               -> one Copilot call PER FILE, write access to that file only
#   Stops on success, on no progress, or after maxCompileFixRounds.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step '08 Compile on JDK 21 and fix (file by file)'

$apiRules = @($ctx.Rules.removedJdkApis)
$attempts = @{}
$needsHuman = [System.Collections.Generic.List[string]]::new()
$fixedFiles = [System.Collections.Generic.List[string]]::new()
$reviewNotes = [System.Collections.Generic.List[string]]::new()
$prevSig = $null
$round = 0
$success = $false

try {
while ($true) {
    $round++
    $logName = "compile-r$round.log"
    $code = Invoke-Maven $ctx '21' @('clean', 'test-compile', '-fae', '-Dmaven.compiler.showDeprecation=true', '-Dmaven.compiler.showWarnings=true') $logName
    if ($code -eq 0) {
        $success = $true; Write-Good "compiles on JDK $($ctx.TargetJdk) (round $round)"
        $dep = @(Get-DeprecationWarnings (Join-Path $ctx.Logs $logName) $ctx)
        Save-JsonFile @{ list = $dep; summary = (Get-DeprecationSummary $dep) } (Get-WorkFile $ctx 'deprecations-after.json')
        Write-Info "deprecation warnings on JDK $($ctx.TargetJdk): $($dep.Count) ($(@($dep | Where-Object { $_.forRemoval }).Count) marked for removal)"
        break
    }

    $errs = Get-CompileErrors (Join-Path $ctx.Logs $logName) $ctx
    if ($errs.Count -eq 0) {
        $tail = (Get-Content (Join-Path $ctx.Logs $logName) | Where-Object { $_ -match '^\[ERROR\]' } | Select-Object -First 15) -join "`n"
        throw "Build failed without Java compiler errors (dependency resolution / plugin problem?):`n$tail"
    }
    $total = 0; foreach ($k in $errs.Keys) { $total += $errs[$k].Count }
    Write-Info "round ${round}: $total error(s) in $($errs.Count) file(s)"

    $sig = (@($errs.Keys | Sort-Object | ForEach-Object { "${_}=" + ($errs[$_] -join ';') })) -join '|'
    if ($sig -eq $prevSig) { throw "No progress in round $round - the same errors remain. See $($cfg.workDir)/compile-fix.json and logs." }
    $prevSig = $sig
    if ($round -gt $cfg.maxCompileFixRounds) { throw "Still $total compile error(s) after $($cfg.maxCompileFixRounds) rounds." }

    # --- deterministic: missing packages that were removed from the JDK -> add dependency
    $models = @(Get-PomModels $ctx)
    $added = 0
    foreach ($rel in $errs.Keys) {
        foreach ($e in $errs[$rel]) {
            $pm = [regex]::Match($e, 'package ([\w.]+) does not exist|location: package ([\w.]+)')
            if (-not $pm.Success) { continue }
            $pkg = if ($pm.Groups[1].Success) { $pm.Groups[1].Value } else { $pm.Groups[2].Value }
            $rule = $apiRules | Where-Object { @($_.packages) -contains $pkg -and @($_.addDeps).Count } | Select-Object -First 1
            if (-not $rule) { continue }
            $full = Join-Path $ctx.Repo $rel
            $mod = Get-ModuleForFile $models $full
            if (-not $mod) { continue }
            $scope = if ($rel -match '(^|/)src/test/') { 'test' } else { $null }
            foreach ($d in $rule.addDeps) {
                if (Add-PomDependency $mod.Pom $d.groupId $d.artifactId $d.version $scope) {
                    Save-Pom $mod.Pom; $added++
                    Write-Info "added $($d.groupId):$($d.artifactId):$($d.version) to $($mod.Rel) ($($rule.id))"
                }
            }
        }
    }
    if ($added) { continue }   # recompile before spending AI calls

    # --- Copilot Chat mode: one batch task per build round (each rerun costs a build)
    if (Test-ChatMode $ctx) {
        $nm = "fix-batch-$(Get-ShortHash $sig)"
        if (Test-Path -LiteralPath (Join-Path $ctx.Work "agent-io/$nm.final.json")) { throw "No progress: the same compile errors remain after AI task $nm. See $($cfg.workDir)/chat-needs-human.json." }
        $done = @(Get-ChildItem -LiteralPath (Join-Path $ctx.Work 'agent-io') -Filter 'fix-batch-*.final.json' -ErrorAction SilentlyContinue).Count
        if ($done -ge $cfg.maxCompileFixRounds) { throw "Still failing after $done AI fix batches - needs a human." }
        $batch = @($errs.Keys | Select-Object -First $cfg.maxFilesPerRound)
        $sections = (@(foreach ($rel in $batch) { "### $rel`n" + ((@($errs[$rel] | Select-Object -First 30) | ForEach-Object { "- $_" }) -join "`n") })) -join "`n`n"
        $task = @"
Make each Java file below compile on JDK $($ctx.TargetJdk) (maven.compiler.release=$($ctx.TargetJdk)). Dependencies were already upgraded by the pipeline.

$sections

Rules:
1. Smallest edit that fixes the listed errors. No refactoring, renaming, reformatting or clean-up.
2. Behaviour must stay identical: same results, data formats and bytes, exceptions, logging, public signatures.
3. Replace removed or internal JDK APIs with supported ones. Where the replacement can differ in an edge case (for example sun.misc.BASE64Encoder wraps lines, java.util.Base64.getEncoder() does not), keep the old behaviour and add a comment line starting with JDK21-REVIEW: above the change.
4. If an error needs another file, a dependency, or cannot be fixed without risking behaviour, leave it and add an entry to needsHuman in the output.
5. selfReview.behaviourChanged must be true if anything observable could differ.
"@
        $null = Invoke-Copilot $ctx 'jdk21-fixer' $task $batch $nm @{ purpose = "Make these files compile on JDK $($ctx.TargetJdk) with identical behaviour: $($batch -join ', ')" }
        continue
    }

    # --- AI (CLI mode): one small task per file
    $todo = @($errs.Keys | Where-Object { ($attempts[$_] ?? 0) -lt $cfg.maxAttemptsPerFile } | Select-Object -First $cfg.maxFilesPerRound)
    if (-not $todo.Count) { throw "All failing files exhausted their AI attempts. Needs a human:`n$($errs.Keys -join "`n")" }
    foreach ($rel in $todo) {
        $attempts[$rel] = ($attempts[$rel] ?? 0) + 1
        $errorList = (@($errs[$rel] | Select-Object -First 40) | ForEach-Object { "- $_" }) -join "`n"
        $task = @"
# Task: make one Java file compile on JDK 21

File to fix (the ONLY file you may edit): $rel
The build now uses maven.compiler.release=$($ctx.TargetJdk) (target JDK $($ctx.TargetJdk)). Dependencies were already upgraded by the pipeline.

## Compiler errors in this file
$errorList

## Rules
1. Make the smallest edit that fixes these errors. No refactoring, renaming, reformatting or clean-up.
2. Behaviour must stay identical: same results, same data formats and bytes, same exceptions, same logging, same public signatures.
3. Replace removed or internal JDK APIs with supported standard APIs. Where the replacement can differ in an edge case (for example sun.misc.BASE64Encoder wraps lines, java.util.Base64.getEncoder() does not), keep the old behaviour and put a comment line starting with JDK21-REVIEW: directly above the change, saying what to verify.
4. Do not edit any other file (no pom.xml, no tests), do not add dependencies, do not run commands.
5. If an error can only be fixed in another file, needs a dependency, or cannot be fixed without risking behaviour, leave it and print a separate line that starts with the marker NEEDS-HUMAN followed by a colon, the file and the reason.
6. Finish by printing one line that starts with DONE followed by a colon and a one-sentence summary.
"@
        $res = Invoke-Copilot $ctx 'jdk21-fixer' $task @($rel) "fix-r$round-$(Get-SafeName $rel)"
        foreach ($n in $res.NeedsHuman) { if (-not $needsHuman.Contains($n)) { $needsHuman.Add($n) } }
        # maker-checker: second agent reviews the diff; rejected or high-risk edits are reverted
        $rev = Invoke-DiffReview $ctx @($rel) @{ purpose = "Make $rel compile on JDK $($ctx.TargetJdk) with identical behaviour"; compilerErrors = @($errs[$rel]) } "review-r$round-$(Get-SafeName $rel)"
        if ($rev.Verdict -eq 'reject' -or $rev.Risk -eq 'high') {
            Invoke-Git $ctx @('checkout', '--', $rel) | Out-Null
            $needsHuman.Add("${rel}: fix rejected by reviewer (risk $($rev.Risk)): $(@($rev.Reasons) -join '; ')")
            $attempts[$rel] = $cfg.maxAttemptsPerFile
            Write-Warn2 "reviewer rejected the change to $rel - reverted"
        }
        else { foreach ($t in @($rev.Tests | Where-Object { $_ })) { $reviewNotes.Add("${rel}: test to add - $t") } }
        if (-not $fixedFiles.Contains($rel)) { $fixedFiles.Add($rel) }
    }
}
}
finally {
    Save-JsonFile @{ success = $success; rounds = $round; filesTouchedByAI = @($fixedFiles); needsHuman = @($needsHuman); reviewerSuggestedTests = @($reviewNotes) } (Get-WorkFile $ctx 'compile-fix.json')
}
if ($needsHuman.Count) { Write-Warn2 "NEEDS-HUMAN notes: $($needsHuman.Count) (see compile-fix.json)" }
Save-Commit $ctx 'jdk21: source changes for JDK 21 compilation'
Set-PhaseDone $ctx '08-compile-fix'
