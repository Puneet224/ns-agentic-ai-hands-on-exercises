#requires -Version 7.0
# 10 - Security gate on the upgraded code, BEFORE report/push: Snyk + Checkmarx again, compared
#      with the baseline taken before any change. New findings at/above the threshold fail the gate.
#      Credentials only from environment variables. No AI (triage runs if the gate fails).
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step '10 Security gate (Snyk + Checkmarx after the upgrade)'
if (-not $cfg.securityGate.enabled) { Write-Info 'securityGate.enabled=false - skipped'; Set-PhaseDone $ctx '10-security-gate' 'skipped'; return }

& (Join-Path $PSScriptRoot '04-snyk.ps1') -RepoPath $ctx.Repo -OutName 'snyk-after.json' -Jdk 'target'
$cxAfter = Invoke-CheckmarxScan $ctx 'checkmarx-after.json'
$snykBefore = Read-JsonFile (Get-WorkFile $ctx 'snyk.json')
$snykAfter = Read-JsonFile (Get-WorkFile $ctx 'snyk-after.json')
$cxBefore = Read-JsonFile (Get-WorkFile $ctx 'checkmarx.json')

$rank = @{ info = 0; low = 1; medium = 2; high = 3; critical = 4 }
$min = $rank["$($cfg.securityGate.failOnNewSeverity)"]; if (-not $min) { $min = 3 }
function Get-Keys($Scan, [scriptblock]$Key) { if (-not $Scan -or $Scan.skipped) { return @() }; @($Scan.findings | ForEach-Object { & $Key $_ }) }

$snykKey = { param($f) "$($f.id)|$($f.package)" }
$cxKey = { param($f) "$($f.ruleId)|$($f.file)|$($f.package)" }
$beforeSnyk = Get-Keys $snykBefore $snykKey
$beforeCx = Get-Keys $cxBefore $cxKey
$newSnyk = @(); $newCx = @(); $evaluated = @()
if ($snykAfter -and -not $snykAfter.skipped) {
    $evaluated += 'snyk'
    $newSnyk = @($snykAfter.findings | Where-Object { ($rank["$($_.severity)"] ?? 0) -ge $min -and $beforeSnyk -notcontains (& $snykKey $_) })
}
if ($cxAfter -and -not $cxAfter.skipped -and (-not $cxBefore -or $cxBefore.skipped)) { Write-Warn2 'No Checkmarx baseline from before the change - Checkmarx results recorded but not gated.' }
elseif ($cxAfter -and -not $cxAfter.skipped) {
    $evaluated += 'checkmarx'
    $newCx = @($cxAfter.findings | Where-Object { ($rank["$($_.severity)"] ?? 0) -ge $min -and $beforeCx -notcontains (& $cxKey $_) })
}
$afterSnykKeys = Get-Keys $snykAfter $snykKey
$fixed = @($beforeSnyk | Where-Object { $afterSnykKeys -notcontains $_ }).Count
$status = if (-not $evaluated.Count) { 'unverified' } elseif ($newSnyk.Count -or $newCx.Count) { 'failed' } else { 'passed' }

Save-JsonFile @{
    status = $status; evaluated = $evaluated; threshold = $cfg.securityGate.failOnNewSeverity
    newSnyk = $newSnyk; newCheckmarx = $newCx; snykFixedByUpgrade = $fixed
    snykBefore = @($snykBefore.findings).Count; snykAfter = @($snykAfter.findings).Count
} (Get-WorkFile $ctx 'security-gate.json')
Write-Info "gate: $status | evaluated: $($evaluated -join ', ') | new >= $($cfg.securityGate.failOnNewSeverity): snyk $($newSnyk.Count), checkmarx $($newCx.Count) | snyk findings fixed by the upgrade: $fixed"
if ($status -eq 'failed' -and $cfg.securityGate.mode -eq 'fail') {
    throw "Security gate FAILED: $($newSnyk.Count + $newCx.Count) new finding(s) at or above '$($cfg.securityGate.failOnNewSeverity)'. See security-gate.json."
}
if ($status -eq 'unverified') { Write-Warn2 'No scanner could run (tokens/CLI missing) - gate is UNVERIFIED; push will be refused.' }
Set-PhaseDone $ctx '10-security-gate'
