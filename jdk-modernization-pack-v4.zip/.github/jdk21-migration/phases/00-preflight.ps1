#requires -Version 7.0
# 00 - Tools, JDKs, Maven, git branch. No AI.
param([Parameter(Mandatory)][string]$RepoPath, [switch]$AllowDirty)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step "00 Preflight - $($ctx.Repo)"

$problems = [System.Collections.Generic.List[string]]::new()
if (-not (Test-Path (Join-Path $ctx.Repo 'pom.xml'))) { $problems.Add('No pom.xml at repository root.') }
foreach ($t in @('git') + $(if ("$($cfg.aiMode)" -eq 'cli') { @($cfg.copilotCmd) } else { @() })) {
    if (-not (Get-Command $t -ErrorAction SilentlyContinue)) { $problems.Add("'$t' not found on PATH.") }
}
if ($problems.Count) { throw ("Preflight failed:`n - " + ($problems -join "`n - ")) }

$jdk = Resolve-JdkHomes $ctx          # detects project level, finds/asks for JDK homes
Write-Info "project Java level: $($jdk.sourceFeature)  ->  target: $($jdk.targetFeature)"
Assert-RepoPolicy $ctx (Get-MavenRepoPolicy $ctx @(Get-PomModels $ctx))
foreach ($tool in 'jdeps', 'jdeprscan') {
    if (-not (Test-Path (Get-JdkTool $ctx $tool '21'))) { throw "$tool not found in the target JDK - a full JDK is required (not a JRE)." }
}
if ($cfg.snykEnabled -and -not (Get-Command $cfg.snykCmd -ErrorAction SilentlyContinue)) {
    Write-Warn2 "Snyk CLI '$($cfg.snykCmd)' not found - phase 04 will record 'skipped'. Set snykEnabled=false to silence."
}

# Maven version (with JDK 21)
$code = Invoke-Maven $ctx '21' @('-v') 'preflight-mvn-version.log' -Quiet
$mvnText = Get-Content (Join-Path $ctx.Logs 'preflight-mvn-version.log') -Raw
if ($code -ne 0) { throw "Maven is not runnable with JDK 21. See $($cfg.workDir)/logs/preflight-mvn-version.log" }
$mv = [regex]::Match($mvnText, 'Apache Maven (\d+\.\d+\.\d+)')
if ($mv.Success) {
    Write-Info "Maven $($mv.Groups[1].Value)"
    if ((Compare-MavenVersion $mv.Groups[1].Value '3.6.3') -lt 0) { throw 'Maven 3.6.3+ is required for JDK 21 (3.9.x recommended).' }
}
if ("$($cfg.aiMode)" -eq 'cli') { $cv = Invoke-Exe $cfg.copilotCmd @('--version'); Write-Info "Copilot CLI: $(($cv.Lines | Select-Object -First 1))" }
else { Write-Info 'AI mode: Copilot Chat (tasks are handed to the chat driver agent)' }

# Git safety net: own branch, base commit recorded, work dir excluded
$inside = Invoke-Exe 'git' @('rev-parse', '--is-inside-work-tree') -WorkingDir $ctx.Repo
if ($inside.ExitCode -ne 0) { throw 'Not a git work tree - git is required for branch, commits and rollback.' }
$excl = (Invoke-Git $ctx @('rev-parse', '--git-path', 'info/exclude')) | Select-Object -First 1
if (-not [IO.Path]::IsPathRooted($excl)) { $excl = Join-Path $ctx.Repo $excl }
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $excl) | Out-Null
$line = "/$($cfg.workDir)/"
if (-not (Test-Path $excl) -or -not (Select-String -LiteralPath $excl -SimpleMatch $line -Quiet)) { Add-Content -LiteralPath $excl -Value $line }

$toolPaths = '\.github/jdk21-migration/|\.github/agents/jdk|\.github/prompts/jdk|\.jdk21-migration\.json'
$dirty = @(Invoke-Git $ctx @('status', '--porcelain') | Where-Object { $_ -and $_ -notmatch $toolPaths -and $_ -notmatch '^\?\? \.github/$' })
if ($dirty.Count -and -not $AllowDirty) {
    throw "Working tree has uncommitted changes (commit/stash them, or use -AllowDirty):`n$($dirty -join "`n")"
}

$branch = (Invoke-Git $ctx @('rev-parse', '--abbrev-ref', 'HEAD')) | Select-Object -First 1
$state = Get-State $ctx
if (-not $state.baseCommit) {
    Set-StateValue $ctx 'baseCommit' ((Invoke-Git $ctx @('rev-parse', 'HEAD')) | Select-Object -First 1)
    Set-StateValue $ctx 'baseBranch' $branch
}
if ($branch -ne $cfg.branchName) {
    $exists = Invoke-Exe 'git' @('rev-parse', '--verify', '--quiet', "refs/heads/$($cfg.branchName)") -WorkingDir $ctx.Repo
    if ($exists.ExitCode -eq 0) { Invoke-Git $ctx @('checkout', $cfg.branchName) | Out-Null }
    else { Invoke-Git $ctx @('checkout', '-b', $cfg.branchName) | Out-Null }
    Write-Info "working on branch $($cfg.branchName) (base: $branch)"
}

Write-Good 'preflight passed'
Set-PhaseDone $ctx '00-preflight'
