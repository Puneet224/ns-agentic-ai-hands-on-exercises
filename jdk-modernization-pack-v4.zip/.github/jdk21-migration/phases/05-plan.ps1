#requires -Version 7.0
# 05 - Merge JDK 21 minimums + framework decision + Snyk fixes into ONE upgrade plan.
#      Target per artifact = highest of (JDK 21 minimum, framework recommendation, Snyk fix).
#      Each change says exactly which pom / property / element will be edited.
#      Pipeline STOPS after this phase until a human sets "approved": true.
#      Optional single Copilot call reviews the plan (writes plan-review.md only).
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step '05 Upgrade plan'

$planFile = Get-WorkFile $ctx 'upgrade-plan.json'
$existing = Read-JsonFile $planFile
if ($existing -and $existing.approved -eq $true) { Write-Warn2 'An APPROVED plan already exists - not regenerating. Delete upgrade-plan.json to rebuild it.'; Set-PhaseDone $ctx '05-plan'; return }

$inv = Read-JsonFile (Get-WorkFile $ctx 'inventory.json')
$compat = Read-JsonFile (Get-WorkFile $ctx 'compat.json')
if (-not $inv -or -not $compat) { throw 'inventory.json / compat.json missing - run phases 02 and 03.' }
$snyk = Read-JsonFile (Get-WorkFile $ctx 'snyk.json')
$models = @(Get-PomModels $ctx)
$tops = @($models | Where-Object { -not $_.InRepoParent } | ForEach-Object { $_.Rel })
$tree = @(Read-JsonFile (Get-WorkFile $ctx 'tree-before.json'))
$role = if ($inv.role) { $inv.role } else { Get-RepoRole $ctx $models }
# libraries shared with other repos keep their consumers' bytecode level while building on the new JDK
$release = $ctx.TargetJdk
if ($role -eq 'library') {
    $release = if ("$($cfg.libraryRelease)" -eq 'source') { "$($inv.sourceJava)" } else { "$($cfg.libraryRelease)" }
    if (-not $release) { $release = '8' }
    Write-Info "library repo: build on JDK $($ctx.TargetJdk), keep bytecode --release $release for consumers"
}

# ---- 1. candidates per artifact
$cand = [ordered]@{}
function Add-Candidate([string]$Kind, [string]$Key, [string]$Version, [string]$Source, [string]$Reason, [bool]$AutoApprove) {
    if (-not $Version) { return }
    if (-not $cand.Contains($Key)) { $cand[$Key] = @{ kind = $Kind; list = [System.Collections.Generic.List[object]]::new() } }
    $cand[$Key].list.Add(@{ version = $Version; source = $Source; reason = $Reason; auto = $AutoApprove })
}
foreach ($f in $compat.versionFindings) {
    Add-Candidate $f.kind "$($f.groupId):$($f.artifactId)" $f.target $f.type $f.why ($f.type -ne 'framework-line-upgrade')
}
if ($snyk -and -not $snyk.skipped) {
    foreach ($f in $snyk.findings) {
        if ($f.kind -eq 'no-fix') { continue }
        $auto = ($f.kind -in 'direct', 'via-direct') -and -not $f.majorChange
        Add-Candidate 'dependency' $f.upgradeKey $f.target "snyk-$($f.kind)" "$($f.severity) $($f.id) in $($f.package)@$($f.version)" $auto
    }
}

# ---- 2. locate every place a version must change
$changes = [System.Collections.Generic.List[object]]::new()
$manual = [System.Collections.Generic.List[object]]::new()
$propIndex = @{}
$n = 0
function New-Id { $script:n++; 'C{0:000}' -f $script:n }

foreach ($key in $cand.Keys) {
    $g, $a = $key.Split(':', 2)
    $kind = $cand[$key].kind
    $list = $cand[$key].list
    $target = Get-MaxVersion @($list | ForEach-Object { $_.version })
    $winners = @($list | Where-Object { (Compare-MavenVersion $_.version $target) -eq 0 })
    $approved = @($winners | Where-Object { $_.auto }).Count -gt 0
    $reason = (@($list | ForEach-Object { "$($_.source): $($_.reason)" } | Select-Object -Unique) -join ' ; ')
    $nodeKinds = if ($kind -eq 'plugin') { @('plugin') } else { @('dependency', 'parent') }
    $occ = @($inv.items | Where-Object { $_.GroupId -eq $g -and $_.ArtifactId -eq $a -and $nodeKinds -contains $_.Kind })
    $handled = $false

    foreach ($o in $occ) {
        if ($o.PropertyName -and -not $o.PropertyPom) {
            # property defined in an external parent/BOM -> override it in our top parent(s)
            $pk = "TOP|$($o.PropertyName)"
            if (-not $propIndex.ContainsKey($pk)) {
                $c = @{ id = (New-Id); approved = $approved; type = 'property'; poms = $tops; property = $o.PropertyName; from = '(external)'; to = $target; artifacts = @($key); reason = $reason; note = 'Property comes from an external parent/BOM; it is overridden in the top-level pom.' }
                $propIndex[$pk] = $c; $changes.Add($c)
            }
            else { $c = $propIndex[$pk]; $c.to = Get-MaxVersion @($c.to, $target); if ($c.artifacts -notcontains $key) { $c.artifacts += $key } }
            $handled = $true; continue
        }
        if (-not $o.Version) { continue }   # version-less here, managed elsewhere
        $handled = $true
        if ((Compare-MavenVersion $o.Version $target) -ge 0) { continue }
        if ($o.PropertyName) {
            $pk = "$($o.PropertyPom)|$($o.PropertyName)"
            if (-not $propIndex.ContainsKey($pk)) {
                $shared = @($inv.items | Where-Object { $_.PropertyName -eq $o.PropertyName -and $_.PropertyPom -eq $o.PropertyPom } | ForEach-Object { "$($_.GroupId):$($_.ArtifactId)" } | Select-Object -Unique)
                $c = @{ id = (New-Id); approved = $approved; type = 'property'; poms = @($o.PropertyPom); property = $o.PropertyName; from = $o.Version; to = $target; artifacts = @($key); sharedBy = $shared; reason = $reason }
                $propIndex[$pk] = $c; $changes.Add($c)
            }
            else {
                $c = $propIndex[$pk]
                $c.to = Get-MaxVersion @($c.to, $target)
                if ($c.artifacts -notcontains $key) { $c.artifacts += $key }
                if (-not $approved) { $c.approved = $false }
            }
        }
        elseif ($o.RawVersion -and $o.RawVersion -notmatch '\$\{') {
            $changes.Add(@{ id = (New-Id); approved = $approved; type = 'inline'; pom = $o.Pom; kind = $o.Kind; context = $o.Context; groupId = $g; artifactId = $a; raw = $o.RawVersion; from = $o.Version; to = $target; reason = $reason })
        }
        else { $manual.Add(@{ item = "${key} in $($o.Pom)"; reason = "Version expression '$($o.RawVersion)' is too complex to edit automatically -> set $target by hand. ($reason)" }) }
    }

    if (-not $handled) {
        $managedExternally = @($occ).Count -gt 0
        $autoOk = $approved -and ($kind -eq 'plugin' -or @($winners | Where-Object { $_.source -eq 'jdk21-min' }).Count -gt 0)
        $who = @(Get-WhoBrings $tree $key)
        $note = if ($who.Count) { "Transitive via: $($who -join ' | '). " } else { '' }
        $why = if ($managedExternally) { 'Declared without version (managed by external parent/BOM). Pinned in top-level management section; prefer upgrading that parent/BOM if possible.' }
        elseif ($kind -eq 'plugin') { 'Plugin version comes from the Maven super-POM or an external parent; pinned in top-level pluginManagement.' }
        else { 'Transitive dependency; pinned in top-level dependencyManagement.' }
        $note += $why
        $changes.Add(@{ id = (New-Id); approved = $autoOk; type = 'add-managed'; poms = $tops; kind = $kind; groupId = $g; artifactId = $a; to = $target; reason = $reason; note = $note })
    }
}

# ---- 3. compiler level, removed-API dependencies
$changes.Add(@{ id = (New-Id); approved = $true; type = 'compiler-release'; poms = $tops; to = $release; role = $role; reason = 'Set maven.compiler.release (target JDK for applications, consumer level for libraries), update java version properties, compiler <source>/<target>, enforcer requireJavaVersion.' })

$apiRules = @{}; foreach ($r in $ctx.Rules.removedJdkApis) { $apiRules[$r.id] = $r }
foreach ($grp in ($compat.removedApiHits | Group-Object { "$($_.module)|$($_.id)" })) {
    $first = $grp.Group[0]
    $rule = $apiRules[$first.id]
    if (-not $rule -or -not @($rule.addDeps).Count) {
        $manual.Add(@{ item = "$($first.id) in $($first.module)"; reason = "$($rule.why). Files: $(@($grp.Group | Select-Object -First 5 | ForEach-Object { $_.file }) -join ', ')" })
        continue
    }
    $scope = if (@($grp.Group | Where-Object { -not $_.test }).Count -eq 0) { 'test' } else { $null }
    foreach ($d in $rule.addDeps) {
        $declared = @($inv.items | Where-Object { $_.Pom -eq $first.module -and $_.GroupId -eq $d.groupId -and $_.ArtifactId -eq $d.artifactId -and $_.Context -eq 'dependencies' }).Count
        if ($declared) { continue }
        $changes.Add(@{ id = (New-Id); approved = $true; type = 'add-dependency'; pom = $first.module; groupId = $d.groupId; artifactId = $d.artifactId; to = $d.version; scope = $scope; reason = "$($rule.why) (used in $($grp.Count) file(s))" })
    }
}
# source encoding: JDK 18+ javac defaults to UTF-8
$enc = $inv.encoding
if ($enc -and -not @($enc.declared).Count -and $enc.nonAsciiFiles -gt 0) {
    $bad = @($enc.invalidUtf8Files).Count
    $val = if ($bad) { "$($cfg.legacySourceEncoding)" } else { 'UTF-8' }
    $changes.Add(@{ id = (New-Id); approved = (-not $bad); type = 'source-encoding'; poms = $tops; to = $val
            reason = $(if ($bad) { "No source encoding declared and $bad java file(s) are not valid UTF-8 (written in a legacy code page). Confirm the old build OS encoding before approving, or convert the files to UTF-8." } else { 'No source encoding declared; all non-ASCII sources are valid UTF-8 - pin it explicitly.' }) })
}
elseif ($enc -and @($enc.invalidUtf8Files).Count) { $manual.Add(@{ item = 'source encoding'; reason = "Encoding is declared but $(@($enc.invalidUtf8Files).Count) java file(s) are not valid UTF-8: $(@($enc.invalidUtf8Files | Select-Object -First 5) -join ', ')" }) }

# internal libraries that call removed JDK APIs need those jars at runtime -> add to war modules
$warPoms = @($models | Where-Object { $_.Packaging -eq 'war' } | ForEach-Object { $_.Rel })
foreach ($lib in @($compat.internalLibs | Where-Object { $_.status -eq 'needs-runtime-deps' })) {
    foreach ($apiId in @($lib.removedApis)) {
        foreach ($d in @($apiRules[$apiId].addDeps)) {
            foreach ($wp in $warPoms) {
                if (@($changes | Where-Object { $_.type -eq 'add-dependency' -and $_.pom -eq $wp -and $_.artifactId -eq $d.artifactId }).Count) { continue }
                $changes.Add(@{ id = (New-Id); approved = $true; type = 'add-dependency'; pom = $wp; groupId = $d.groupId; artifactId = $d.artifactId; to = $d.version; scope = 'runtime'; reason = "Internal library $($lib.key):$($lib.version) uses $apiId (removed from JDK); needed at runtime." })
            }
        }
    }
}

# third-party jars (transitive too) that call removed JDK APIs -> same runtime deps for war modules
foreach ($lib in @($compat.thirdPartyJars | Where-Object { @($_.issues) -contains 'needs-runtime-deps' })) {
    foreach ($apiId in @($lib.removedApis)) {
        foreach ($d in @($apiRules[$apiId].addDeps)) {
            foreach ($wp in $warPoms) {
                if (@($changes | Where-Object { $_.type -eq 'add-dependency' -and $_.pom -eq $wp -and $_.artifactId -eq $d.artifactId }).Count) { continue }
                $changes.Add(@{ id = (New-Id); approved = $true; type = 'add-dependency'; pom = $wp; groupId = $d.groupId; artifactId = $d.artifactId; to = $d.version; scope = 'runtime'; reason = "Third-party $($lib.key):$($lib.version) (via $(@($lib.broughtBy)[0])) uses $apiId, removed from the JDK." })
            }
        }
    }
}
foreach ($t in @($compat.thirdPartyJars | Where-Object { @($_.issues) -contains 'class-version-too-high' })) { $manual.Add(@{ item = "$($t.key):$($t.version)"; reason = "Compiled for $($t.compiledFor) - newer than the target JDK $($ctx.TargetJdk)." }) }
foreach ($t in @($compat.thirdPartyJars | Where-Object { @($_.issues) -contains 'uses-jdk-internals' })) { $manual.Add(@{ item = "$($t.key):$($t.version)"; reason = "Uses JDK internal APIs (may need --add-opens/--add-exports or an upgrade): $(@($t.jdkInternals | Select-Object -First 2) -join ' | ')" }) }
foreach ($d in @($compat.divergentVersions | Select-Object -First 20)) { $manual.Add(@{ item = "$($d.key) (divergent)"; reason = "Different modules resolve different versions: $(@($d.versions) -join ', ') - consider pinning one version in dependencyManagement." }) }

# libraries: a dependency upgrade must not raise the bytecode level consumers need
if ($role -eq 'library') {
    foreach ($c in @($changes | Where-Object { $_.type -in 'inline', 'property', 'add-managed' -and $_.approved })) {
        $arts = if ($c.artifacts) { @($c.artifacts) } else { @("$($c.groupId):$($c.artifactId)") }
        foreach ($art in $arts) {
            $ga = $art.Split(':', 2)
            if (@($inv.items | Where-Object { $_.GroupId -eq $ga[0] -and $_.ArtifactId -eq $ga[1] -and ($_.Scope -eq 'test' -or $_.Kind -eq 'plugin') }).Count) { continue }
            if ((Test-ArtifactAvailable $ctx $ga[0] $ga[1] $c.to) -ne 'jar') { continue }
            $info = Get-JarJavaInfo (Get-LocalJar $ctx $ga[0] $ga[1] $c.to)
            if ($info.javaFeature -and $info.javaFeature -gt [int]$release) {
                $c.approved = $false
                $c.note = "$($c.note) LIBRARY: $art $($c.to) needs Java $($info.javaFeature) but consumers run Java $release - not auto-approved.".Trim()
            }
        }
    }
}

# ---- 4. manual items
foreach ($b in $compat.blockers) { $manual.Add(@{ item = $b.key; reason = "$($b.why) -> $($b.advice)" }) }
foreach ($l in @($compat.internalLibs | Where-Object { $_.status -in 'owner-action', 'jar-not-found' })) {
    $manual.Add(@{ item = "$($l.key):$($l.version) (internal)"; reason = $(if ($l.status -eq 'owner-action') { "Uses JDK internals / APIs removed in 21 - owning team must release a fixed version: $(@($l.jdkInternals + $l.forRemoval | Select-Object -First 3) -join ' | ')" } else { "Jar not in local repo ($($l.jar)) - could not be analysed." }) })
}
if ($snyk -and -not $snyk.skipped) {
    foreach ($f in @($snyk.findings | Where-Object { $_.kind -eq 'no-fix' })) { $manual.Add(@{ item = "$($f.package)@$($f.version)"; reason = "Snyk $($f.severity) $($f.id): no fixed version published." }) }
}

$plan = @{
    approved = $false; generatedAt = (Get-Date).ToString('s'); topParents = $tops
    frameworkDecisions = @($compat.frameworks); changes = @($changes); manual = @($manual)
    howToApprove = 'Review upgrade-plan.md. Flip "approved" per change if needed, then set top-level "approved": true and rerun the pipeline.'
}
Save-JsonFile $plan $planFile

# ---- 5. markdown view
$md = [System.Collections.Generic.List[string]]::new()
$md.Add('# JDK 8 -> 21 upgrade plan'); $md.Add('')
$md.Add('Edit `upgrade-plan.json`: set `"approved": false` on any change you do not want, then set the top-level `"approved": true` and rerun.'); $md.Add('')
$md.Add('## Framework decision'); $md.Add('')
if (-not @($compat.frameworks).Count) { $md.Add('No tracked framework detected - no framework upgrade is needed for JDK 21.') }
foreach ($f in $compat.frameworks) {
    $verdict = switch ($f.status) { 'ok' { 'no upgrade needed' } 'patch-upgrade' { 'patch upgrade within the same line (low risk)' } default { 'LINE UPGRADE REQUIRED (not auto-approved - needs regression testing)' } }
    $md.Add("- **$($f.name)** $($f.current) -> $verdict (target $($f.recommended)). $($f.note)")
}
$md.Add(''); $md.Add('## Changes'); $md.Add('')
$md.Add('| id | ok | type | where | what | from -> to | why |'); $md.Add('|---|---|---|---|---|---|---|')
foreach ($c in $changes) {
    $where = if ($c.poms) { @($c.poms) -join ', ' } else { $c.pom }
    $what = switch ($c.type) {
        'property' { "property ``$($c.property)`` ($(@($c.artifacts) -join ', '))$(if (@($c.sharedBy).Count -gt @($c.artifacts).Count) { ' - shared by: ' + (@($c.sharedBy) -join ', ') })" }
        'compiler-release' { 'compiler level' }
        default { "$($c.kind) $($c.groupId):$($c.artifactId)$(if ($c.scope) { " ($($c.scope))" })" }
    }
    $md.Add("| $($c.id) | $(if ($c.approved) { 'yes' } else { '**NO**' }) | $($c.type) | $where | $what | $($c.from) -> $($c.to) | $($c.reason)$(if ($c.note) { ' _' + $c.note + '_' }) |")
}
$md.Add(''); $md.Add("## Manual / needs a human ($($manual.Count))"); $md.Add('')
foreach ($m in $manual) { $md.Add("- **$($m.item)**: $($m.reason)") }
$md | Set-Content -LiteralPath (Get-WorkFile $ctx 'upgrade-plan.md') -Encoding utf8NoBOM

Write-Info "$($changes.Count) changes ($(@($changes | Where-Object { $_.approved }).Count) pre-approved), $($manual.Count) manual items"

# ---- 6. optional AI review (one call, writes only plan-review.md)
if ($cfg.aiPlanReview) {
    $reviewRel = "$($cfg.workDir)/plan-review.md"
    $task = @"
# Task: review a JDK 8 -> 21 upgrade plan

Read these files:
- $($cfg.workDir)/upgrade-plan.md
- $($cfg.workDir)/compat-summary.md
- the root pom.xml (only if needed)

Write your review to $reviewRel and to no other file. Maximum 40 lines. Cover only:
1. Version combinations in the plan that are incompatible with each other (for example Spring Framework vs Spring Security vs Hibernate vs Spring Boot lines, or a plugin needing a newer Maven).
2. Changes likely to alter runtime behaviour, data formats or business flow, and what to test for each.
3. Anything required for JDK 21 that the plan misses.
4. Whether you agree with the framework decision, in one sentence.
Do not repeat the plan. Do not edit pom files or source code.
"@
    $res = Invoke-Copilot $ctx 'jdk21-plan-reviewer' $task @($reviewRel) 'plan-review'
    if (Test-Path -LiteralPath (Join-Path $ctx.Repo $reviewRel)) { Write-Good "AI review: $reviewRel" } else { Write-Warn2 'AI review produced no file (see logs/plan-review.log).' }
}

Set-PhaseDone $ctx '05-plan'
Write-Host "`n    >>> Review $($cfg.workDir)/upgrade-plan.md (and plan-review.md), set `"approved`": true in upgrade-plan.json, then rerun." -ForegroundColor Magenta
