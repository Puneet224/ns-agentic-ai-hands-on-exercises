#requires -Version 7.0
<#
.SYNOPSIS
  JDK migration pipeline (source -> targetJdk, default 21) for multi-module Maven repos.
  Runs phases/NN-*.ps1 in order, resumes where it stopped, pauses for plan approval.

.EXAMPLE
  pwsh .github/jdk21-migration/run-pipeline.ps1                       # this repo
  pwsh C:\tools\jdk21\run-pipeline.ps1 -RepoPath C:\code\other-repo    # central install, any repo
  pwsh .github/jdk21-migration/run-pipeline.ps1 -From 07 -Force        # redo from compile phase
  pwsh .github/jdk21-migration/run-pipeline.ps1 -Only 03,05 -Force     # re-scan and re-plan
#>
[CmdletBinding()]
param(
    [string]$RepoPath,
    [string]$From,
    [string]$To,
    [string[]]$Only,
    [switch]$Force,
    [switch]$AllowDirty,
    [switch]$SkipBaseline,
    [switch]$SkipSnyk,
    [switch]$NonInteractive
)
$ErrorActionPreference = 'Stop'
if (-not $RepoPath) { $RepoPath = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path }
if ($NonInteractive) { $env:JDKMIG_NONINTERACTIVE = '1' }
Import-Module (Join-Path $PSScriptRoot 'lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath

# Copilot Chat mode: finish the AI task handed out by the previous run before doing anything else
if (-not $env:JDKMIG_PARENT_RUNNER) { $env:JDKMIG_RESUME_CMD = "pwsh -NoProfile -File $($MyInvocation.MyCommand.Path) -RepoPath `"$($ctx.Repo)`" -NonInteractive" }
$pendingState = Complete-PendingChatTask $ctx
if ($pendingState -eq 'waiting') { exit 3 }

$phases = Get-ChildItem (Join-Path $PSScriptRoot 'phases') -Filter '*.ps1' | Sort-Object Name
$started = -not $From
$sw = [Diagnostics.Stopwatch]::StartNew()

foreach ($p in $phases) {
    $name = $p.BaseName
    if ($From -and $name.StartsWith($From)) { $started = $true }
    if (-not $started) { continue }
    if ($Only -and -not @($Only | Where-Object { $name.StartsWith($_) }).Count) { continue }
    if ($SkipBaseline -and $name.StartsWith('01')) { Write-Info "skip $name (-SkipBaseline)"; continue }
    if ($SkipSnyk -and $name.StartsWith('04')) { Write-Info "skip $name (-SkipSnyk)"; continue }

    $state = Get-State $ctx
    $status = if ($state.phases.ContainsKey($name)) { $state.phases[$name].status } else { $null }
    if (-not $Force -and $status -in 'done', 'skipped') { Write-Info "skip $name (already $status; use -Force to rerun)"; continue }

    if ($name.StartsWith('06')) {
        $plan = Read-JsonFile (Get-WorkFile $ctx 'upgrade-plan.json')
        if (-not $plan -or $plan.approved -ne $true) {
            Write-Host "`nPAUSED: review $($ctx.Config.workDir)/upgrade-plan.md, set `"approved`": true in upgrade-plan.json, then rerun this script." -ForegroundColor Magenta
            exit 0
        }
    }

    $params = @{ RepoPath = $ctx.Repo }
    if ($name.StartsWith('00') -and $AllowDirty) { $params.AllowDirty = $true }
    try { & $p.FullName @params }
    catch {
        if ($_.Exception.Message -like 'AI-TASK-PENDING:*') { Write-Host "`nWaiting for the AI task above ($name). Do it, then rerun the command." -ForegroundColor Magenta; exit 3 }
        Write-Host "`nSTOPPED in $name : $($_.Exception.Message)" -ForegroundColor Red
        Invoke-ErrorTriage $ctx $name $_.Exception.Message
        Write-Host "Logs: $($ctx.Config.workDir)/logs   |   resume: rerun this script (finished phases are skipped)" -ForegroundColor Red
        exit 1
    }
    if ($To -and $name.StartsWith($To)) { break }
}
Write-Host "`nPipeline finished in $([int]$sw.Elapsed.TotalMinutes) min. Report: $($ctx.Config.workDir)/final-report.md" -ForegroundColor Green

exit 0
