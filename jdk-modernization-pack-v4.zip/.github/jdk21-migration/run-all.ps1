#requires -Version 7.0
<#
.SYNOPSIS
  Assess first; migrate in continuation ONLY if the assessment says it is required.
    1. run-assessment.ps1 (no changes)
    2. decision gate:
         recommendation not in autoMigrateOn      -> stop, no migration needed
         AI reviewer disagrees (pauseOnAiDisagreement) -> PAUSED for a human decision
         otherwise                                 -> continue
    3. run-pipeline.ps1 (still pauses for plan approval; framework LINE upgrades stay unapproved)
  Rerunning resumes wherever it stopped (finished phases and AI tasks are not repeated).
.EXAMPLE
  pwsh .github/jdk21-migration/run-all.ps1 -NonInteractive
  pwsh .github/jdk21-migration/run-all.ps1 -Migrate always      # migrate even if not required
#>
[CmdletBinding()]
param(
    [string]$RepoPath,
    [ValidateSet('auto', 'always', 'never')][string]$Migrate = 'auto',
    [switch]$NonInteractive
)
$ErrorActionPreference = 'Stop'
if (-not $RepoPath) { $RepoPath = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path }
Import-Module (Join-Path $PSScriptRoot 'lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$env:JDKMIG_PARENT_RUNNER = '1'
$env:JDKMIG_RESUME_CMD = "pwsh -NoProfile -File $($MyInvocation.MyCommand.Path) -RepoPath `"$($ctx.Repo)`" -Migrate $Migrate -NonInteractive"
$common = @{ RepoPath = $ctx.Repo }
if ($NonInteractive) { $common.NonInteractive = $true }

# ---- 1. assessment
$global:LASTEXITCODE = 0
& (Join-Path $PSScriptRoot 'run-assessment.ps1') @common
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }          # 3 = AI task pending, 1 = stopped

# ---- 2. decision gate (decided once, remembered in state)
$state = Get-State $ctx
$decision = $state.autoDecision
if (-not $decision) {
    $a = Read-JsonFile (Get-WorkFile $ctx 'assessment.json')
    $ai = Read-JsonFile (Get-WorkFile $ctx 'assessment-ai-review.json')
    if (-not $a) { throw 'assessment.json missing.' }
    Write-Step "Decision gate: assessment says '$($a.recommendation)'"
    $required = @($ctx.Config.autoMigrateOn) -contains $a.recommendation
    if ($Migrate -eq 'never' -or ($Migrate -eq 'auto' -and -not $required)) {
        Write-Host "`nNo migration started: recommendation is '$($a.recommendation)' ($(@($a.reasons) -join '; '))." -ForegroundColor Green
        Write-Host "Assessment finished -> $($ctx.Config.workDir)/assessment-report.md   (use -Migrate always to migrate anyway)" -ForegroundColor Green
        exit 0
    }
    if ($Migrate -eq 'auto' -and $ctx.Config.pauseOnAiDisagreement -and $ai -and $ai.recommendation -ne $a.recommendation) {
        Write-Host "`nPAUSED: the AI reviewer recommends '$($ai.recommendation)' but the automated decision is '$($a.recommendation)'." -ForegroundColor Magenta
        Write-Host "Read $($ctx.Config.workDir)/assessment-report.md, then rerun with -Migrate always (continue) or -Migrate never (stop)." -ForegroundColor Magenta
        exit 0
    }
    if ($a.recommendation -eq 'jdk-upgrade-plus-framework-modernization') {
        Write-Warn2 'Framework modernization is required. The migration does the JDK part; framework LINE upgrades appear in the plan as NOT approved - decide them there.'
    }
    $decision = @{ migrate = $true; recommendation = $a.recommendation; mode = $Migrate; at = (Get-Date).ToString('s') }
    Set-StateValue $ctx 'autoDecision' $decision
    Write-Good 'continuing with the migration pipeline'
}

# ---- 3. migration
$global:LASTEXITCODE = 0
& (Join-Path $PSScriptRoot 'run-pipeline.ps1') @common
exit $LASTEXITCODE
