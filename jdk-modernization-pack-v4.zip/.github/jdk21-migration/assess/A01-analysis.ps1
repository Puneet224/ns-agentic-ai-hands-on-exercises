#requires -Version 7.0
# A01 - Code & dependency analysis on the CURRENT JDK (no changes):
#       inventory (phase 02), compile + jdeps/jdeprscan, compatibility scan (phase 03). No AI.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$phases = Join-Path $PSScriptRoot '../phases'
Write-Step 'A01 Analysis (inventory, compile, jdeps, compatibility)'

& (Join-Path $phases '02-inventory.ps1') -RepoPath $ctx.Repo

# compile once on the current JDK so jdeps/jdeprscan can inspect real class files
if (-not (Test-Path -LiteralPath (Get-WorkFile $ctx 'baseline-jdeps-internals.txt'))) {
    $code = Invoke-Maven $ctx 'source' @('-DskipTests', 'test-compile', '-Dmaven.compiler.showDeprecation=true', '-Dmaven.compiler.showWarnings=true') 'assess-compile.log' -Quiet
    $dep = @(Get-DeprecationWarnings (Join-Path $ctx.Logs 'assess-compile.log') $ctx)
    Save-JsonFile @{ list = $dep; summary = (Get-DeprecationSummary $dep) } (Get-WorkFile $ctx 'deprecations-before.json')
    Write-Info "deprecation warnings on current JDK: $($dep.Count)"
    if ($code -ne 0) { Write-Warn2 'Project does not compile on its current JDK - class-level analysis skipped (see logs/assess-compile.log).' }
    else {
        $jdeps = Get-JdkTool $ctx 'jdeps' 'target'; $jdeprscan = Get-JdkTool $ctx 'jdeprscan' 'target'
        $internals = [System.Collections.Generic.List[string]]::new(); $removals = [System.Collections.Generic.List[string]]::new()
        $dirs = Get-ChildItem -LiteralPath $ctx.Repo -Recurse -Directory -Filter 'classes' -ErrorAction SilentlyContinue |
            Where-Object { $_.Parent.Name -eq 'target' -and $_.FullName -notmatch '[\\/]node_modules[\\/]' }
        foreach ($d in $dirs) {
            $rel = Get-RelPath $ctx $d.FullName
            foreach ($l in (Invoke-Exe $jdeps @('--multi-release', $ctx.TargetJdk, '--jdk-internals', $d.FullName)).Lines) { if ($l -match 'JDK internal API') { $internals.Add("$rel :: $($l.Trim())") } }
            foreach ($l in (Invoke-Exe $jdeprscan @('--release', $ctx.TargetJdk, '--for-removal', $d.FullName)).Lines) { if ($l -match 'forRemoval=true') { $removals.Add("$rel :: $($l.Trim())") } }
        }
        $internals | Set-Content -LiteralPath (Get-WorkFile $ctx 'baseline-jdeps-internals.txt') -Encoding utf8NoBOM
        $removals | Set-Content -LiteralPath (Get-WorkFile $ctx 'baseline-jdeprscan.txt') -Encoding utf8NoBOM
        Write-Info "jdeps: $($internals.Count) JDK-internal uses | jdeprscan: $($removals.Count) for-removal uses"
    }
}

& (Join-Path $phases '03-compat.ps1') -RepoPath $ctx.Repo
Set-PhaseDone $ctx 'A01-analysis'
