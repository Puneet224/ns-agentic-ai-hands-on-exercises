#requires -Version 7.0
# A04 - AI in the loop: an assessment-reviewer agent checks the deterministic recommendation
#       against the evidence and returns a structured verdict (validated JSON). Read-only.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
Write-Step 'A04 AI review of the assessment'

if (-not $ctx.Config.aiAssessmentReview) { Write-Info 'aiAssessmentReview=false - skipped'; Set-PhaseDone $ctx 'A04-ai-review' 'skipped'; return }
$a = Read-JsonFile (Get-WorkFile $ctx 'assessment.json')
if (-not $a) { throw 'assessment.json missing - run A03.' }

# compact evidence only: keeps the request small
$evidence = @{
    sourceJdk = $a.sourceJdk; targetJdk = $a.targetJdk
    automatedRecommendation = $a.recommendation; automatedReasons = $a.reasons
    classificationCounts = $a.classificationCounts
    fixesNeedingChange = @($a.vulnerabilityFixes | Where-Object { $_.classification -ne 'fixable-now' } | Select-Object -First 40 | ForEach-Object {
            @{ artifact = $_.artifact; current = $_.current; target = $_.target; requiresJava = $_.requiresJava; jakarta = $_.jakarta; framework = $_.framework; classification = $_.classification; maxSeverity = $_.maxSeverity } })
    noFixCount = @($a.noFix).Count; sast = $a.sast; jdkUpgradeEffort = $a.jdkUpgradeEffort; repoPolicy = $a.repoPolicy
    evidenceFiles = @("$($ctx.Config.workDir)/compat-summary.md", "$($ctx.Config.workDir)/assessment.json")
}
$schema = @{
    required = @('recommendation', 'agreesWithAutomatedDecision', 'confidence', 'keyRisks', 'effortDrivers', 'questionsForHuman', 'suggestedSequence')
    enums    = @{
        recommendation = @('patch-on-current-jdk-possible', 'jdk-upgrade-required', 'jdk-upgrade-plus-framework-modernization')
        confidence     = @('high', 'medium', 'low')
    }
    example  = @{
        recommendation = 'jdk-upgrade-plus-framework-modernization'; agreesWithAutomatedDecision = $true; confidence = 'medium'
        keyRisks = @('spring-web fix exists only in 6.x -> jakarta.* + Tomcat 10')
        effortDrivers = @('42 javax.servlet imports', 'PowerMock tests')
        questionsForHuman = @('Can the app server move to a jakarta-capable version?')
        suggestedSequence = @('JDK 21 on Spring 5.3', 'then Spring 6 / jakarta')
    }
}
$r = Invoke-Agent $ctx 'jdk-assessment-reviewer' $evidence $schema @() 'assessment-review' 'Validate the automated recommendation against the evidence. Disagree only with a concrete reason. Read the evidence files if you need detail. Do not edit any other file.'
if ($r.Ok) {
    Save-JsonFile $r.Output (Get-WorkFile $ctx 'assessment-ai-review.json')
    $flag = if ($r.Output.recommendation -ne $a.recommendation) { ' (DIFFERS from automated decision)' } else { '' }
    Write-Info "AI: $($r.Output.recommendation), confidence $($r.Output.confidence)$flag"
    Set-PhaseDone $ctx 'A04-ai-review'
}
else { Write-Warn2 "AI review failed: $($r.Error) - report will show the automated decision only."; Set-PhaseDone $ctx 'A04-ai-review' 'failed' }
