#requires -Version 7.0
# A02 - Security baseline BEFORE any change: Snyk (open source) + Checkmarx (SAST/SCA, SARIF).
#       Credentials come only from environment variables. No AI. No changes.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
Write-Step 'A02 Security baseline (Snyk + Checkmarx)'

& (Join-Path $PSScriptRoot '../phases/04-snyk.ps1') -RepoPath $ctx.Repo -OutName 'snyk.json' -Jdk 'source'
$cx = Invoke-CheckmarxScan $ctx 'checkmarx.json'
Set-PhaseDone $ctx 'A02-security-scans'
