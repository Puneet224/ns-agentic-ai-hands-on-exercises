#requires -Version 7.0
# A05 - Assessment report for this repo + one row in a cross-repo portfolio CSV. No AI.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
Write-Step 'A05 Assessment report'

$a = Read-JsonFile (Get-WorkFile $ctx 'assessment.json')
$ai = Read-JsonFile (Get-WorkFile $ctx 'assessment-ai-review.json')
$envInfo = Read-JsonFile (Get-WorkFile $ctx 'environment.json')
$snyk = Read-JsonFile (Get-WorkFile $ctx 'snyk.json')
$cx = Read-JsonFile (Get-WorkFile $ctx 'checkmarx.json')
$repoName = Split-Path -Leaf $ctx.Repo

$md = [System.Collections.Generic.List[string]]::new()
$md.Add("# Modernization assessment - $repoName"); $md.Add('')
$md.Add("Java $($a.sourceJdk) -> $($a.targetJdk) | generated $((Get-Date).ToString('s')) | company-repo policy: **$($a.repoPolicy)**"); $md.Add('')
$md.Add('## Decision'); $md.Add('')
$md.Add("- Automated: **$($a.recommendation)**")
foreach ($r in $a.reasons) { $md.Add("  - $r") }
if ($ai) {
    $md.Add("- AI reviewer: **$($ai.recommendation)** (confidence $($ai.confidence))$(if ($ai.recommendation -ne $a.recommendation) { ' - **disagrees, needs a human decision**' })")
    $md.Add(''); $md.Add('### Key risks'); foreach ($x in @($ai.keyRisks)) { $md.Add("- $x") }
    $md.Add(''); $md.Add('### Effort drivers'); foreach ($x in @($ai.effortDrivers)) { $md.Add("- $x") }
    $md.Add(''); $md.Add('### Suggested sequence'); $i = 1; foreach ($x in @($ai.suggestedSequence)) { $md.Add("$i. $x"); $i++ }
    $md.Add(''); $md.Add('### Questions for the team'); foreach ($x in @($ai.questionsForHuman)) { $md.Add("- $x") }
}
$md.Add(''); $md.Add('## Vulnerability remediation requirements'); $md.Add('')
$md.Add('| artifact | current | fix | needs Java | jakarta | class | max sev | findings |'); $md.Add('|---|---|---|---|---|---|---|---|')
foreach ($r in @($a.vulnerabilityFixes | Sort-Object { $_.classification })) {
    $md.Add("| $($r.artifact) | $($r.current) | $($r.target) | $($r.requiresJava) | $(if ($r.jakarta) { 'yes' } else { '' }) | $($r.classification) | $($r.maxSeverity) | $(@($r.vulnerabilities).Count) |")
}
$md.Add(''); $md.Add("No fix available: $(@($a.noFix).Count) finding(s)")
foreach ($n in @($a.noFix | Select-Object -First 20)) { $md.Add("- $($n.source) $($n.severity) $($n.id) $($n.package) $($n.note)") }
$md.Add(''); $md.Add("## Checkmarx SAST: $($a.sast.total) finding(s) (JDK-independent code fixes)"); $md.Add('')
foreach ($s in @($a.sast.bySeverity)) { $md.Add("- $($s.severity): $($s.count)") }
foreach ($t in @($a.sast.topRules)) { $md.Add("- top rule: $($t.rule) ($($t.count))") }
$e = $a.jdkUpgradeEffort
$md.Add(''); $md.Add("## JDK $($a.targetJdk) upgrade effort indicators"); $md.Add('')
foreach ($f in @($e.frameworks)) { $md.Add("- $($f.name) $($f.current): $($f.status)") }
$md.Add("- dependency/plugin version changes needed: $($e.versionFindings)")
$md.Add("- files using APIs removed from the JDK: $($e.removedApiFiles)")
$md.Add("- JDK-internal API uses in compiled classes: $($e.appJdkInternalUses)")
$md.Add("- JVM flag / CI / script findings: $($e.configHits)")
foreach ($b in @($e.blockers)) { $md.Add("- BLOCKER $($b.key): $($b.why)") }
foreach ($l in @($e.internalLibsNeedingOwner)) { $md.Add("- internal library needs its owning team: $l") }
foreach ($h in @($e.behaviourRiskHits)) { $md.Add("- behaviour-risk $($h.id): $($h.count) location(s)") }
$md.Add("- repository role: **$($e.repoRole)**$(if ($e.repoRole -eq 'library') { ' - migrate/release before the apps that consume it; keep --release at the consumers'' level' })")
$md.Add("- third-party jars with issues (transitive included): $(@($e.thirdPartyJarIssues).Count)")
foreach ($t in @($e.thirdPartyJarIssues | Select-Object -First 15)) { $md.Add("  - $($t.jar): $(@($t.issues) -join ', ')$(if ($t.via) { ' (via ' + $t.via + ')' })") }
$md.Add("- artifacts with divergent versions across modules: $($e.divergentVersions)")
$md.Add("- source encoding declared: $($e.sourceEncodingDeclared); java files not valid UTF-8: $($e.nonUtf8SourceFiles)")
$md.Add("- deprecated API uses (javac): $($e.deprecatedApiUses) ($($e.deprecatedForRemoval) marked for removal)")
$md.Add("- Java agents in repo config: $(if (@($e.javaAgents).Count) { @($e.javaAgents) -join ', ' } else { 'none found (check server config)' })")
$md.Add(''); $md.Add("Details: compat-summary.md, assessment.json, snyk.json, checkmarx.json in $($ctx.Config.workDir)/")
$md | Set-Content -LiteralPath (Get-WorkFile $ctx 'assessment-report.md') -Encoding utf8NoBOM
Write-Good "$($ctx.Config.workDir)/assessment-report.md"

if ($ctx.Config.portfolioCsv) {
    # dependency graph node for cross-repo ordering (portfolio-order.ps1)
    $inv = Read-JsonFile (Get-WorkFile $ctx 'inventory.json')
    $prefixes = @($ctx.Config.internalGroupIdPrefixes | Where-Object { $_ })
    $node = @{
        repo = $repoName; role = $e.repoRole; sourceJdk = $a.sourceJdk; recommendation = $a.recommendation
        provides = @($inv.modules | ForEach-Object { "$($_.groupId):$($_.artifactId)" })
        consumes = @($inv.resolvedDeps.Keys | Where-Object { $g = $_.Split(':')[0]; @($prefixes | Where-Object { $g.StartsWith($_) }).Count })
    }
    Save-JsonFile $node (Join-Path (Join-Path (Split-Path -Parent $ctx.Config.portfolioCsv) 'graph') "$repoName.json")
    $cc = $a.classificationCounts
    $row = [pscustomobject]@{
        date = (Get-Date).ToString('yyyy-MM-dd'); repo = $repoName; sourceJdk = $a.sourceJdk; targetJdk = $a.targetJdk
        recommendation = $a.recommendation; aiRecommendation = $(if ($ai) { $ai.recommendation } else { '' }); aiConfidence = $(if ($ai) { $ai.confidence } else { '' })
        snykFindings = $(if ($snyk -and -not $snyk.skipped) { @($snyk.findings).Count } else { 'n/a' })
        checkmarxSast = $a.sast.total
        fixableNow = ($cc['fixable-now'] ?? 0) + ($cc['fixable-now-major-version'] ?? 0)
        needsJdk = $cc['needs-jdk-upgrade'] ?? 0; needsFramework = $cc['needs-framework-modernization'] ?? 0
        notInCompanyRepo = $cc['blocked-not-in-company-repo'] ?? 0; noFix = @($a.noFix).Count
        frameworks = (@($e.frameworks | ForEach-Object { "$($_.name) $($_.current) [$($_.status)]" }) -join '; ')
        blockers = @($e.blockers).Count; removedApiFiles = $e.removedApiFiles; repoPolicy = $a.repoPolicy
    }
    $dir = Split-Path -Parent $ctx.Config.portfolioCsv
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $row | Export-Csv -LiteralPath $ctx.Config.portfolioCsv -Append -NoTypeInformation -Encoding utf8
    Write-Good "portfolio row appended: $($ctx.Config.portfolioCsv)"
}
Set-PhaseDone $ctx 'A05-report'
