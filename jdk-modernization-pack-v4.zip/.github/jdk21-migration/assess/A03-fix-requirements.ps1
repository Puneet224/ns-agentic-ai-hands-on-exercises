#requires -Version 7.0
# A03 - "What does it take to remediate every Snyk/Checkmarx finding?"
#   For each fixed version: is it in the company repo? which Java does its bytecode need?
#   does it switch javax -> jakarta? is it a framework major-line jump?
#   -> fixable-now | fixable-now-major-version | needs-jdk-upgrade | needs-framework-modernization
#      | beyond-target-jdk | blocked-not-in-company-repo | no-fix
#   Combined with the JDK-compatibility findings this gives a deterministic recommendation. No AI.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
Write-Step 'A03 Remediation requirements per vulnerability'

$envInfo = Read-JsonFile (Get-WorkFile $ctx 'environment.json')
$inv = Read-JsonFile (Get-WorkFile $ctx 'inventory.json')
$compat = Read-JsonFile (Get-WorkFile $ctx 'compat.json')
$snyk = Read-JsonFile (Get-WorkFile $ctx 'snyk.json')
$cx = Read-JsonFile (Get-WorkFile $ctx 'checkmarx.json')
if (-not $envInfo -or -not $inv -or -not $compat) { throw 'Run A00 and A01 first.' }
$S = [int]$envInfo.jdk.sourceFeature
$T = [int]$ctx.TargetJdk
$policyEnforced = $envInfo.repoPolicy.status -eq 'enforced'
$projectJavaxEE = @($inv.resolvedDeps.Keys | Where-Object { $_ -match '^javax\.' -or $_ -match ':(javax\.servlet-api|servlet-api|javax\.persistence-api|hibernate-jpa-2\.\d-api)$' }).Count -gt 0

# ---- 1. collect fix targets (key + target version) with the vulnerabilities they fix
$targets = [ordered]@{}
$noFix = [System.Collections.Generic.List[object]]::new()
function Add-Target([string]$Key, [string]$Version, $Vuln) {
    if (-not $Key -or -not $Version) { return }
    $k = "$Key@$Version"
    if (-not $targets.Contains($k)) { $targets[$k] = @{ key = $Key; target = $Version; vulns = [System.Collections.Generic.List[object]]::new() } }
    $targets[$k].vulns.Add($Vuln)
}
if ($snyk -and -not $snyk.skipped) {
    foreach ($f in $snyk.findings) {
        $v = @{ source = 'snyk'; id = $f.id; severity = $f.severity; package = "$($f.package)@$($f.version)"; title = $f.title }
        if ($f.kind -eq 'no-fix') { $noFix.Add($v) } else { Add-Target $f.upgradeKey $f.target $v }
    }
}
$sast = @()
if ($cx -and -not $cx.skipped) {
    foreach ($f in @($cx.findings | Where-Object { $_.type -eq 'sca' })) {
        $v = @{ source = 'checkmarx'; id = $f.ruleId; severity = $f.severity; package = "$($f.package)@$($f.version)"; title = $f.ruleName }
        if ($f.package -and $f.fixVersion) { Add-Target $f.package $f.fixVersion $v } else { $noFix.Add($v + @{ note = 'no package/fix version parsed from SARIF - review manually' }) }
    }
    $sast = @($cx.findings | Where-Object { $_.type -eq 'sast' })
}

# ---- 2. analyse each fixed version
$fwRules = @($ctx.Rules.frameworks)
$availCache = @{}
$rows = [System.Collections.Generic.List[object]]::new()
foreach ($t in $targets.Values) {
    $g, $a = $t.key.Split(':', 2)
    $cur = Get-MinVersion @($inv.resolvedDeps[$t.key])
    if (-not $availCache.ContainsKey("$($t.key)@$($t.target)")) { $availCache["$($t.key)@$($t.target)"] = Test-ArtifactAvailable $ctx $g $a $t.target }
    $avail = $availCache["$($t.key)@$($t.target)"]
    $info = $null; $curInfo = $null
    if ($avail -eq 'jar') { $j = Get-LocalJar $ctx $g $a $t.target; if (Test-Path -LiteralPath $j) { $info = Get-JarJavaInfo $j } }
    if ($cur) { $cj = Get-LocalJar $ctx $g $a $cur; if (Test-Path -LiteralPath $cj) { $curInfo = Get-JarJavaInfo $cj } }
    $fw = $fwRules | Where-Object { $_.alignGroupId -eq $g -and $a -match $_.alignArtifactRegex } | Select-Object -First 1
    $majorChange = $cur -and ((Get-Major $cur) -ne (Get-Major $t.target))
    $wasJavax = if ($curInfo) { $curInfo.usesJavaxEE -or -not $curInfo.usesJakarta } else { $projectJavaxEE }
    $nsSwitch = $info -and $info.usesJakarta -and -not $info.usesJavaxEE -and $wasJavax
    $req = if ($info) { $info.javaFeature } else { $null }

    $class = if (-not $avail) { if ($policyEnforced) { 'blocked-not-in-company-repo' } else { 'not-resolvable' } }
    elseif ($req -and $req -gt $T) { 'beyond-target-jdk' }
    elseif ($nsSwitch -or ($fw -and $majorChange)) { 'needs-framework-modernization' }
    elseif ($req -and $req -gt $S) { 'needs-jdk-upgrade' }
    elseif ($majorChange) { 'fixable-now-major-version' }
    else { 'fixable-now' }

    $rows.Add(@{
            artifact = $t.key; current = $cur; target = $t.target; available = [bool]$avail; requiresJava = $req
            jakarta = [bool]$nsSwitch; framework = $(if ($fw) { $fw.name } else { $null }); majorChange = [bool]$majorChange
            classification = $class; vulnerabilities = @($t.vulns)
            maxSeverity = (@($t.vulns | ForEach-Object { $_.severity }) | Sort-Object { @{ critical = 4; high = 3; medium = 2; low = 1 }[$_] } -Descending | Select-Object -First 1)
        })
    Write-Info ("{0,-55} {1,-12} -> {2,-12} {3}" -f $t.key, $cur, $t.target, $class)
}

# ---- 3. JDK-upgrade side (independent of vulnerabilities)
$fwLine = @($compat.frameworks | Where-Object { $_.status -eq 'line-upgrade-required' })
$byClass = @{}; foreach ($r in $rows) { $byClass[$r.classification] = 1 + ($byClass[$r.classification] ?? 0) }
$vulnMinJava = $null; foreach ($r in $rows) { if ($r.available -and $r.requiresJava -and $r.requiresJava -gt ($vulnMinJava ?? 0)) { $vulnMinJava = $r.requiresJava } }

$needsFw = ($byClass['needs-framework-modernization'] ?? 0) -gt 0 -or $fwLine.Count -gt 0
$needsJdk = ($byClass['needs-jdk-upgrade'] ?? 0) -gt 0 -or ($byClass['needs-framework-modernization'] ?? 0) -gt 0
$recommendation = if ($needsFw) { 'jdk-upgrade-plus-framework-modernization' }
elseif ($needsJdk) { 'jdk-upgrade-required' }
else { 'patch-on-current-jdk-possible' }

$reasons = [System.Collections.Generic.List[string]]::new()
if ($byClass['needs-framework-modernization']) { $reasons.Add("$($byClass['needs-framework-modernization']) vulnerable artifact(s) are fixed only in a new framework line and/or jakarta.* (e.g. $(@($rows | Where-Object { $_.classification -eq 'needs-framework-modernization' } | Select-Object -First 3 | ForEach-Object { "$($_.artifact) $($_.target)" }) -join ', '))") }
if ($fwLine.Count) { $reasons.Add("JDK $T itself requires a framework line upgrade: $(@($fwLine | ForEach-Object { "$($_.name) $($_.current)" }) -join ', ')") }
if ($byClass['needs-jdk-upgrade']) { $reasons.Add("$($byClass['needs-jdk-upgrade']) fix(es) need a newer JDK than $S (highest needed: Java $vulnMinJava)") }
if ($byClass['beyond-target-jdk']) { $reasons.Add("$($byClass['beyond-target-jdk']) fix(es) need a JDK newer than the target $T") }
if ($byClass['blocked-not-in-company-repo']) { $reasons.Add("$($byClass['blocked-not-in-company-repo']) fixed version(s) are not available in the company repository") }
if (-not $reasons.Count) { $reasons.Add("All vulnerabilities with a fix can be remediated on Java $S without framework changes") }

$assessment = @{
    sourceJdk = $S; targetJdk = $T; recommendation = $recommendation; reasons = @($reasons)
    vulnerabilityFixes = @($rows); noFix = @($noFix); classificationCounts = $byClass; highestJavaNeededByFixes = $vulnMinJava
    sast = @{ total = $sast.Count; bySeverity = @($sast | Group-Object { $_.severity } | ForEach-Object { @{ severity = $_.Name; count = $_.Count } })
        topRules = @($sast | Group-Object { $_.ruleName } | Sort-Object Count -Descending | Select-Object -First 10 | ForEach-Object { @{ rule = $_.Name; count = $_.Count } })
        note = 'SAST findings are code fixes; they do not depend on the JDK version.' }
    jdkUpgradeEffort = @{
        frameworks = @($compat.frameworks); versionFindings = @($compat.versionFindings).Count; blockers = @($compat.blockers)
        removedApiFiles = @($compat.removedApiHits).Count
        behaviourRiskHits = @(@($compat.riskHits | Where-Object { -not $_.test }) | Group-Object { $_.id } | ForEach-Object { @{ id = $_.Name; count = $_.Count } })
        configHits = @($compat.configHits).Count
        internalLibsNeedingOwner = @($compat.internalLibs | Where-Object { $_.status -eq 'owner-action' } | ForEach-Object { "$($_.key):$($_.version)" })
        appJdkInternalUses = @($compat.appJdkInternals).Count
        thirdPartyJarIssues = @($compat.thirdPartyJars | ForEach-Object { @{ jar = "$($_.key):$($_.version)"; issues = @($_.issues); via = @($_.broughtBy)[0] } })
        divergentVersions = @($compat.divergentVersions).Count
        sourceEncodingDeclared = [bool]@($compat.encoding.declared).Count; nonUtf8SourceFiles = @($compat.encoding.invalidUtf8Files).Count
        repoRole = $compat.role
        deprecatedApiUses = $(if ($d = Read-JsonFile (Get-WorkFile $ctx 'deprecations-before.json')) { $d.summary.total } else { $null })
        deprecatedForRemoval = $(if ($d) { $d.summary.forRemoval } else { $null })
        javaAgents = @($compat.configHits | Where-Object { $_.id -eq 'java-agent' } | ForEach-Object { $_.match } | Select-Object -Unique)
    }
    repoPolicy = $envInfo.repoPolicy.status
}
Save-JsonFile $assessment (Get-WorkFile $ctx 'assessment.json')
Write-Host "`n    RECOMMENDATION: $recommendation" -ForegroundColor Magenta
foreach ($r in $reasons) { Write-Info "- $r" }
Set-PhaseDone $ctx 'A03-fix-requirements'
