#requires -Version 7.0
# A00 - Environment: project Java level (from the poms), JDK homes (auto-discovered, asked only
#       if ambiguous), company-repository policy, tools and credential presence. No AI. No changes.
param([Parameter(Mandatory)][string]$RepoPath)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '../lib/Jdk21Lib.psm1') -Force -DisableNameChecking
$ctx = Get-MigContext $RepoPath
$cfg = $ctx.Config
Write-Step "A00 Environment - $($ctx.Repo)"
if (-not (Test-Path (Join-Path $ctx.Repo 'pom.xml'))) { throw 'No pom.xml at repository root.' }

$jdk = Resolve-JdkHomes $ctx
Write-Info "project Java level: $($jdk.sourceFeature) (evidence: $(@($jdk.evidence | Select-Object -First 3 | ForEach-Object { $_.source + '=' + $_.value }) -join '; '))"
Write-Info "target Java level : $($jdk.targetFeature)  | rules: $(Split-Path -Leaf $ctx.RulesFile)"
if ((Split-Path -Leaf $ctx.RulesFile) -ne "jdk$($ctx.TargetJdk)-rules.json") { Write-Warn2 "No rules file for JDK $($ctx.TargetJdk); using $(Split-Path -Leaf $ctx.RulesFile). Copy and adapt it." }

$models = @(Get-PomModels $ctx)
$policy = Get-MavenRepoPolicy $ctx $models
Write-Info "company repo policy: $($policy.status)"
foreach ($v in $policy.violations) { Write-Warn2 $v }

$code = Invoke-Maven $ctx 'source' @('-v') 'assess-mvn-version.log' -Quiet
$mvnVer = [regex]::Match((Get-Content (Join-Path $ctx.Logs 'assess-mvn-version.log') -Raw), 'Apache Maven (\d+\.\d+\.\d+)').Groups[1].Value

$tools = [ordered]@{
    git          = [bool](Get-Command git -ErrorAction SilentlyContinue)
    maven        = $(if ($code -eq 0) { $mvnVer } else { $false })
    copilot      = [bool](Get-Command $cfg.copilotCmd -ErrorAction SilentlyContinue)
    snyk         = [bool]($cfg.snykEnabled -and (Get-Command $cfg.snykCmd -ErrorAction SilentlyContinue))
    snykTokenEnv = [bool]$env:SNYK_TOKEN
    checkmarx    = [bool]($cfg.checkmarx.enabled -and (Get-Command $cfg.checkmarx.cmd -ErrorAction SilentlyContinue))
    checkmarxEnv = @($cfg.checkmarx.requiredEnv | ForEach-Object { @{ name = $_; present = [bool][Environment]::GetEnvironmentVariable($_) } })
}
foreach ($k in $tools.Keys) { if ($k -ne 'checkmarxEnv') { Write-Info ("{0,-13}: {1}" -f $k, $tools[$k]) } }
foreach ($e in $tools.checkmarxEnv) { Write-Info ("{0,-13}: {1}" -f $e.name, $(if ($e.present) { 'set' } else { 'NOT set' })) }
if ($cfg.snykEnabled -and $tools.snyk -and -not $tools.snykTokenEnv) { Write-Warn2 'SNYK_TOKEN not set - relying on a prior "snyk auth" on this machine.' }

Save-JsonFile @{ jdk = $jdk; repoPolicy = $policy; tools = $tools; targetJdk = $ctx.TargetJdk } (Get-WorkFile $ctx 'environment.json')
if ($code -ne 0) { throw 'Maven is not runnable with the project JDK - see logs/assess-mvn-version.log' }
Assert-RepoPolicy $ctx $policy
Set-PhaseDone $ctx 'A00-environment'
