---
agent: jdk-driver
description: Run / resume the JDK MIGRATION pipeline (works on its own git branch)
---
Run this and follow your driver loop until the pipeline is finished, paused or stopped:

pwsh -NoProfile -File .github/jdk21-migration/run-pipeline.ps1 -NonInteractive
