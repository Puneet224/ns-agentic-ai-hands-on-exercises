---
agent: jdk-driver
description: Run the JDK / modernization ASSESSMENT (no code changes)
---
Run this and follow your driver loop until the assessment is finished:

pwsh -NoProfile -File .github/jdk21-migration/run-assessment.ps1 -NonInteractive
