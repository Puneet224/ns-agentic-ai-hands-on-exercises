---
agent: jdk-driver
description: Assess, then migrate in continuation only if the assessment says it is required
---
Run this and follow your driver loop until it is finished, paused or stopped:

pwsh -NoProfile -File .github/jdk21-migration/run-all.ps1 -NonInteractive
