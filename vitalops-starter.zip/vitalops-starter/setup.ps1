# vitalOps.ai - one-shot project bootstrap (Windows PowerShell)
# Usage:  .\setup.ps1
$ErrorActionPreference = "Stop"

$Project = "vitalops"

Write-Host "==> Checking prerequisites"
python --version
git --version

Write-Host "==> Creating project: $Project"
New-Item -ItemType Directory -Force -Path $Project | Out-Null
Set-Location $Project

Write-Host "==> Creating virtual environment"
python -m venv venv
& .\venv\Scripts\Activate.ps1

Write-Host "==> Installing packages"
pip install --upgrade pip --quiet
pip install sqlalchemy fastapi "uvicorn[standard]" httpx streamlit plotly pandas pytest
pip freeze > requirements.txt

Write-Host "==> Creating folder skeleton"
foreach ($d in @("sdk\vitalops","api\routes","dashboard","demo","scripts","tests")) {
    New-Item -ItemType Directory -Force -Path $d | Out-Null
}
foreach ($f in @("sdk\vitalops\__init__.py","api\__init__.py","api\routes\__init__.py","tests\__init__.py")) {
    New-Item -ItemType File -Force -Path $f | Out-Null
}

Write-Host "==> Writing .gitignore"
@"
venv/
env/
__pycache__/
*.py[cod]
*.egg-info/
.pytest_cache/
*.db
*.db-shm
*.db-wal
.vitalops_spool/
.env
.streamlit/secrets.toml
.vscode/
.idea/
.DS_Store
"@ | Set-Content -Path .gitignore -Encoding UTF8

Write-Host "==> Writing .env.example"
@"
VITALOPS_API_KEY=change-me
VITALOPS_DB_URL=sqlite:///vitalops.db
VITALOPS_ENDPOINT=http://localhost:8000
"@ | Set-Content -Path .env.example -Encoding UTF8

Write-Host "==> Initializing git"
git init --quiet
git add -A
git commit -m "Bootstrap vitalOps.ai project" --quiet

Write-Host ""
Write-Host "Done. Next steps:"
Write-Host "  1. Copy the .github folder into $(Get-Location)"
Write-Host "  2. code ."
Write-Host "  3. In VS Code terminal:  .\venv\Scripts\Activate.ps1"
Write-Host "  4. Copilot Chat -> Claude Opus 5 -> Agent mode -> /phase-1-schema-and-api"
