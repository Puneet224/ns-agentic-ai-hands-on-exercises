# How to use this folder

## What's here

```
.github/
├── copilot-instructions.md          ← loads automatically, never paste it
├── README.md                        ← this file
└── prompts/
    ├── phase-1-schema-and-api.prompt.md
    ├── phase-2-sdk.prompt.md
    ├── phase-3-checkup.prompt.md
    ├── phase-4-dashboard.prompt.md
    ├── phase-5-demo.prompt.md
    ├── phase-6-offline-queue.prompt.md   (stretch)
    ├── phase-7-cost.prompt.md            (stretch)
    └── fix-drift.prompt.md               (use when Copilot wanders)
```

## Setup

1. Put this `.github` folder in your project root:

   ```
   vitalops/
   ├── .github/          ← here
   ├── .gitignore
   └── ...
   ```

2. Open the `vitalops` folder in VS Code (**File → Open Folder**, not a single
   file — Copilot only reads instructions when the folder is the workspace root).

3. Enable prompt files. Open Settings (`Ctrl+,`), search
   `chat.promptFiles`, and turn it on. This lets you invoke the prompts with `/`.

4. Open Copilot Chat (`Ctrl+Alt+I` on Windows/Linux, `Cmd+Ctrl+I` on Mac).

5. Select **Claude Opus 5** in the model picker. Confirm before starting — the
   default model produces noticeably weaker architecture on prompts this dense.

6. Switch to **Agent mode** so Copilot can create files directly instead of just
   printing code.

## Verify the instructions loaded

Ask in Copilot Chat:

> What are my operating principles for this project?

If it repeats the six principles, you're set.
If you get a generic answer:
- check the file is exactly at `.github/copilot-instructions.md`
- reload the window: `Ctrl+Shift+P` → **Developer: Reload Window**
- confirm the workspace root is the `vitalops` folder

**You do not need to paste `copilot-instructions.md` into chat.** Copilot reads
it on every request automatically. That is the entire point of the file — it
survives restarts and applies to everyone who clones the repo.

## Running a phase

In Copilot Chat, type:

```
/phase-1-schema-and-api
```

The prompt file loads and runs. If the `/` command doesn't appear, prompt files
aren't enabled — go back to step 3, or just open the `.md` file and paste its
contents (everything below the `---` block) into chat.

## Order

| Order | Prompt | Priority |
|---|---|---|
| 1 | `/phase-1-schema-and-api` | Must |
| 2 | `/phase-2-sdk` | Must |
| 3 | `/phase-3-checkup` | Must |
| 4 | `/phase-4-dashboard` | Must |
| 5 | `/phase-5-demo` | Must |
| 6 | `/phase-6-offline-queue` | Stretch |
| 7 | `/phase-7-cost` | Stretch |

**One phase at a time.** Every phase prompt ends with a stop gate that forces
Copilot to run the app, test the flows, list unresolved issues, update
`handoff.md`, and stop. Do not remove it — Copilot's default behavior is to
barrel into the next phase with untested code behind it.

After each phase:

1. Read `handoff.md` — that's the phase summary
2. Read the generated code — don't accept blindly
3. Run it yourself; don't trust "it works" without seeing output
4. `git commit -m "Phase N: <what it does>"`
5. Only then start the next phase

Pasting several phases together degrades output quality sharply and hides wrong
turns until they're expensive to undo.

## handoff.md

Created at the repo root by Phase 1 and appended to by every phase after. Each
section covers: what was built · how to run it · verified working · unresolved
issues · assumptions made · **contract for the next phase**.

That last part is what makes parallel teamwork possible. Person B building the
SDK reads Person A's contract section for endpoint shapes instead of asking, and
Person C building the dashboard reads it for repository function signatures.

Commit `handoff.md` — it's shared team state, not scratch notes.

## When Copilot drifts

If it adds unapproved dependencies, writes SQL in route handlers, or
over-engineers something, run:

```
/fix-drift
```

That usually corrects it within one turn.

## Team split (4 people)

| Person | Phases | Blocked by |
|---|---|---|
| A | 1 — schema, repository, API | — |
| B | 2 — SDK | Phase 1's API contract |
| C | 4 — dashboard | Phase 1's repository functions |
| D | 3 — checkup, then 5 — demo and seed | Phases 1 and 2 |

Person A unblocks everyone. Agree the API contract within the first two hours,
then work in parallel against it.

Branch per phase:

```bash
git checkout -b phase-1-schema
# work, commit
git push -u origin phase-1-schema
# open PR, review, merge
```
