---
mode: agent
description: Phase 2 — the vitalops SDK package, the core deliverable
---

Build the `vitalops` SDK package. This is the heart of the project and where
judging attention will land.

## Target integration — must work exactly as written

```python
from vitalops import init, identify, track

init(agent="claims-bot")
identify(acf2_id=user.acf2)

@track
def handle_query(prompt): ...
```

## Public API surface

```
Lifecycle:  init(), configure(), flush(), shutdown()
Identity:   identify(), get_user(), clear_user()
Tracking:   track()   — works bare (@track) AND parameterized
                        (@track(agent=..., capture_input=False))
            event()   — manual named event with metadata
            timed()   — decorator capturing duration_ms
            session() — context manager grouping multi-turn interactions
Checkup:    is_checkup_due(), get_questions(), submit_feedback(),
            snooze(days=...), dismiss()
Class:      VitalOps  — instantiable client for multi-agent use and test mocking
Models:     Question, Questionnaire
Errors:     VitalOpsError (base), ConfigError, IdentityError, TransportError
```

## Automatic telemetry — captured with zero agent effort

The `@track` decorator wraps the host function, so it already knows all of this.
Capture it:

- `status`: success or failure
- `duration_ms`: `time.perf_counter` around the call
- `error_type`: the exception class name
- `error_category`: mapped from `error_type` through a lookup table —
  timeout, connectivity, auth, rate_limit, validation, unknown
- session duration: from the `session()` context manager on exit

Accept but do not populate: `model_name`, `input_tokens`, `output_tokens`,
`tool_name`. Expose them as optional keyword arguments on `event()` so agent
teams can supply them later without an SDK change. Document this in the README.

## Version and runtime context — captured once at init()

- `sdk_version` from `importlib.metadata.version("vitalops")`
- `agent_version` from `vitalops.yaml`, or the `init()` argument
- `git_commit` from `git rev-parse --short HEAD`, wrapped in try/except with a
  short timeout; `None` if not a git checkout
- `python_version`, `hostname`

Attach this block to every event. It makes deployment comparison possible —
"error rate doubled after v1.2 shipped" is the payoff, so do not skip it.

## Privacy controls

- `capture_input` and `capture_output` both default to `False`.
- `hash_user_id` config option: when True, SHA-256 the ACF2 ID before
  transmission so the central store holds a stable pseudonym rather than the raw
  identifier.
- `pii_fields` config: a list of metadata keys whose values are replaced with
  `[REDACTED]` before the event leaves the process.
- Masking happens in-process, before the event enters the queue. Raw values must
  never reach the transport layer.

## Non-negotiable behaviors

1. **Non-blocking.** Events enter an in-memory queue; a background worker thread
   flushes them in batches, triggered by batch size or elapsed time, whichever
   fires first.
2. **Fail-safe.** Any internal exception is caught and logged at DEBUG. The host
   function's return value and its exceptions pass through completely untouched.
   Provide `strict=True` config that re-raises instead — development only.
3. Preserve function metadata with `functools.wraps`. Support both sync and async
   host functions — detect via `inspect.iscoroutinefunction`.
4. **Graceful degradation.** If `init()` was never called, or the collector is
   unreachable, every SDK call becomes a silent no-op.
5. Flush on interpreter exit via `atexit` so buffered events are not lost.
6. Transport sends the bearer token from config or `VITALOPS_API_KEY`. Retries
   with exponential backoff, capped at 3 attempts, recording `retry_count` on the
   event.

## Tests (pytest)

Prove:
- the decorator preserves return values
- host exceptions propagate unchanged while still being recorded as failures
- a dead collector does not break the host function
- async functions work
- content is not captured by default
- `hash_user_id` produces no raw ACF2 ID in the outbound payload

---

## STOP GATE — mandatory

Stop after completing this phase. Do not begin the next phase under any
circumstances, even if the next step seems obvious.

Before you stop:

1. **Run the application.** Actually execute it in the terminal — do not assume
   it works because the code looks right.
2. **Test every flow you implemented in this phase.** Show me the commands you
   ran and their real output.
3. **List unresolved issues.** Anything broken, stubbed, assumed, or deferred.
   Be specific. "Error handling incomplete" is useless; "checkup snooze does not
   persist across restarts" is useful.
4. **Update `handoff.md`** at the repo root using the structure below. Append a
   new section — never overwrite previous phases.
5. **Then stop and wait for me.**

### handoff.md structure

```markdown
## Phase N — <name>
Status: complete | partial | blocked
Date: <date>

### What was built
- <file/module> — <one line on what it does>

### How to run it
<exact commands, copy-pasteable>

### Verified working
- <flow tested> — <what the output showed>

### Unresolved issues
- <issue> — <impact> — <suggested fix>

### Assumptions made
- <assumption> — <why> — <what to confirm>

### Contract for the next phase
- <what the next phase can rely on: function signatures, endpoints, schemas>
```

The "Contract for the next phase" section matters most — teammates work in
parallel against it. Be precise about signatures and shapes.
