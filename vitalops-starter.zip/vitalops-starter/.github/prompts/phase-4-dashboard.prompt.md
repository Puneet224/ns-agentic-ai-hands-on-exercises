---
mode: agent
description: Phase 4 — Streamlit dashboards for Outcome 1 and Outcome 2
---

Build the Streamlit dashboard serving both required outcomes. All data access
goes through the repository layer via `dashboard/queries.py`, returning pandas
DataFrames. No SQL in the UI.

## Outcome 1 — Adoption view

- Portfolio header: total agents, active users, total events
- Daily and weekly active users, per agent and portfolio-wide
- Adoption by Business Group and by Division (grouped bar charts)
- **Dark Agents panel**: agents with zero events in the last N days. Make this
  the most visually prominent element on the page — it is the single most
  actionable view for a leader.
- Retention curve: percentage of users still active N days after first use
- New vs returning user split

## Outcome 2 — Feedback view

- Sentiment distribution, overall and per agent
- Average time saved, rolled up to an estimated hours-per-month figure
- Barriers as a raw response list, most recent first
- Checkup response rate: completed vs pending vs snoozed
- Cross-view: sentiment plotted against usage frequency

## Reliability view (same event stream)

- Success rate over time, per agent
- Latency distribution: p50, p95, p99
- Error breakdown by category
- **Version comparison**: success rate and p95 latency grouped by
  `agent_version`. This is the payoff for version tracking — make it a clear
  side-by-side.

## Requirements

- Global filters: date range, agent, Business Group, Division
- Cache with `st.cache_data` and a sensible TTL
- Honest empty states when there is no data. Never fabricate placeholder numbers.

## Insights panel — rule-based, no LLM

Render generated one-line insights from thresholds in `dashboard/insights.py`:

- usage drop above 30% versus the prior period
- average sentiment below 3.0
- any agent with zero events in 14 days
- success rate below 95%
- p95 latency up more than 50% versus the prior period
- checkup response rate below 40%

Show the top three by severity. Keep every rule in that one module so an
LLM-backed generator could replace it later without touching the UI.

---

## STOP GATE — mandatory

Stop after completing this phase. Do not begin the next phase under any
circumstances, even if the next step seems obvious.

Before you stop:

1. **Run the application.** Actually execute it in the terminal — do not assume
   it works because the code looks right.
2. **Test every flow you implemented in this phase.** Show me the commands you
   ran and their real output.
3. **List unresolved issues.** Anything broken, stubbed, assumed, or deferred.
   Be specific. "Error handling incomplete" is useless; "checkup snooze does not
   persist across restarts" is useful.
4. **Update `handoff.md`** at the repo root using the structure below. Append a
   new section — never overwrite previous phases.
5. **Then stop and wait for me.**

### handoff.md structure

```markdown
## Phase N — <name>
Status: complete | partial | blocked
Date: <date>

### What was built
- <file/module> — <one line on what it does>

### How to run it
<exact commands, copy-pasteable>

### Verified working
- <flow tested> — <what the output showed>

### Unresolved issues
- <issue> — <impact> — <suggested fix>

### Assumptions made
- <assumption> — <why> — <what to confirm>

### Contract for the next phase
- <what the next phase can rely on: function signatures, endpoints, schemas>
```

The "Contract for the next phase" section matters most — teammates work in
parallel against it. Be precise about signatures and shapes.
