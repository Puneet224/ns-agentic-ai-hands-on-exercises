---
mode: agent
description: Phase 7 (stretch) — token usage and cost attribution
---

> **Only if everything above is complete and stable.**

Close the ROI loop — adoption metrics paired with what that adoption costs.

- Add a pricing lookup module mapping `model_name` to input and output rates.
- Compute `estimated_cost` **at ingestion, not in the SDK**, so pricing updates
  do not require every agent to upgrade.
- Add a dashboard view: cost by Business Group and Division, cost per agent, and
  cost per active user.

The schema fields already exist and are nullable, so this requires no migration —
that was the point of adding them in Phase 1.

---

## STOP GATE — mandatory

Stop after completing this phase. Do not begin the next phase under any
circumstances, even if the next step seems obvious.

Before you stop:

1. **Run the application.** Actually execute it in the terminal — do not assume
   it works because the code looks right.
2. **Test every flow you implemented in this phase.** Show me the commands you
   ran and their real output.
3. **List unresolved issues.** Anything broken, stubbed, assumed, or deferred.
   Be specific. "Error handling incomplete" is useless; "checkup snooze does not
   persist across restarts" is useful.
4. **Update `handoff.md`** at the repo root using the structure below. Append a
   new section — never overwrite previous phases.
5. **Then stop and wait for me.**

### handoff.md structure

```markdown
## Phase N — <name>
Status: complete | partial | blocked
Date: <date>

### What was built
- <file/module> — <one line on what it does>

### How to run it
<exact commands, copy-pasteable>

### Verified working
- <flow tested> — <what the output showed>

### Unresolved issues
- <issue> — <impact> — <suggested fix>

### Assumptions made
- <assumption> — <why> — <what to confirm>

### Contract for the next phase
- <what the next phase can rely on: function signatures, endpoints, schemas>
```

The "Contract for the next phase" section matters most — teammates work in
parallel against it. Be precise about signatures and shapes.
