---
mode: agent
description: Phase 3 — feedback trigger logic and questionnaire flow
---

Implement the feedback trigger and questionnaire flow.

## Trigger logic

A user is due for checkup on an agent when all of these hold:

- `days_since(first_seen_at) >= agent.checkup_interval_days`
- no completed checkup exists for that (user, agent) pair
- `snoozed_until` is null or in the past

Implement this as a **lazy check inside the SDK**, evaluated on interaction
rather than by a background scheduler. Add a comment justifying it: this removes
any need for cron or scheduler infrastructure, which matters enormously for a
drop-in library.

## Default question set (overridable per agent)

| key | type | text |
|---|---|---|
| sentiment | scale 1-5 | How would you rate your experience with this agent? |
| time_saved | numeric | Roughly how many minutes has this saved you per week? |
| barriers | text | What has made this agent harder to use than it should be? |
| recommend | scale 1-5 | How likely are you to recommend this to a colleague? |
| value_signal | text | What would make this significantly more useful? |

## Configuration

Agent teams override via `vitalops.yaml` in their repo root:

```yaml
agent: claims-bot
version: 1.4.0
checkup:
  after_days: 21
  questions:
    - key: sentiment
      type: scale
      range: [1, 5]
      text: "Rate your experience"
privacy:
  hash_user_id: true
  pii_fields: [email, phone]
```

Build `Questionnaire` and `Question` models that validate this config and produce
a renderable structure. Handle partial submission, snooze, and dismiss.

Parse the YAML with a minimal hand-rolled parser, or accept JSON as an
alternative. Do not add PyYAML unless you tell me why it is unavoidable.

## Adaptive branching — build this, it is not optional

A static survey asks the same questions regardless of the answers. Make the
questionnaire respond to what the user says:

- `sentiment <= 2` → follow up with "What specifically went wrong?"
- `sentiment >= 4` → follow up with "What has worked best for you?"
- `time_saved > 60` → follow up with "What task did this replace?"
- `barriers` left empty → skip the remaining open-text questions rather than
  asking someone who is clearly not engaging

Define branches declaratively in the config so agent teams can add their own:

```yaml
questions:
  - key: sentiment
    type: scale
    range: [1, 5]
    text: "Rate your experience"
    branches:
      - when: "<= 2"
        ask:
          key: failure_detail
          type: text
          text: "What specifically went wrong?"
```

Keep the branch evaluator small and rule-based — no LLM. This turns feedback
collection from a form into a short conversation, which is what raises response
quality and completion rate.

---

## STOP GATE — mandatory

Stop after completing this phase. Do not begin the next phase under any
circumstances, even if the next step seems obvious.

Before you stop:

1. **Run the application.** Actually execute it in the terminal — do not assume
   it works because the code looks right.
2. **Test every flow you implemented in this phase.** Show me the commands you
   ran and their real output.
3. **List unresolved issues.** Anything broken, stubbed, assumed, or deferred.
   Be specific. "Error handling incomplete" is useless; "checkup snooze does not
   persist across restarts" is useful.
4. **Update `handoff.md`** at the repo root using the structure below. Append a
   new section — never overwrite previous phases.
5. **Then stop and wait for me.**

### handoff.md structure

```markdown
## Phase N — <name>
Status: complete | partial | blocked
Date: <date>

### What was built
- <file/module> — <one line on what it does>

### How to run it
<exact commands, copy-pasteable>

### Verified working
- <flow tested> — <what the output showed>

### Unresolved issues
- <issue> — <impact> — <suggested fix>

### Assumptions made
- <assumption> — <why> — <what to confirm>

### Contract for the next phase
- <what the next phase can rely on: function signatures, endpoints, schemas>
```

The "Contract for the next phase" section matters most — teammates work in
parallel against it. Be precise about signatures and shapes.
