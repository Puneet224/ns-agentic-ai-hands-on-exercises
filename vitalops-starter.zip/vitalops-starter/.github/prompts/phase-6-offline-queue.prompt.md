---
mode: agent
description: Phase 6 (stretch) — offline disk spool so the SDK survives collector outages
---

> **Do not start this until Phases 1-5 run end to end.**

Make the SDK survive collector outages.

## Behavior

- On flush failure after exhausting retries, spool the batch to a local SQLite
  file at `.vitalops_spool/spool.db` rather than dropping it.
- On `init()`, attempt to drain the spool before processing new events.
- The worker retries the spool every 60 seconds so a recovered collector is
  picked up without a restart.
- Cap the spool at a configurable maximum (default 10,000 events). When full,
  drop the oldest and increment a dropped counter. Bounded loss beats unbounded
  disk growth on a long outage.
- Spool writes must be as fail-safe as everything else. If the disk is read-only
  or the path unwritable, log at DEBUG and continue in memory-only mode.

## Demo value

This is the strongest live moment available: stop the API, keep running the
agent, show it working normally, restart the API, watch the backlog land on the
dashboard. Build a demo script for exactly that sequence.

## Test

Simulate an outage, generate events, restore the collector, assert every event
eventually arrives exactly once.

---

## STOP GATE — mandatory

Stop after completing this phase. Do not begin the next phase under any
circumstances, even if the next step seems obvious.

Before you stop:

1. **Run the application.** Actually execute it in the terminal — do not assume
   it works because the code looks right.
2. **Test every flow you implemented in this phase.** Show me the commands you
   ran and their real output.
3. **List unresolved issues.** Anything broken, stubbed, assumed, or deferred.
   Be specific. "Error handling incomplete" is useless; "checkup snooze does not
   persist across restarts" is useful.
4. **Update `handoff.md`** at the repo root using the structure below. Append a
   new section — never overwrite previous phases.
5. **Then stop and wait for me.**

### handoff.md structure

```markdown
## Phase N — <name>
Status: complete | partial | blocked
Date: <date>

### What was built
- <file/module> — <one line on what it does>

### How to run it
<exact commands, copy-pasteable>

### Verified working
- <flow tested> — <what the output showed>

### Unresolved issues
- <issue> — <impact> — <suggested fix>

### Assumptions made
- <assumption> — <why> — <what to confirm>

### Contract for the next phase
- <what the next phase can rely on: function signatures, endpoints, schemas>
```

The "Contract for the next phase" section matters most — teammates work in
parallel against it. Be precise about signatures and shapes.
