---
mode: agent
description: Phase 5 — demo agents, synthetic seed data, and README quickstart
---

Prove reusability. This is the core claim of the challenge.

## 1. Two demo agents that share no code

Build them in `demo/`:

- a claims-processing agent (**synchronous**)
- a document-summarization agent (**async**)

Each integrates the SDK in exactly three lines. Give them different
`agent_version` values so the version comparison chart has real data.

## 2. Synthetic seed data

Write `scripts/seed.py` using only stdlib `random` and `datetime`:

- ~50 users across 4 Business Groups and 8 Divisions
- 60 days of history with a natural weekday/weekend usage pattern
- one agent that visibly declines to zero — the **"dark agent" moment**
- a version bump partway through where error rate jumps — the
  **"regression caught" moment**
- a realistic spread of checkup responses, including negative ones

## 3. README with a 60-second quickstart

```
pip install → seed → run API → run demo agents → open dashboard
```

## Demo narrative

Take a fresh agent repo, add three lines, run one query, watch the event appear
live on the dashboard. Optimize the harness for that beat — it is the moment the
pitch turns on.

---

## STOP GATE — mandatory

Stop after completing this phase. Do not begin the next phase under any
circumstances, even if the next step seems obvious.

Before you stop:

1. **Run the application.** Actually execute it in the terminal — do not assume
   it works because the code looks right.
2. **Test every flow you implemented in this phase.** Show me the commands you
   ran and their real output.
3. **List unresolved issues.** Anything broken, stubbed, assumed, or deferred.
   Be specific. "Error handling incomplete" is useless; "checkup snooze does not
   persist across restarts" is useful.
4. **Update `handoff.md`** at the repo root using the structure below. Append a
   new section — never overwrite previous phases.
5. **Then stop and wait for me.**

### handoff.md structure

```markdown
## Phase N — <name>
Status: complete | partial | blocked
Date: <date>

### What was built
- <file/module> — <one line on what it does>

### How to run it
<exact commands, copy-pasteable>

### Verified working
- <flow tested> — <what the output showed>

### Unresolved issues
- <issue> — <impact> — <suggested fix>

### Assumptions made
- <assumption> — <why> — <what to confirm>

### Contract for the next phase
- <what the next phase can rely on: function signatures, endpoints, schemas>
```

The "Contract for the next phase" section matters most — teammates work in
parallel against it. Be precise about signatures and shapes.
