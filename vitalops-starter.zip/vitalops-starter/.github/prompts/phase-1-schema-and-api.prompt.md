---
mode: agent
description: Phase 1 — SQLite schema, repository layer, and FastAPI ingestion service
---

Build the foundation: SQLite schema, repository layer, and FastAPI ingestion
service.

## Schema

```
users
  acf2_id (PK), business_group, division, first_seen_at, last_seen_at

agents
  agent_name (PK), owner, registered_at, checkup_interval_days (default 14)

events
  -- identity and timing
  id (PK), acf2_id (FK), agent_name (FK), event_type, occurred_at,
  session_id (nullable)
  -- execution telemetry
  duration_ms, status (success | failure), error_type (nullable),
  error_category (nullable), retry_count (default 0)
  -- version attribution
  agent_version (nullable), sdk_version, git_commit (nullable),
  python_version, hostname (nullable)
  -- future-ready, all nullable, unpopulated for now
  tool_name, model_name, input_tokens, output_tokens, estimated_cost
  -- extensibility
  event_metadata (JSON stored as TEXT)

checkups
  id (PK), acf2_id (FK), agent_name (FK), status
  (pending | completed | snoozed | dismissed), due_at, responded_at,
  snoozed_until (nullable)

feedback_responses
  id (PK), checkup_id (FK), question_key, question_text, response_value,
  response_type (scale | numeric | text | choice), submitted_at
```

## Design requirements

- Index `events` on (agent_name, occurred_at), (acf2_id, occurred_at), and
  (agent_name, status). Every dashboard query filters on these.
- `users.first_seen_at` anchors checkup scheduling. Set it once on the first
  event and never overwrite it.
- Store `event_metadata` as a JSON string with serialize/deserialize helpers.
- Enable SQLite WAL mode on connect for better concurrent read behavior.
- Keep the schema completely agent-agnostic. Nothing specific to any one agent.
- Use SQLAlchemy `create_all()` for setup. Skip Alembic — migrations are not
  worth the time in this build.

## Repository layer — build this FIRST, it is not optional

Create `api/repository.py` exposing functions like `record_events()`,
`upsert_user()`, `get_due_checkup()`, `save_feedback()`, and the read-side
queries the dashboard will need. Every function takes plain arguments and returns
plain objects or dicts. No SQLAlchemy types leak out of this module.

Route handlers call the repository. The dashboard calls the repository. Nothing
else touches a session. This is what makes the PostgreSQL migration claim true
rather than aspirational — state that in a module docstring.

## API endpoints

```
POST /v1/events          single event or batch, returns 202
POST /v1/identify        upsert user with org attributes
GET  /v1/checkup/due     query params acf2_id, agent_name → status + questions
POST /v1/feedback        submit questionnaire responses
GET  /health             liveness probe, no auth
```

## Security

- Bearer token auth via a FastAPI dependency on all `/v1` routes.
- Token read from the `VITALOPS_API_KEY` environment variable.
- If unset, run in open mode and log a clear warning at startup — local
  development must not require setup, but the absence must be visible.
- Return 401 with a plain body on bad tokens. Never echo the supplied token back.

## Deliver

- `api/db.py` with engine, session factory, `init_db()`
- Models, schemas, repository, routes, auth dependency
- `.env.example` listing every config variable
- A one-line README command that starts the API

Explain your indexing choices and any trade-off between write throughput and
query flexibility.

---

## STOP GATE — mandatory

Stop after completing this phase. Do not begin the next phase under any
circumstances, even if the next step seems obvious.

Before you stop:

1. **Run the application.** Actually execute it in the terminal — do not assume
   it works because the code looks right.
2. **Test every flow you implemented in this phase.** Show me the commands you
   ran and their real output.
3. **List unresolved issues.** Anything broken, stubbed, assumed, or deferred.
   Be specific. "Error handling incomplete" is useless; "checkup snooze does not
   persist across restarts" is useful.
4. **Update `handoff.md`** at the repo root using the structure below. Append a
   new section — never overwrite previous phases.
5. **Then stop and wait for me.**

### handoff.md structure

```markdown
## Phase N — <name>
Status: complete | partial | blocked
Date: <date>

### What was built
- <file/module> — <one line on what it does>

### How to run it
<exact commands, copy-pasteable>

### Verified working
- <flow tested> — <what the output showed>

### Unresolved issues
- <issue> — <impact> — <suggested fix>

### Assumptions made
- <assumption> — <why> — <what to confirm>

### Contract for the next phase
- <what the next phase can rely on: function signatures, endpoints, schemas>
```

The "Contract for the next phase" section matters most — teammates work in
parallel against it. Be precise about signatures and shapes.
