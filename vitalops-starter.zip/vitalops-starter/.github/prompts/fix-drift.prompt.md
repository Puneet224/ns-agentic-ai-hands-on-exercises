---
mode: agent
description: Paste this when Copilot starts adding unapproved deps or over-engineering
---

Stop and re-read the constraints for this project:

- Nothing may be specific to any single agent. If a design would require editing
  the SDK to onboard a new agent, it is wrong.
- Integration stays within three lines for the common case.
- No prompt or response content captured by default.
- Tracking failures never propagate to the host application.
- All database access goes through the repository layer. No raw SQL outside it.
- Approved dependencies only: `sqlalchemy`, `fastapi`, `uvicorn`, `httpx`,
  `streamlit`, `plotly`, `pandas`, `pytest`. Nothing else without justification.
- No Docker, no database server, no external APIs, no ML libraries.
- Prefer working end-to-end slices over complete-but-unrunnable layers.

Review what you just produced against this list. Tell me every violation you
find, then fix them.
