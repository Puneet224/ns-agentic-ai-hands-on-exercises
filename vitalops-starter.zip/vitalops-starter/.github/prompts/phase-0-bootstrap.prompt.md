---
mode: agent
description: Phase 0 — verify the environment and scaffold the project skeleton
---

Set up and verify the project skeleton. Run commands in the integrated terminal
and report what you find.

## 1. Verify the environment

Run these and show me the output:

```bash
python --version
git --version
pip list
```

Confirm:
- Python is 3.10 or higher
- a virtual environment is active (`venv` should appear in the `pip list` path,
  or `sys.prefix` differs from `sys.base_prefix`)
- these packages are installed: sqlalchemy, fastapi, uvicorn, httpx, streamlit,
  plotly, pandas, pytest

If anything is missing, tell me the exact command to fix it. **Do not create or
activate a virtual environment yourself** — venv activation does not persist
across your terminal calls, so pip would install into the wrong interpreter.
Report the problem and let me run it.

## 2. Create the folder skeleton

```
sdk/vitalops/
api/routes/
dashboard/
demo/
scripts/
tests/
```

Add an empty `__init__.py` to `sdk/vitalops/`, `api/`, `api/routes/`,
`dashboard/`, and `tests/`.

## 3. Create these files

**`requirements.txt`** — from `pip freeze`, or written out if freeze is empty.

**`.env.example`**
```
VITALOPS_API_KEY=change-me
VITALOPS_DB_URL=sqlite:///vitalops.db
VITALOPS_ENDPOINT=http://localhost:8000
```

**`.gitignore`** — Python artifacts, `venv/`, `*.db`, `*.db-shm`, `*.db-wal`,
`.env`, `.vitalops_spool/`, `.streamlit/secrets.toml`, editor and OS files.

**`sdk/setup.py`** (or `pyproject.toml`) so the SDK is installable with
`pip install -e ./sdk`. Package name `vitalops`, version `0.1.0`. This matters:
`importlib.metadata.version("vitalops")` is how the SDK reports `sdk_version` on
every event, and it only works if the package is properly installed.

**`README.md`** — a stub with the project one-liner and a Quickstart section I
will fill in during Phase 5.

## 4. Smoke test

Create a throwaway `scripts/smoke_test.py` that imports every approved
dependency and prints its version. Run it. If any import fails, tell me which
package to install.

Delete the file after it passes.

## 5. Report

Tell me:
- what was already correct
- what you created
- anything I need to run myself before Phase 1

Do not write any application code in this phase. Skeleton and config only.

---

## STOP GATE — mandatory

Stop after completing this phase. Do not begin the next phase under any
circumstances, even if the next step seems obvious.

Before you stop:

1. **Run the application.** Actually execute it in the terminal — do not assume
   it works because the code looks right.
2. **Test every flow you implemented in this phase.** Show me the commands you
   ran and their real output.
3. **List unresolved issues.** Anything broken, stubbed, assumed, or deferred.
   Be specific. "Error handling incomplete" is useless; "checkup snooze does not
   persist across restarts" is useful.
4. **Update `handoff.md`** at the repo root using the structure below. Append a
   new section — never overwrite previous phases.
5. **Then stop and wait for me.**

### handoff.md structure

```markdown
## Phase N — <name>
Status: complete | partial | blocked
Date: <date>

### What was built
- <file/module> — <one line on what it does>

### How to run it
<exact commands, copy-pasteable>

### Verified working
- <flow tested> — <what the output showed>

### Unresolved issues
- <issue> — <impact> — <suggested fix>

### Assumptions made
- <assumption> — <why> — <what to confirm>

### Contract for the next phase
- <what the next phase can rely on: function signatures, endpoints, schemas>
```

The "Contract for the next phase" section matters most — teammates work in
parallel against it. Be precise about signatures and shapes.
